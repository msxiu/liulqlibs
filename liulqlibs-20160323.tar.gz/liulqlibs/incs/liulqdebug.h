#ifndef LLQBASE_SQLITE_LOCAL_H_
#define LLQBASE_SQLITE_LOCAL_H_

#define GDB_LINE_NEXT "----------------------------------------------------------\n"


//--�����������****************************************************
#ifdef ENABLE_PROMPT
#define GDB_SEPARATOR(s) printf("------%s%s", s, GDB_LINE_NEXT)
#define LINEFLAG() printf(GDB_LINE_NEXT)
#define GDBMSGS(level, format, args...) {\
	if(gdb_log_allow(level, __FILE__)) {\
		gdb_log_printf(__FILE__, __LINE__);\
		printf(format, args);\
	}\
}
#define GDBMSG(level, msg) {\
	if(gdb_log_allow(level, __FILE__)) {\
		gdb_log_printf(__FILE__, __LINE__);\
		printf(msg);\
	}\
}
#define GDB_MSGL(fmt, addr, l) {\
	if(gdb_log_allow(D_DEBUG, __FILE__)) {\
		char dbuf[l + 1];\
		memcpy(dbuf, addr, l);\
		dbuf[l]=0;\
		gdb_log_printf(__FILE__, __LINE__);\
		printf(fmt, dbuf);\
	}\
} while(0)
#define GDBDATA(level, msg, buf, len) {\
		if(gdb_log_allow(level, __FILE__)) {\
			gdb_log_printf(__FILE__, __LINE__);\
			printf(msg);\
			printf("{");\
			for(int i=0;i<len;i++) {if(0 == (i%8))printf("\n");printf("0x%02x,", buf[i]);}\
			printf("\n}\n");\
		}\
	}

#else
#define GDB_SEPARATOR(s) printf("------%s%s", s, GDB_LINE_NEXT)
#define LINEFLAG() {}while(0)
#define GDB_MSGL(fmt, addr, l)  {}while(0)
#define GDBMSGS(level, format, args...) {}while(0)
#define GDBMSG(level, msg) {}while(0)
#define GDBDATA(level, msg, buf, len) {}while(0)
#endif

#define GDB_DEBUGD(msg, buf, len) GDBDATA(D_DEBUG, msg, buf, len)
#define GDB_DEBUGS(format, args...) GDBMSGS(D_DEBUG, format, args)
#define GDB_DEBUG(msg) GDBMSG(D_DEBUG, msg)
#define GDB_INFOD(msg, buf, len) GDBDATA(D_INFO, msg, buf, len)
#define GDB_INFOS(format, args...) GDBMSGS(D_INFO, format, args)
#define GDB_INFO(msg) GDBMSG(D_INFO, msg)
#define GDB_WARND(msg, buf, len) GDBDATA(D_WARN, msg, buf, len)
#define GDB_WARNS(format, args...) GDBMSGS(D_WARN, format, args)
#define GDB_WARN(msg) GDBMSG(D_WARN, msg)
#define GDB_ERRORD(msg, buf, len) GDBDATA(D_ERROR, msg, buf, len)
#define GDB_ERRORS(format, args...) GDBMSGS(D_ERROR, format, args)
#define GDB_ERROR(msg) GDBMSG(D_ERROR, msg)
#define GDB_EXITD(msg, buf, len) GDBDATA(D_EXIT, msg, buf, len)
#define GDB_EXITS(format, args...) GDBMSGS(D_EXIT, format, args)
#define GDB_EXIT(msg) GDBMSG(D_EXIT, msg)


#define FMT_IPADDR "%d.%d.%d.%d"
#define FMT_MAC		"%02X-%02X-%02X-%02X-%02X-%02X"
#define TO_IPLOCAL(a)  (int)((a)&0xFF), (int)(((a)>>8)&0xFF), (int)(((a)>>16)&0xFF), (int)(((a)>>24)&0xFF)
#define TO_IPADDR(a)  (int)(((a)>>24)&0xFF), (int)(((a)>>16)&0xFF), (int)(((a)>>8)&0xFF), (int)((a)&0xFF)
#define TO_MAC(a)		(int)a[0],(int)a[1],(int)a[2],(int)a[3],(int)a[4],(int)a[5]
#define STR_IPADDR(a, b)	sprintf(b, FMT_IPADDR, TO_IPADDR(a))
#define GDB_INTEGER_ADD(a)		(++a, a &= 0x0FFFFFFF)
#define GDB_INTEGER_SUM(a, b)		(a = ((a+b)&0x0FFFFFFF))


#endif /* LLQBASE_SQLITE_LOCAL_H_ */
