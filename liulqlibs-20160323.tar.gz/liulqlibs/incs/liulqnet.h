﻿/*
 * liulqnet.h
 *
 *  Created on: 2016年1月12日
 *      Author: root
 */

#ifndef SHAREDLIBS_INCS_LIULQNET_H_
#define SHAREDLIBS_INCS_LIULQNET_H_
#include <liulqcore.h>

#define MAXHTTPURI		256//URI地址的最大长度
#define MAXHTTPHEADER	1024//HTTP协议头部的最大长度
#define HTTP_MAX_HEADER 	1024
#define MAX_HTTP_PARA	128//模板页的最在参数长度
#define MAX_HTTP_TAGS 16 //标签的最大字段数
#define MAX_HTTP_HEADS	32

//#ifdef __cplusplus
//extern "C" {
//#endif


//***网络操作*********************************************************************************
typedef struct socketc_struct{//epoll事件客户端结构体
	int connfd;//套接字标识,未链接时或链接出错时,使用-1表示
	char ipaddr[MAX_IPADDR_LEN];//连接服务器的IP地址
	unsigned short port;//连接服务器的端口
} socketc_t;

typedef struct epollsvr_struct{//epoll事件服务端结构体
	char ipaddr[MAX_IPADDR_LEN];//服务端绑定的IP地址
	unsigned short port; //监听端口
	int backlog;//max listen queue
	int listen_fd;//监听套接字

	int epoll_fd;//内核_事件表的指针
	pthread_t thread_id;//监听线程ID
	struct epoll_event events[MAX_EVENT_NUMBER];//events是个数组，events就是数组的首地址，指针
	//----以下是相关操作函数
	int (*onsend)(struct epollsvr_struct *e, int i);//处理数据发送
	int (*onrecv)(struct epollsvr_struct *e, int i);//处理数据接收
	void* (*connect)(struct epollsvr_struct *e, socketc_t* c);
	int (*destory)(struct epollsvr_struct *e, int i);//处理数据接收
} epollsvr_t;


extern int epollsvr_start(epollsvr_t *e);//开始监听
extern int epollsvr_join(epollsvr_t *e);//等待线程执行完成
extern int epollsvr_cancel(epollsvr_t *e);//取消线程执行
extern int epollsvr_destory(epollsvr_t *e);//销毁对象


extern void epollsvr_tosend(epollsvr_t *e, socketc_t *c, int i);//设置为发送状态
extern void epollsvr_torecv(epollsvr_t *e, socketc_t *c, int i);//设置为接收状态
extern void epollcnt_destory(epollsvr_t *e, socketc_t *c, int i);//销毁对象


//****socket_client*********************************************************
extern int socketc_open(socketc_t *c);//打开一个客户端
extern int socketc_open_card(socketc_t *c, const char* card);//指定网卡,打开一个客户端
extern int socketc_close(socketc_t *c);//关闭客户端链接

extern int socketc_read(socketc_t *c, void* buffer, const unsigned int len);//从套接字中读取数据
extern int socketc_read_int(socketc_t *c, int * buf);//读取1个整形
extern int socketc_write(socketc_t *c, const void* buffer, const unsigned int len);//向套接字中写入数据
extern int socketc_writes(socketc_t *c, const char *buffer);
extern int socketc_write_int(socketc_t *c, unsigned int i);//写入1个整形
extern int socketc_writefile(socketc_t *c, const char* addr, int start, int len);


//***socket server operator*********************************************************
struct socksvr_struct;
typedef struct socksvrc_struct {
	socketc_t sock;
	pthread_t thread;//线程ID
	struct socksvr_struct* server;
}  socksvrc_t;
typedef struct socksvr_struct{//epoll事件服务端结构体
	char ipaddr[MAX_IPADDR_LEN];//服务端绑定的IP地址
	unsigned short port; //监听端口
	int backlog;//max listen queue
	int listen;//监听套接字

	int epoll;//内核_事件表的指针
	pthread_t thread;//监听线程ID
	struct epoll_event events[MAX_EVENT_NUMBER];//events是个数组，events就是数组的首地址，指针
	//----以下是相关操作函数
	void (*execute)(socksvrc_t* c);
} socksvr_t;
int socksvr_start(socksvr_t *e);//开始监听
int socksvr_join(socksvr_t *e);//等待线程执行完成
int socksvr_cancel(socksvr_t *e);//取消线程执行
int socksvr_destory(socksvr_t *e);//销毁对象


//***http protocol operator*********************************************************
extern char http_protocol_start(const char*p, int sln);//HTTP协议头识别
extern char http_comfirm(const char *data);//--进行http协议判断
extern char *http_time_now(char *time_buf);//--返回UTC格式时间
extern char *http_time(char* time_buf,  time_t src);//--返回UTC格式时间
extern const char*http_mime_type(char *uri);//--根据URL返回数据类型
extern char http_ishtml(char *uri);
extern int  http_read_header(int fd, char* hv); //读取HTTP头数据

//http协议缓存数据解析
typedef struct{
	const char* data;//数据指针
	int length;//数据
	char direction;//方向{0:请求,1:响应}
	int method;//请求方式
	int url;//访问地址
	int varsion;//HTTP协议版本
	int header;//头数据长度
	int body;//主体数据长度
} httpbuffer_t;
extern int httpbuffer_comfirm(httpbuffer_t *o);//判断缓存流是否为HTTP协议
extern int httpbuffer_header(httpbuffer_t *o);//从一端buffer数据中解析出http头部长度
extern int httpbuffer_key(httpbuffer_t *o, const char* key, int* len);//从o->data头数据中查找key开头的行
extern int httpbuffer_headkey(httpbuffer_t *o, const char* key, vdata_t* val);//从o->data头数据中查找key开头的行
extern int httpbuffer_context(httpbuffer_t *o);//确定缓存数据是否为HTTP协议,并解析HTTP协议
extern int httpbuffer_complete(httpbuffer_t *o, int len);//比较是否完成以次HTTP操作
extern void httpbuffer_completed(httpbuffer_t *o);//HTTP分段处理完成,重置对象

//**http protocol server***********************************************************************
typedef struct httpreq_struct {//http请求对象结构体有
	unsigned short vhead;//请求头长度
	char header[HTTP_MAX_HEADER];//请求头数据
	unsigned short vbody;//请求头长度
	char* body;//主求主体,动态申请,需要回收
	vsegment_t method;//请求方式
	vsegment_t uri;//请求地址
	vsegment_t query;//查询参数
	int headcnt;//请头选项个数
	vfield_t headers[MAX_HTTP_HEADS];//请求头选项
	int paracnt;//参数个数
	vfield_t paras[MAX_HTTP_PARA];//参数选项
	int cookcnt;//cook个数
	vfield_t cookies[MAX_HTTP_TAGS];//cook选项
} httpreq_t;
typedef struct httpres_struct {//http响应对象结构体
	unsigned short cache;//允许客户端缓存时长,单位秒
	int cookpos;//cook position
	char cookies[MAXHTTPURI];//以0结尾的cook数据
	dbuffer_t body;//响应主体
} httpres_t;
typedef struct httpd_config_struct {
	char root[MAX_HTTP_PARA];//网站根目录位置
	char module[MAX_HTTP_PARA];//模块文件目录
	char encoding[MAX_HTTP_TAGS];//字符编码
} httpd_config_t;
typedef struct httpd_struct {//http通信上下文结构体
	httpd_config_t *config;//配置
	epollsvr_t *server;//服务器
	socketc_t client;//客户端
	httpreq_t request;//请求对象
	httpres_t response;//响应对象
} httpd_t;

extern int  httpd_initialize(httpd_t *o);//得到一个请求时,初始化将读取请求数据
extern void httpd_destory(httpd_t* o);//销毁对象
extern char *httpd_mappath(httpd_t *o, const char* addr, char *taddr);//映射地址
extern char *httpd_maptemplate(httpd_t* o, const char* addr, char* taddr);//映射模板
extern const char* httpd_encoding(httpd_t* o);//获得字符编码
extern char httpreq_header(httpd_t* o,  const char* key, vdata_t* v);//获得请求头数据
extern char httpreq_header_segment(httpd_t* o,  const char* key, vsegment_t* v);//获得请求头数据
extern char httpreq_para(httpd_t* o,  const char* key, vdata_t* v);//获得请求参数
extern int  httpreq_para_integer(httpd_t* o,  const char* key);//获得整数型的参数
extern char httpreq_cookie(httpd_t* o, const char* key, vdata_t* v);//获得请求cookie

extern void httpres_cache(httpd_t* o,  int v);//请求响应页面的缓存时间
extern char httpres_cookie(httpd_t* o, const char* item);
extern char httpres_cookadd(httpd_t* o, const char* name, const char* val, time_t t);//添加响应cookie
extern char httpres_cookremove(httpd_t* o, const char* name);//remove响应cookie
extern char httpres_add(httpd_t* o, const void* buffer, int len);//向响应缓存添加数据
extern char httpres_addtext(httpd_t* o, const char* buffer);//向响应缓存添加文本
extern char httpres_write(httpd_t* o);//输出响应缓存到套按字
extern char httpres_writefile(httpd_t* o, const char* addr);//响应一个文件

extern char ftp_comfirm(const char* p);//判断流是否为FTP协议
extern char smtp_comfirm(const char *p);//判断缓存流是否为SMTP协议
//http协议缓存数据解析
typedef struct{
	const char* data;//数据指针
	char domain[256];//域名
	char form[256];//发件人
	char to[256];//收件人
} smtpbuffer_t;
extern char smtpbuffer_comfirm(smtpbuffer_t *o);//判断缓存流是否为SMTP协议


//**http_form_data*********************************************
typedef int (*form_data_cbk)(void* par, const char* name, const char* val, int vlen);
extern int http_form_data(httpbuffer_t* o, form_data_cbk data_cbk, void* par);//解析HTTP协议的form-data数据,不解析文件
typedef int (*form_data_file_cbk)(void* par, const char* name, const char* finalename, const char* filetype, const char* val, int vlen);
extern int http_form_data_file(httpbuffer_t* o, form_data_file_cbk data_cbk, void* par);//解析HTTP协议的form-data数据,可以解析文件


//#ifdef __cplusplus
//}
//#endif


#endif /* SHAREDLIBS_INCS_LIULQNET_H_ */
