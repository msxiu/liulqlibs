/*
 * rulestable.h
 *
 *  Created on: 2016年2月26日
 *      Author: root
 */

#ifndef HTTPENGINE_HTTPENGINE_H_
#define HTTPENGINE_HTTPENGINE_H_
#include <stdint.h>
#include <time.h>
#include "liulqcore.h"

#define member_offset(type, member)		((unsigned long)(&((type *)0)->member))
#define to_parent_address(ptr, type, member) \
    ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))


enum HTTP_AUDIT_RULE {//审计规则
	HTTP_AUDIT_NONE = 0,
	HTTP_AUDIT_MAIL = 1,
	HTTP_AUDIT_PAN = 2,
	HTTP_AUDIT_FORUM =3,
	HTTP_AUDIT_ATTACH = 4,
};
enum HTTP_METHD {//HTTP请求方式
	HTTP_METHD_ANY = 0,
	HTTP_METHD_GET = 1,
	HTTP_METHD_POST = 2,
};

enum URLCOMPARE_TYPE {//URL比较类型
	URLCOMPARE_IGNORE= 0,
	URLCOMPARE_CONTAIN = 1,
	URLCOMPARE_STARTWITH = 2,
	URLCOMPARE_ENDWITH = 3,
};

enum HTTPCONTENT_RESOLVE {//http内容解析规则
	HTTP_RESOLVE_FORMDATA = 1,
	HTTP_RESOLVE_URLDECODE,
	HTTP_RESOLVE_ATTACH,
	HTTP_RESOLVE_URLDECODE_REGEX,
	HTTP_RESOLVE_REGEX_URLDECODE
};


//****数据库结构定义*************************************************************************
//记录结构体
typedef struct rules_struct {
	int length;//记录长度
	char records[];//记录数据
} tbrecords_t;

typedef struct  {//http响应规则
	int id;
	enum HTTP_AUDIT_RULE rule;//审计规则
	enum HTTPCONTENT_RESOLVE resolve;//内容解析方式
	enum HTTP_METHD method;//请求方式
	enum URLCOMPARE_TYPE urltype;//URL比较类型;
	char domain[128];//域名
	char url[128];//URL
	char charset[32];//字符编码
	struct list_head attach_rules;//挂载附件规则
} tb_engine_actioni_t;


typedef struct {//邮件规则
	tb_engine_actioni_t action;
	char sender[128];//发送
	char receiver[128];//接收
	char cc[128];//抄送
	char bcc[128];//密送
	char subject[128];//标题
	char content[128];//内容
	char sid[128];//匹配附件关联字符串
	uint32_t mask;
	//struct list_head listrules;//规则列表,从持久化中加载数据
} tb_engine_mail_t;

typedef struct {//论坛规则
	tb_engine_actioni_t action;
	char subject[128];//标题
	char content[128];//内容
	char sid[128];//匹配附件关联字符串
	//struct list_head listrules;//规则列表,从持久化中加载数据
} tb_engine_forum_t;

typedef struct {//附件规则
	tb_engine_actioni_t action;
	enum HTTP_AUDIT_RULE ruletype;//规则类型
	int ruleid;//规则ID
	char sid[256];//参数关联
	char cook[256];//cook关联
	char data[128];//发送

	char offset[32];//开始位置
	char length[32];//当前数据长度

	char name[32];//文件名
	char aid[32];//非第1个包
	char size[32];//文件总大小
	//struct list_head listrules;//规则列表,从持久化中加载数据
} tb_engine_attach_t;

//*************************************************************************************
typedef struct {//TCP回话的五元组数据
    time_t startrawtime;/*开始时间*/
    time_t endrawtime;/*结束时间*/
    long total_sent;/*上行流量*/
    long total_recv;/*下行流量*/
    unsigned short int src_port;/*源端口*/
    uint32_t src;/*源IP*/
    unsigned short int dst_port;/*目的端口*/
    uint32_t dst;/*目的ip*/
    unsigned short int protocol;/*协议*/
    uint8_t dmac[6];//目标MAC地址
    uint8_t smac[6];//目标MAC地址
} tcpheader_t;

//*************************************************************************************
//void指针列表
typedef struct voidlist_struct {
	void* node;//当前节点指针
	struct voidlist_struct *next;//下一个节点
} voidlist_t;

//缓存数据单链表
typedef struct buffernext_struct {
	unsigned int type;//类型
	struct buffernext_struct* next;//下一个
	unsigned char data[];//根据结构大小分配的数据
}buffernext_t;

//HTTP协议引擎回调函数
typedef void(*httpengine_execute)(void* o, tcpheader_t* e);
//回调函数列表
typedef struct httpengine_cbk_struct {
	httpengine_execute execute;//回调函数
	struct httpengine_cbk_struct *next;//下一个节点
} httpengine_cbk_t;
//http协议处理函数
typedef struct httpengine_handle_struct {
	int attach_timeout;//附件超时时长,单位:秒
	httpengine_cbk_t* cbkmail;//邮件回调
	httpengine_cbk_t* cbkforum;//论坛回调
	httpengine_cbk_t* cbkpan;//网盘回调
	//struct list_head rules;//处理规则
	buffernext_t* rules;//处理规则
	struct list_head attachs;//挂载附件
} httpengine_handle_t;


//*************************************************************************************
#define		MSG_SENSITIVE_ALERT_SENDER_LEN			64 + 1
#define		MSG_SENSITIVE_ALERT_RECEIVE_LEN			256 + 1
#define		MSG_SENSITIVE_ALERT_TITLE_LEN			128 + 1
typedef struct {//分包附件
	char name[256];//文件名
	int aid;//非第1个包
	int offset;//开始位置
	int length;//当前数据长度
	int size;//文件总大小
} httattachpart_t;

typedef struct {//HTTP附件数据
	void *rules;//匹配规则
	int8_t		 m_method[16];//请求方式
	int8_t      m_domain[128];//所属域名
	int8_t		 m_uri[256];//所属URI

	int8_t      m_sid[256];//sid,用于匹配附件
	int8_t      m_name[256];//附件名称
	int8_t      m_type[128];//附件类型
	uint64_t m_offset;//当前包偏移
	uint64_t m_pktlen;//当前包大小
	uint64_t m_size;//附件总大小
	time_t m_time; //收到附件时间
	uint8_t* data;//附件内容
	httattachpart_t* part;//分包属性
	struct list_head list;//用于挂载列表
} httpattach_t;


typedef struct {//邮件数据
	void *rules;//匹配规则
	int8_t           m_sid[128];//sid,用于匹配附件
	int8_t           m_sender[MSG_SENSITIVE_ALERT_SENDER_LEN];//发送人
	int8_t           m_receiver[MSG_SENSITIVE_ALERT_RECEIVE_LEN];/*接收人ID和收受方地址，最长为256个字符*/
	int8_t           m_subject[MSG_SENSITIVE_ALERT_TITLE_LEN];/*event_type为电子邮件:邮件标题;为即时通信:官方名称;为博客、论坛、网盘:接收方网址*/
	int8_t* m_content;//正文
	struct list_head attachs; //附件列表
} httpmail_t;
typedef struct {//论坛数据
	void *rules;//匹配规则
	int8_t           m_sid[128];//sid,用于匹配附件
	int8_t           m_subject[MSG_SENSITIVE_ALERT_TITLE_LEN];/*event_type为电子邮件:邮件标题;为即时通信:官方名称;为博客、论坛、网盘:接收方网址*/
	int8_t* m_content;//正文
	struct list_head attachs; //附件列表
} httpforum_t;

/**添加邮件处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
extern void httpdescribe_addhandler_mail(httpengine_handle_t* o, void (*callback)(httpmail_t*, tcpheader_t* e));
/**添加论坛处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
extern void httpdescribe_addhandler_forum(httpengine_handle_t* o, void (*callback)(httpforum_t*, tcpheader_t* e));
/**添加网盘处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
extern void httpdescribe_addhandler_pan(httpengine_handle_t* o, void (*callback)(httpattach_t*, tcpheader_t* e));

//****http协议缓存数据解析****************************************************************************************
typedef struct{
	const char* data;//数据指针
	int length;//数据
	char direction;//方向{0:请求,1:响应}
	int method;//请求方式
	int url;//访问地址
	int varsion;//HTTP协议版本
	int header;//头数据长度
	int body;//主体数据长度
} httpbuffer_t;
//struct httpactionrule_struct;
typedef struct httpattachlist_struct {//挂载附件链表
	tb_engine_actioni_t* node;
	struct httpattachlist_struct* next;
} httpattachlist_t;

/**过滤获得HTTP协议解析规则
 *@parameter handler:协议处理者对象
 *@parameter o:请求缓存数据
 */
extern tb_engine_actioni_t* httpactionrules_filter(httpengine_handle_t* handler, httpbuffer_t* o);

#endif /* HTTPENGINE_HTTPENGINE_H_ */
