#ifndef LIULQSMART_H_
#define LIULQSMART_H_
#include <liulqcore.h>
#include <stdarg.h>

#define MAX_TAG_FIELD 16 //标签的最大字段数
#define MAX_UNIT_FIELD	32
#define DEFULTPAGE		"index.html"//默认首页
#define MAX_LEN_PARA	128//模板页的最在参数长度

#define VARIABLE_ARGUMENT(buffer, args, pos) {\
		int cln, ivl;\
		double dvl;\
		char*psql = buffer, *svl;\
		const char* p;\
		va_list ap;\
		va_start(ap, args);\
		for(p=args; *p; p++) {\
			if(*p != '%') {\
				psql[pos++] = *p;\
				continue;\
			}\
			switch(*++p) {\
			case 'd':\
				ivl = va_arg(ap, int);\
				pos += chars_form_int(psql + pos, 10, 0, ivl);\
				break;\
			case 'f':\
				break;\
			case 's':\
				for(svl = va_arg(ap, char*); *svl; svl++)  psql[pos++] = *svl;\
				break;\
			default:\
				psql[pos++] = *p;\
				break;\
			}\
		}\
		va_end(ap);\
} while(0)


//#ifdef __cplusplus
//extern "C" {
//#endif




//*****template***********************************************************************************
typedef struct sfield_struct {//--表示一个字段,包括名称,与值
	const void *addr;//数据开始地址
	vregion_t name;//字段名称
	vregion_t value;//字段值
} sfield_t;
extern char sfield_equals(sfield_t *o, const char* name);//比较名称是否相等
extern char* sfield_name(sfield_t *o, char* buffer);//获得对象名称,buffer是保存数据的内存地址
extern char* sfield_value(sfield_t *o, char* buffer);//获得对象值,buffer是保存数据的内存地址
extern int  sfield_integer(sfield_t *o);//获得对象整型值

typedef struct stagin_struct {
	unsigned int start;//开始位置
	unsigned int finish;//结束位置
	int value;//整数值
} stagin_t;
//--表示一个标签
typedef struct stag_struct {
	vdata_t data;//段数据
	vregion_t tagname;//标签的名字在data数据的开始位置与长度
	vsegment_t outner;//标签在非data外包数据的开始位置与长度
	vregion_t inner;//内嵌数据在data数据的开始位置与长度
	unsigned char fldcnt;//--使用的字段个数
	sfield_t fields[MAX_TAG_FIELD];//字段集合
	unsigned char indcnt;//内嵌对象集合个数
	stagin_t inodes[MAX_UNIT_FIELD];//内嵌对象集合
} stag_t;

extern char stag_equals(stag_t* o, const char*name);//比较与标签名是否相等
extern char *stag_tagname(stag_t* o, char*name);//获得标签名
extern char stag_field_add(stag_t* o, sfield_t fld);//添加一个字段
extern char stag_field_append(stag_t* o, const void* addr, int nlen, int vpos, int vlen);//--添加字段
extern int  stag_field_of(stag_t* o, const char* name);//--包含字段
extern int  stag_field_value(stag_t* o, const char* name, char* val);//获得字段值
extern char stag_field_value_pos(stag_t* o, int index, char* val);//获得指定下标的字段值
extern char stag_field_name(stag_t* o, int index, char* name);//--获得属性名称
extern int  stag_field_integer(stag_t* o, const char* name);//获得指定名字的整型值
extern int  stag_field_count(stag_t* o);//--字段个数

extern int  stag_inner_parse(stag_t* o);//内嵌节点解析
extern char stag_inner_fore(stag_t* o, int i, vdata_t* v);//获得第i个内嵌节点之前内容
extern char stag_inner_last(stag_t* o, vdata_t* v);//获得内嵌节点最后内容
extern int  stag_inner_value(stag_t* o, int i);//获得第i个内嵌节点值
extern int  stag_inner_count(stag_t* o);//获得内嵌节点个数

//--从文件中解析出来的模板
typedef struct stemplate_struct {
	char hastemplate;//是否成功加载模板
	vdata_t data;//数据指针
	linked_list_t tags;//标签列表
	char invokepar[MAX_LEN_PARA];//调用母版页时的参数
} stemplate_t;


extern stemplate_t* stemplate_initailize(const char *addr);//从文件中加载一个模板
extern void stemplate_destory(stemplate_t* o);//销毁一个模板对象
extern int  stemplate_param(stemplate_t* o, const char* key, char* val);//获得调用参数
extern int  stemplate_param_integer(stemplate_t* o, const char* key);//获得调用参数
extern void stemplate_reset(stemplate_t* o);//重置节点列表对象
extern char stemplate_next(stemplate_t* o);//是否有下一个节点对象
extern char stemplate_fore(stemplate_t* o, vdata_t* v);//模板当前节点与上一个节点之间的数据
extern stag_t  *stemplate_entry(stemplate_t* o);//获得模板的当前实体
extern char stemplate_last(stemplate_t* o, vdata_t* v);//模板当前节点与下一个节点之间的数据


typedef struct templatec_struct {
	stemplate_t *module;
	char hasmodule;
	fcache_check_t master;
	fcache_check_t invoke;
} templatec_t;
char templatec_initialize(templatec_t* o, const char* addr);
stemplate_t* templatec_entry(templatec_t* o);
void templatec_free(templatec_t* o);


//#ifdef __cplusplus
//}
//#endif

#endif /* LIULQSMART_H_ */
