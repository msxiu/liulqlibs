/*
 * liulqflow.h
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */

#ifndef LIULQNET_LIULQFLOW_LIULQFLOW_H_
#define LIULQNET_LIULQFLOW_LIULQFLOW_H_
#include <stdint.h>
#include "liulqcore.h"

//********************************************************************************************
//IP碎片操作函数
//********************************************************************************************
//IP碎片重组后回调函数
typedef int (*ipfrag_execute)(void* buffer, uint32_t len);
//IP碎片处理器结构体
typedef struct ipfrag_struct {
	hashmap_t* map;//哈希表
	ipfrag_execute handle_ip;//IP包处理程序列表
	ipfrag_execute handle_arp;//ARP包处理程序列表
} ipfrag_t;

/**添加IP碎片处理初始化
 *@parameter o:对象
 *@parameter mx:最大hash数
 */
extern int ipfrag_initialize(ipfrag_t* o, int mx, ipfrag_execute process_ip, ipfrag_execute process_arp);
/**添加IP包
 *@parameter o:对象
 *@parameter packet:数据包
 *@parameter len:数据包长度
 */
extern int ipfrag_addpacket(ipfrag_t* o, void* packet, unsigned int len);


//********************************************************************************************
//TCP流汇聚操作函数
//********************************************************************************************
//数据包通信插口
typedef struct {
	uint32_t ip;//IP地址
	uint16_t port;//端口
} packetjack_t;

typedef struct {//TCP回话的五元组数据
	packetjack_t src;//源IP
	packetjack_t dst;//目的IP
    uint8_t dmac[6];//目标MAC地址
    uint8_t smac[6];//目标MAC地址
    time_t startrawtime;/*开始时间*/
    time_t endrawtime;/*结束时间*/
    long total_sent;/*上行流量*/
    long total_recv;/*下行流量*/
} tcpflowhdr_t;

//通信的一端
typedef struct {
	char state;//TCP连接状态
	uint32_t acked;//确认码
	uint32_t seq;//序列号
	uint32_t ack_seq;//确认序列号
	uint32_t first_data_seq;//首包序列号
	uint16_t window;//窗口宽度
	uint8_t ts_on;
	uint32_t curr_ts;
	uint8_t wscale_on;//是否开启窗口扩大因子
	uint32_t wscale;//窗口扩大因子

	uint32_t count;//接收数据字节数
	uint32_t urg_count;//加急数据字节数
}tcpflowhalf_t;

typedef struct {
    uint16_t protocol;//协议类型
    uint8_t refuse;//是否拒收数据包{0:不拒收,1:拒收}
	tcpflowhalf_t client;//客户端
	tcpflowhalf_t server;//服务端
	tcpflowhdr_t hdr;//数据头
	uint32_t validcount;//content中有效数据长度
	void* content;//
}tcpsession_t;


//TCP流汇聚完成后的回调函数
typedef int (*tcpflow_execute)(tcpsession_t* item);
/**流汇聚时包处理函数
 *@parameter tcp:流汇聚对象
 *@parameter buffer:数据缓存
 *@parameter len:数据长度
 *@return :还回真,需回调流处理
 */
typedef char(*tcpflow_writepkt)(tcpsession_t* tcp, char fclient, uint32_t offset, void* buffer, uint32_t len);

//TCP流汇聚结构体
typedef struct tcpflow_struct {
	hashmap_t* map;//会话(session)对象的哈希表
	tcpflow_execute handle_stream;//流汇聚完成后的回调处理程序
	tcpflow_execute handle_recover;//数据回收
	tcpflow_writepkt handle_packet;//packet包处理函数
} tcpflow_t;


/**添加TCP流汇聚处理初始化
 *@parameter o:对象
 *@parameter mx:最大hash数
 */
extern int tcpflow_initialize(tcpflow_t* o, int mx, tcpflow_execute process_stream, tcpflow_writepkt process_pkt, tcpflow_execute process_recover);
/**添加数据包
 *@parameter o:对象
 *@parameter packet:数据包
 *@parameter len:数据包长度
 */
extern int tcpflow_addpacket(tcpflow_t* o, void* packet, unsigned int len);
/**TCP流汇聚处理过程显示
 *@parameter o:对象
 */
extern void tcpflow_sow(tcpflow_t* o);

#endif /* LIULQNET_LIULQFLOW_LIULQFLOW_H_ */
