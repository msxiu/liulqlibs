/*
 * actree.h
 *
 *  Created on: 2016年2月24日
 *      Author: root
 */
#include <stdint.h>
#include "liulqcore.h"

#ifndef INCS_ACTREE_H_
#define INCS_ACTREE_H_

#define ACTREE_PATTERN_LEN 256
#define ACTREE_MAX_CHILDS	256

enum ACTREE_STYLE {
	ACTREE_STYLE_NONE = 0,
	ACTREE_STYLE_BCSHIFT  = 1,
	ACTREE_STYLE_GSSHIFT = 2,
};

typedef struct actree_node_struct {//关键词节点树
	int label;// lable 记录字串来自于初始化数组的第几个输入字串
	int depth;//关建词首字母到当前字母的深度
	unsigned char ch;//节点对应的字符
	int GSshift;
	unsigned char one_child;
	struct actree_node_struct *childs[ACTREE_MAX_CHILDS];//子节点
	int nchild;//子节点个数
	struct actree_node_struct *parent;//父节点
} actree_node_t;

typedef struct actree_key_struct {//一个匹配关键词
	unsigned char data[ACTREE_PATTERN_LEN] ;//匹配关键词
	int len ;//关键词长度
} actree_key_t ;

typedef struct acbmtree_struct {//编译生成好的匹配关键词对象树
	actree_node_t *root;// 树根节点
	int max_depth;//关键词最大深度
	int min_pattern_size;//关键词的最短长度
	enum ACTREE_STYLE style;//处理类型
	int BCshift[256];//字符在关键词列表中首次出现的位置

	actree_key_t *pattern_list;//指向节点数组第一个字串的指针
	int pattern_count;// 包含的字串个数
	int (*gsposition)(actree_node_t *node);//获得gs_shift位置
} actree_t;

typedef struct actree_match_element_struct {//匹配的一个结果单元
	actree_key_t *pattern;//pattern_data关键词数组下标
	unsigned long offset ;//在文本中的位置
} actree_match_element_t ;


typedef struct actree_match_struct {//匹配结果集合
	uint32_t max;//允许保存结果集的最大个数
	uint32_t index;//当前下标
	actree_match_element_t elements[];//关键词列表
} actree_match_t;




/**附加字母首次出现列表
 * @ptree 匹配树对象
 */
extern int actree_BCshifts_attach (actree_t *ptree);
/**绑定多模匹配节点树的跳转逻辑
 *@ptree 匹配树
 */
extern int actree_shifts_attach (actree_t *ptree);
/** actree树初始化关键词
 * @ptree 关键词初始化的树节点,即将关键词初始化到该树上
 * @param patterns 关键词对象列表
 * @param npattern 关键词对象个数
 */
extern int actree_patterns (actree_t *ptree, actree_key_t *patterns, int npattern);
/** acbm树关键词重置
 * @ptree 匹配树
 * @argc 关键词对象个数
 * @argv 关键词对象列表
*/
 extern void actree_resetkeys (actree_t *ptree, int argc, char* argv[]);
 /**使用关键词创建actree对象
  *@argc 关键词个数
  *@argv 关键词数组
  *@style actree对象样式
  */
extern actree_t* actree_create(int argc, char* argv[], enum ACTREE_STYLE style);


/**acbmtree_t通知改变响应函数
 * @o inotify节点
 * @t 操作位掩码
 */
extern void actree_notify_change(inotifynode_t* o, uint32_t t);
/**actree关键词数组文件动态通知加载
 * @o 检测文件集合
 */
extern int actree_inotify(inotifywatch_t* o);

/**销毁对象
 * @ptree 编译好的关键词树
 */
void actree_destory (actree_t *ptree);
/**申请匹配结果集内存
 * @max 结果集最大个数
 */
actree_match_t* actree_alloc_matchs(uint32_t max);
/**从指定的多模匹配树中搜索关键词
 * @ptree 编译好的关键词树
 * @text 文本字符串
 * @tlen 文本字符串长度
 * @matcheds 匹配到的关键词结果
 * @nmax 允许匹配的最大个数
 * @nmatched 存放结果的位置
 */
int actree_search(actree_t *ptree, unsigned char *text, int tlen, actree_match_t *matcheds, int nreply);

#endif /* INCS_ACTREE_H_ */
