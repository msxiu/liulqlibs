/**链表头是原理是通过把
a.next->b b.next->c c.next->a
a.prev->c c.prev->b b.prev->a
这样循环链接方式实现
*/
#ifndef _TOPLIST_H_
#define _TOPLIST_H_
#include "liulqcore.h"

#if defined(WIN32)
#define INLINE __inline
#else
#define INLINE inline
#endif


//初始化链表头结构
#define LIST_HEAD_INIT(name) { &(name), &(name) }

//申请链表头节点,
#define LIST_HEADM(name) \
    struct list_head name = LIST_HEAD_INIT(name)

//链表头结构指针赋值
#define INIT_LIST_HEAD(ptr)  do { \
    (ptr)->next = (ptr); (ptr)->prev = (ptr); \
} while (0)


static INLINE void __list_add(struct list_head *new_n, struct list_head *prev, struct list_head *next)
{
    next->prev = new_n;
    new_n->next = next;
    new_n->prev = prev;
    prev->next = new_n;
}

//添加节点到链表头
static INLINE void list_add_n(struct list_head *new_n, struct list_head *head)
{
    __list_add(new_n, head, head->next);
}

//添加节点到锭表尾
static INLINE void list_add_tail(struct list_head *new_n, struct list_head *head)
{
    __list_add(new_n, head->prev, head);
}


static INLINE void __list_del(struct list_head *prev, struct list_head *next)
{
    next->prev = prev;
    prev->next = next;
}

//删除一个节点
static INLINE void list_del(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    entry->next = (struct list_head*)(void *) 0;
    entry->prev = (struct list_head*)(void *) 0;
}

/**
 * list_del_init - 从链表中删除节点,并以该实体初始化链表.
 * @entry: 节点.
 */
static INLINE void list_del_init(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    INIT_LIST_HEAD(entry);
}

/**
 * list_move - 从一个列表中删除，并添加作为另一个的头部
 * @list: 删除的节点
 * @head: 要添加的头节点
 */
static INLINE void list_move(struct list_head *list, struct list_head *head)
{
    __list_del(list->prev, list->next);
    list_add_n(list, head);
}

/**
 * list_move - 从一个列表中删除，并添加作为另一个的尾部
 * @list: 删除的节点
 * @head: 要添加的头节点
 */
static INLINE void list_move_tail(struct list_head *list, struct list_head *head)
{
    __list_del(list->prev, list->next);
    list_add_tail(list, head);
}

static INLINE int list_empty(struct list_head *head) //测试列表是否为空
{
    return head->next == head;
}

static INLINE void __list_splice(struct list_head *list, struct list_head *head)
{
    struct list_head *first = list->next;
    struct list_head *last = list->prev;
    struct list_head *at = head->next;

    first->prev = head;
    head->next = first;

    last->next = at;
    at->prev = last;
}


static INLINE void list_splice(struct list_head *list, struct list_head *head)//连接两个链表
{
    if (!list_empty(list))
        __list_splice(list, head);
}

/**
 * list_splice_init - 连接两个列表和初始化清空列表.
 * @list: 新列表中添加, @list 链表被初始化.
 * @head: 将其添加在第一个列表.
 */
static INLINE void list_splice_init(struct list_head *list, struct list_head *head)
{
    if (!list_empty(list)) {
        __list_splice(list, head);
        INIT_LIST_HEAD(list);
    }
}

/**
 * list_entry - 获得数据实体
 * @ptr: list_head结构体指针.
 * @type: 链表结构体名称.
 * @member: 链表头成员在结构体中的名称.
 */
#define list_entry(ptr, type, member) \
    ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))

/**
 * list_for_each - 遍历链表
 * @pos: the &struct list_head to use as a loop counter.
 * @head: 链表头.
 */
#define list_for_each(pos, head) \
    for (pos = (head)->next; pos != (head); pos = pos->next)

/**
 * list_for_each_prev - 向前遍历链表
 * @pos: the &struct list_head to use as a loop counter.
 * @head: 链表头.
 */
#define list_for_each_prev(pos, head) \
    for (pos = (head)->prev; pos != (head); pos = pos->prev)

/**
 * list_for_each_safe - 遍历链表,预防遍历中删除节点
 * @pos: the &struct list_head to use as a loop counter.
 * @n:  another &struct list_head to use as temporary storage
 * @head: 链表头.
 */
#define list_for_each_safe(pos, n, head) \
    for (pos = (head)->next, n = pos->next; pos != (head); pos = n, n = pos->next)

/**
 * list_for_each_entry - 遍历链表,这里的pos是数据项结构指针类型，而不是(struct list_head *)
 * @pos: the type * to use as a loop counter.
 * @head: the head for your list.
 * @member: the name of the list_struct within the struct.
 */
#define list_for_each_entry(pos, head, member)    \
    for (pos = list_entry((head)->next, typeof(*pos), member); \
            &pos->member != (head);      \
            pos = list_entry(pos->member.next, typeof(*pos), member))

/**
 * list_for_each_entry_safe - 遍历链表,预防遍历中删除节点,这里的pos是数据项结构指针类型
 * @pos: the type * to use as a loop counter.
 * @n:  another type * to use as temporary storage
 * @head: the head for your list.
 * @member: the name of the list_struct within the struct.
 */
#define list_for_each_entry_safe(pos, n, head, member)   \
    for (pos = list_entry((head)->next, typeof(*pos), member), \
            n = list_entry(pos->member.next, typeof(*pos), member); \
            &pos->member != (head);      \
            pos = n, n = list_entry(n->member.next, typeof(*n), member))



#endif /* toplist.h */
