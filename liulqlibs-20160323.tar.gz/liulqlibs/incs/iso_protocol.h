﻿#ifndef MP_SERVER_ISO_PROTOCOL_H_
#define MP_SERVER_ISO_PROTOCOL_H_
#include <net/ethernet.h>
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <linux/udp.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <arpa/inet.h>

extern inline uint8_t* pkt_ether_smac(char* pkt);//获得二层协议的源mac
extern inline uint8_t* pkt_ether_dmac(char* pkt);//获得二层协议的目的mac
extern inline uint16_t pkt_ether_type(char* pkt); //获得二层协议类型

//***ARP***********************************************************************
extern  inline char pkt_isarp(char*pkt);//判断是否为ARP协议
extern inline struct ether_arp* pkt_arp_body(char*pkt);//获得ARP主体
extern inline uint16_t pkt_arp_operate(char* pkt);//操作类型,1:ARP请求,2:ARP应答,3:RARP请求,4:RARP应答
 //***IP***********************************************************************
extern  inline char pkt_isip(char*pkt);//判断是否为IP协议
extern  inline struct iphdr* pkt_ip_header(char* pkt);//获得IP头
extern  inline uint8_t pkt_ip_protocal(char* pkt);//获得IP下一层协议{1:ICMP,6:TCP,17:UDP}
extern inline unsigned char pkt_ip_hdrlen(char*pkt);//获得IP头长度
extern inline uint32_t pkt_ip_daddr(char* pkt);//获得目的IP地址
extern inline uint32_t pkt_ip_saddr(char* pkt);//获得源IP地址
extern inline uint16_t pkt_ip_identity(char* pkt);//获得IP标识
extern inline uint32_t pkt_ip_bodypos(char* pkt);//获得IP包数据流位置
//***ICMP*********************************************************
extern inline char pkt_isicmp(char* pkt);//是否为ICMP包
extern inline struct icmphdr* pkt_icmp_header(char* pkt);//获得ICMP头
extern inline uint8_t pkt_icmp_type(char* pkt);//ICMP类型,0:应答,8:请求
extern inline uint8_t pkt_icmp_code(char* pkt);//ICMP code
extern inline uint16_t pkt_icmp_checksum(char* pkt);//ICMP校验码
//***UDP***********************************************************
extern inline char pkt_isudp(char* pkt);//是否为UDP包
extern inline struct udphdr* pkt_udp_header(char* pkt);//获得UDP头
extern inline uint16_t pkt_udp_dport(char* pkt);//获得UDP目标端口
extern inline uint16_t pkt_udp_sport(char* pkt);//获得UDP源端口
extern inline uint16_t pkt_udp_length(char* pkt);//获得UDP包的长度
extern inline uint16_t pkt_udp_bodylen(char* pkt);//获得UDP包内容长度
extern inline uint16_t pkt_udp_bodypos(char* pkt);//获得UDP包内容位置
extern inline uint16_t pkt_udp_reader(char* pkt, void*buffer);//读取UDP内容到缓存
//***TCP***********************************************************
extern inline char pkt_istcp(char* pkt);//是否为TCP包
extern inline struct tcphdr* pkt_tcp_header(char* pkt);//获得TCP包头
extern inline uint16_t pkt_tcp_dport(char* pkt);//获得TCP包目标端口
extern inline uint16_t pkt_tcp_sport(char* pkt);//获得TCP包源端口
extern inline uint32_t pkt_tcp_sequence(char* pkt);//获得TCP包序列号
extern inline uint32_t pkt_tcp_ack(char* pkt);//获得TCP包ack
extern inline uint32_t pkt_tcp_hdrlen(char* pkt);//获得TCP包头长度
extern inline uint16_t pkt_tcp_window(char* pkt);//获得TCP包window
extern inline uint16_t pkt_tcp_check(char* pkt);//获得TCP包校验码
extern inline uint16_t pkt_tcp_bodypos(char* pkt);//获得TCP包内容位置


#endif /* MP_SERVER_ISO_PROTOCOL_H_ */
