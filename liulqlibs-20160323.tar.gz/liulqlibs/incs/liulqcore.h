#ifndef LIULQCORE_H_
#define LIULQCORE_H_
#include <sys/types.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/epoll.h>
#include <time.h>
#include <pthread.h>

//--定义错误状态,调试时需要显示的错误奖态信息
#define D_DEBUG				4
#define D_INFO				3
#define D_WARN				2
#define D_ERROR				1
#define D_EXIT				0

#define MAX_COMMAND_LEN				256//命令行最大长度
#define MAX_FILEADDR_LEN			128//文件地址长度
#define MAX_IPADDR_LEN				30//IP地址的最大长度
#define MAX_EVENT_NUMBER 			128//最大事件窗口

#define SET_BUFFER(buf, src, l) {\
	memcpy((buf), (src), (l));\
	buf[l] = 0;\
} while(0)
#define PARSE_INT_OF(a,v,l)  {\
	char tv[l + 1];\
	memset(tv, 0, sizeof(tv));\
	memcpy(tv, v, l);\
	a = atoi(tv);\
}while(0)

//
//#ifdef __cplusplus
//extern "C" {
//#endif

typedef struct vdata_struct{//一段数据及长度标识
	char *addr;//数据开始地址
	unsigned int  length;//数据长度
} vdata_t;
typedef struct vregion_struct {//--标识一段数据区间
	unsigned int start;//--字段值位置
	unsigned int length;//值的长度
} vregion_t;
typedef struct vsegment_struct {//--数据段
	unsigned int start;//--字段值位置
	unsigned int finish;//值的长度
} vsegment_t;
typedef struct vfield_struct {
	vsegment_t key;
	vsegment_t val;
} vfield_t;


typedef struct memory_buffer_struct {//--读取数据回调结构
	int length, position;
	unsigned char* buffer;
} membuffer_t;

extern membuffer_t* membuffer_alloc(unsigned int len);//申请一个membuffer_t结构缓存区,len申请缓存区大小
extern int  membuffer_write(membuffer_t *o, const void* data, unsigned int len);//向缓存区写数据
extern int  membuffer_writes(membuffer_t *o, const char* data);//向缓存区写数据
extern void membuffer_free(membuffer_t *o);//回收缓存区

//--dbuffer_t*************************************************
typedef struct dbuffer_struct {
	pthread_mutex_t	lock;//互斥锁
	unsigned int bytecnt;//use byte
	unsigned int maxpgs;//max page count
	void **pgs;//page list
	unsigned short pgsize;//page size
} dbuffer_t;
extern dbuffer_t* dbuffer_alloc(unsigned int msize, unsigned short psize);//
extern char dbuffer_initialize(dbuffer_t *o, unsigned int msize, unsigned short psize);
extern int dbuffer_pages(dbuffer_t *o);//
extern char dbuffer_page(dbuffer_t *o, int i, vdata_t* v);//
extern int dbuffer_write(dbuffer_t *o, const void* data, unsigned int len);//向缓存区写数据
extern int  dbuffer_writes(dbuffer_t *o, const char* data);//向缓存区写数据
extern unsigned int dbuffer_read(dbuffer_t *o, void* buffer);
extern unsigned int dbuffer_reset_read(dbuffer_t *o, void* buffer);//读取完后清空数据
char dbuffer_output(dbuffer_t* o);
extern void dbuffer_destory(dbuffer_t *o);
extern void dbuffer_reset(dbuffer_t *o);//重置缓存区
extern void dbuffer_free(dbuffer_t *o);//回收缓存区

//--调试函数区*************************************************
extern void gdb_dump_start(void);//支持gdb调时,可启动该函数跟踪堆栈情况
extern void gdb_mtrace_start(const char* addr);//启动内存泄漏跟踪
extern void gdb_mtrace_finish(void);//结束内存泄漏跟踪
extern void dump_backtrace_start(void);//不支持gdb调时,可启动该函数跟踪堆栈情况

//--以不同格式返回系统时间*************************************************
extern time_t get_time_t(void);//--获得当前时间秒
extern struct tm *get_localtime(void);//--获得当前时间结构体
extern struct tm* to_localtime(time_t t);//转换成时间日期结构体
extern int time_to_integer_ymd(time_t t, unsigned char ymd);//转换成年月日的整数类型
extern int time_to_integer_hms(time_t t, unsigned char hms);//转换成时分秒的整数类型
extern char* time_format(time_t t, char* buffer, int sl);//格式化time_t到字符串缓存中,sl指定字符串长度(仅改文本中部分内容时需指字)
extern char* local_format(char* buffer, int sl);//格式化当前time_t到字符串缓存中,sl指定字符串长度(仅改文本中部分内容时需指字)

//***regex operator**********************************************************
extern int regexpattern_parse(const char* src, const char* pattern, vsegment_t* ovector, int maxln);//正则表达式解析
extern int regexpattern_match(const char* src, const char* pattern, int index, vdata_t *v);//正则匹配数据

//***chars operator**********************************************************
extern char equals_ignore(char a, char b);
extern char buffer_is_null(const unsigned char*buffer, unsigned int len);//--是否为空
extern char buffer_equals(const void*a, const void* b, unsigned int len);//比较内存数据是否相等
extern char buffer_equals_ignore(const void*a, const void* b, unsigned int len);//比较内存数据是否相等
extern int buffer_readline(const char* addr, int* start, int* len);//从缓存中读取一行
extern int buffer_line_length(const char *buffer);//--查找行结尾位置
extern int buffer_indexof(const char*a, const char* b, int offset, int mx);//查找b在a出现的位置,offset是偏移位置

extern char chars_start_with(const char* a, const char* b);//--a是否b开头
extern char chars_start_with_ignore(const char* a, const char* b);//--a是否b开头,忽略大小写比较
extern char chars_end_with(const char* a, const char* b);//--a是否b结尾
extern char chars_end_with_ignore(const char* a, const char* b);//--a是否b结尾,忽略大小写比较
extern int chars_indexof(const char*a, const char* b, int offset);//查找b在a出现的位置,offset是偏移位置
extern int chars_indexof_ignore(const char*a, const char* b, int offset);//查找b在a出现的位置,offset是偏移位置
extern char chars_equals(const char* a, const char* b);//
extern char chars_equals_ignore(const char*a, const char* b);//
extern char buffer_is_numeric(const void* s, int ln);//--判断是否为数字
extern char chars_is_numeric(const char* s);//--判断是否为数字
extern char chars_is_null(const char* buf);//--判断是否为数字
extern char chars_is_empty(const char* s);//判断字符串地址是否为空
extern char char_is_empty(char c);//判断字符c是否为空

extern int chars_to_int(const char *buffer, unsigned char hex, int* result);//将一个字符串解析成数字，仅解析正整数
extern int chars_form_int(char *buffer, unsigned char hex, unsigned char width, int val);//将一个正整数转换成字符串
extern void char_form_hex(char* buffer, unsigned char c) ;//将c的ASCII码转成十六制字符串，保存到buffer中
extern void chars_form_hex(char *buffer, const void* data, int len);//将data中的二制数据转换成十六进制字符串，存放到buffer中
extern short char_to_hex(const char* data);//将两个十六制的字符,解析成一个二进制数
extern int chars_to_hex(void* buffer, const char* data) ;//将十六制的字符串,解析成二进制数
int chars_contact(char *matcheds[], int nmax, char* result, int bufsize, const char const* flag);//连接字符串数组到一个缓存

extern char* to_chars(char* buffer, int i);//将一个正整数转换成一个十进制的字符串
extern int to_integer(const char* buffer);//将一个字符串转换成正整数
extern char* cpyto_lower(char*buffer, const char*src);//转换成小写
extern char* cpyto_lower_part(char*buffer, const char*src, int sln);//指定长度,转换成小写,适合转换部分字符串
extern char* cpyto_upper(char*buffer, const char*src);//转换成大写
extern char* cpyto_upper_part(char*buffer, const char*src, int sln);//指定长度,转换成大写,适合转换部分字符串

//***file operator**********************************************************
extern char file_exists(const char* addr);
extern long file_length(const char* addr);
extern time_t file_last_modify(const char * addr);//--获得文件的最后修改时间
extern struct timespec file_lastmodify(const char * addr);//获得文件的最后修改时间
extern char file_cache_istoday(const char* addr);//检测是否为今天数据
extern char file_cache_isyear(const char* addr);//检测是否为今年数据
extern char file_write_content(const char* addr, const unsigned char* buffer, unsigned int len);//--重写文件内容
extern membuffer_t* file_read_content(const char* addr);//--读取文件内容,内容需要回
extern long file_read_tobuffer(const char*addr, void* buffer);
extern int file_read_top_chars(const char* addr, void *buffer, int len);//--读取文件的前N字节数据
extern int file_write(const char* addr, void* buffer, int len);//覆盖方式打开写文件
extern int file_addbuffer(const char* addr, void* buffer, int len);//追加方式打开写文件
int file_logger(const char* addr, void* buffer, int len);//追加日志方式打开写日志

extern long file_size(const char *addr);//获得文件大小
extern int file_delete(const char* addr);//删除一个文件
extern int file_linecallback(const char* addr, void (* linecallback)(const char*));//文件行回调处理
extern int folder_delete(const char* addr);//删除一个目录
extern char* folder_mappath(const char* original, char* addr);



//***file cache************************************************************************
typedef struct fcache_check_struct {//
	time_t ticks;
	char addr[MAX_FILEADDR_LEN];//缓存文件地址
} fcache_check_t;
extern char fcache_check_timeout(fcache_check_t* o);
extern char fcache_check_onyear(fcache_check_t* o);
extern char fcache_check_onday(fcache_check_t* o);
extern void fcache_check_update(fcache_check_t* o);

typedef struct fcache_struct {
	fcache_check_t file;
	char hasvalue;
	unsigned char* buffer;
} fcache_t;
extern char fcache_initialize(fcache_t* o);
extern void fcache_destory(fcache_t* o);
extern const char* fcache_buffer(fcache_t* o);
extern const char* fcache_buffer_day(fcache_t* o);
extern const char* fcache_buffer_year(fcache_t* o);

typedef void* (*filecache_parse)(void* buf, int len);//缓存文件对象解析

typedef struct filecache_struct {//文件缓存结构体
	time_t tm;//读取时文件修改时间
	char addr[128];//文件地址
	unsigned char* buffer;//缓存数据
	filecache_parse parse;//文件内容解析函数
} filecache_t;
extern void filecache_initialize(filecache_t* o, const char* fname, filecache_parse func);//初始文件缓存对象
extern int filecache_modify(filecache_t* o);//根据修改时间缓存数据
extern unsigned char* filecache_bymodify(filecache_t* o);//根据修改时间缓存数据
extern void filecache_clean(filecache_t* o);//清空缓存数据

//extern int inotify_watch_append(const char* addr, void (*onchage)(void* arg, const char* addr, uint32_t mask), void* arg);//动态文件监控
struct inotifynode_struct;
typedef void (*inotify_onchage)(struct inotifynode_struct* item, uint32_t mask);//inotify响应函数原型
typedef struct inotifynode_struct {//inotify节点
	int wd;//监听ID
	uint32_t mask;//位掩码
	inotify_onchage onchange;//响应函数
	void* arg;//响应函数回调参数
	struct timespec last;//最后时间
	char addr[256];//文件地址
} inotifynode_t;

typedef struct inotifywatch_struct {
	int fd;//启动是生成的内部ID
	pthread_t threadid;//线程ID
	inotifynode_t nodes[];//节点列表
} inotifywatch_t;//检测文件集合

extern int inotifywatch_startup(inotifywatch_t* o);//启动检测


//****队例操作**************************************************************************
//--线程工作链表
typedef  struct  seqlink_struct{
	void *arg;//链表数据
	struct seqlink_struct *prev,*next;//链表的上一个与下一个指针
} seqlink_t;

//**链表及操作方法******************************************************************
//--链表结构体
typedef struct linked_list_struct {
	pthread_mutex_t		lock;//互斥锁
	seqlink_t    		*head;//任务链表结构,存储所有等待任务
	seqlink_t			*current;//枚举的当前选茂
	seqlink_t			*last;//链表的尾部
    int					length ;//当前任务链表中的任务数目
} linked_list_t;

extern void linked_list_initialize(linked_list_t *o);//初始化链表结构
extern int linked_list_destory(linked_list_t *o);//释放链表中记录
extern int linked_list_push(linked_list_t *o, void *arg);//--向链表添加一个任务
extern void *linked_list_indexof(linked_list_t *o, int i);//获得指定记录
extern void linked_list_remove_current(linked_list_t *o);//删除当前记录
extern char linked_list_next(linked_list_t *o);//是否有下一条记录
extern char linked_list_prev(linked_list_t *o);//是否有上一条记录
extern void *linked_list_entry(linked_list_t *o);//获得记录数据
extern void linked_list_reset(linked_list_t *o);//重置链表记录
extern void linked_list_lock(linked_list_t *o);//锁定链表
extern void linked_list_unlock(linked_list_t *o);//解锁链表



//**链表队列结构体******************************************************************
typedef struct linked_queue_struct {
	pthread_cond_t	ready;//条件变量
	linked_list_t	items;//链表数据
} linked_queue_t;

extern void linked_queue_initialize(linked_queue_t *o);//链表队列初始化
extern void linked_queue_destory(linked_queue_t *o);//销毁链表队列
extern int  linked_queue_push(linked_queue_t *o, void *arg);//--向队例压入一个数据
extern void *linked_queue_pop(linked_queue_t *o);//--从队列上弹出一个数据
extern void linked_queue_wait(linked_queue_t *o);//等待队列上有数据压入
extern void linked_queue_lock(linked_queue_t *o);//给队例加锁
extern void linked_queue_unlock(linked_queue_t *o);//给队例解锁



//**线程池操作对象******************************************************************
//--线程池结构体
typedef struct thread_pool_struct{
	pthread_t	*threadid;//线程标数组,用于存放线程ID
	linked_queue_t queue;//线程池队列
	void*		(*execute)(void *arg);//执行函数
	int			max_thread_num;//线程池中允许的活动线程数目
	int			shutdown;//标志变量,是否要销毁线程池
} thread_pool_t;

extern void thread_pool_initialize(thread_pool_t* o);//初始化对象
extern void thread_pool_destory(thread_pool_t* o);//销毁对象
extern int  thread_pool_listern(thread_pool_t* o, int num, void* (*handle)(void *arg));//开始线程池监听
extern int  thread_pool_join(thread_pool_t* o);//等待线程执行完成
extern int  thread_pool_task_push(thread_pool_t* o, void* arg);//向线程池添加任务



//---GDB 命令回调函数***********************************************
extern char gdb_log_allow(int level, const char* fladdr);//--是否需要输出信息
extern void gdb_log_printf(const char* fl, int ln);//--打印日志时,显示的文件信息


typedef void(*gdbfunc_t)(int argc, char* argv[]);//调试命令回调函数
typedef struct gdbcmd_struct {//--调试信息输出命令行结构
	gdbfunc_t func;
	const char* name;
	const char* text;
} gdbcmd_t;
typedef struct gdbentry_struct {//--调试实体对象结构体
	int level;//当前的调试级别
	int state;//{1:时间,2:时间+文件,3:时间+文件+行}是否显示时间与文件行信息
	linked_list_t commads;//命令列表
	linked_list_t filemask;//屏闭文件列表
} gdbentry_t;

extern gdbentry_t gdbentry;//GDB调试设置对象
extern int parameter_parse(char *s, int argvsz, char *argv[]);//--解析命令行参数
extern void gdbentry_initialize(void);//全局数据初始化
extern void gdbentry_destory(void);//销毁
extern int  gdbentry_execute(char *line);//--执行命令
extern void gdbentry_function(gdbfunc_t cmd, const char *label, const char* text);//--添加命令

//**ini config******************************************************************
typedef char (* ini_item)(void* par, const char* key, const unsigned int klen, const char *val, const unsigned int vlen);
extern int iniconfig_load(const char* addr, ini_item func, void* par);
//**page control******************************************************************
typedef struct pager_struct {
	int rcount;//记录总条数
	int total;//总页数
	int start;//分页码开始
	int end;//分页码结束
	int current;//当前分页
	int pgsize;//page size
	int pgrsize;//page button count
} pager_t;
extern char pager_calculation(pager_t* o,  int rcnt, int offset);
extern int pager_max(int count, int psize);//--取得最大页码数

/***哈希****************************************/
typedef struct hashvoidmap_struct {//哈希结构体
	int maxsize;//最大个数
	void* buffer[];//缓存数据
} hashptrmap_t;

extern hashptrmap_t* hashptrmap_initialize(int m);//初始化哈希
extern void hashptrmap_set(hashptrmap_t* o, int i, void* item);//设置数据
extern void* hashptrmap_get(hashptrmap_t* o, int i);//获的数据

//***************************
typedef struct hashelement_struct{//哈希元素结构体
    void* key;//键名
    void* val; //键值
	time_t time;//加入队列的时间
    struct hashelement_struct *next;       /*下个节点*/
} hashelement_t;

struct hashmap_struct;
typedef int  (*hash_callback_each)(void*o,  hashelement_t* b);//循环枚举
typedef int  (*hash_callback_compare)(const void* a, const void* b);
typedef void (*hash_callback_bind)(hashelement_t* o, const void* b);
typedef  uint16_t (*hash_callback_hash)(const void* b, uint32_t msize);
typedef struct hashmap_struct{//哈希操作结构体
    int size;//大小
    int count;//记录个数
	pthread_mutex_t		lock;//互斥锁
    hash_callback_compare compare;//比较函数;
    hash_callback_bind bindkey;//绑定键名到对象
    hash_callback_hash hashkey;;//哈希函数
    hashelement_t* table[];//哈希数组
} hashmap_t;

extern hashmap_t* hashmap_create(int size, hash_callback_compare compare, hash_callback_hash hashkey, hash_callback_bind bindkey);//创建存储汇聚流需要的哈希table
extern hashmap_t* hashmap_create_int32(int size); //创建存储汇聚流需要的哈希table
extern hashmap_t* hashmap_create_string(int size); //创建存储汇聚流需要的哈希table
extern int hashmap_addint32(hashmap_t* o, const void* key,  int val);//添加key及数据
extern int hashmap_addint64(hashmap_t* o, const void* key,  int64_t val);//添加key及数据
extern int hashmap_addstring(hashmap_t* o, const void* key,  const char const* val);//添加key及数据
extern int hashmap_additem(hashmap_t* o, const void* key,  const void* val, uint32_t vln);//添加key及数据
extern int hashmap_addpointer(hashmap_t* o, const void* key,  void* val);//添加key及数据
extern int hashmap_delitem(hashmap_t* o, const void* key);//删除key及数据
extern void hashmap_destory(hashmap_t* o);//销毁对象

extern void* hashmap_find(hashmap_t* o, const void* key);//哈希值
extern int hashmap_contains(hashmap_t* o, const void* key);//哈希包含键名
extern int hashmap_equals_int32(hashmap_t* o, void* k, int v);//哈希值等于
extern int hashmap_equals_string(hashmap_t* o, void* k, char* v);//哈希值等于
extern int hashmap_each(hashmap_t *o, hash_callback_each callback, void* arg);//循环枚举
extern int hashmap_count(hashmap_t* o);//记录条数

typedef struct hashbuffer_struct {//分配一个缓存,在该缓存上建立哈希
    int bufsize;//数据缓存区大小
    uint16_t bufpos;//缓存区位置
    uint8_t *buffer;//指向数据缓存区
    hashmap_t map;//哈希表
} hashbuffer_t;
extern int hashbuffer_sizeof(int size, int bsize);
extern hashbuffer_t* hashbuffer_create(int size, int bsize);
extern hashbuffer_t* hashbuffer_initialize(void*buffer, int size, int bsize);
extern void hashbuffer_destory(hashbuffer_t* o);
extern int hashbuffer_add(hashbuffer_t* o, const void const* key,  const char const* val);//添加key及数据
extern void hashbuffer_clean(hashbuffer_t* o);//清除所有数据
//************************************
extern void* hashbuffer_find(hashbuffer_t* o, const void* key);//哈希值
extern int hashbuffer_contains(hashbuffer_t* o, const void* key);//哈希包含键名
extern int hashbuffer_equals_int32(hashbuffer_t* o, void* k, int v);//哈希值等于
extern int hashbuffer_equals_string(hashbuffer_t* o, void* k, char* v);//哈希值等于
extern int hashbuffer_each(hashbuffer_t *o, hash_callback_each callback, void* arg);//循环枚举
extern int hashbuffer_count(hashbuffer_t* o);//记录条数

/***pipelistern_t,命名管道通信************************/
//管道执行命令结构体
typedef struct pipexecute_struct {
#define MAX_FUNC_NAME 32
	gdbfunc_t func;//函数
	char name[MAX_FUNC_NAME];//名称
} pipexecute_t;
//命名管道监听结构体
typedef struct pipelistern_struct {
#define MAX_PIPE_PATH 32
	char path[MAX_PIPE_PATH];//管道名称
	pthread_t thread;//线程ID
	char inloop;//管道线程是否在运行
	pipexecute_t *commads;//执行命令列表
} pipelistern_t;

void pipelistern_start(pipelistern_t* o, pipexecute_t *cmds);//启动管道监听函数
void pipelistern_join(pipelistern_t* o);//
/* 实例
pipelistern_t namedpipe = { path = "/dev/pipe1" };
gdbcmd_t pipe_execs[] = {
		{ .name = "update", .func=NULL },
		{ .name = "select", .func=NULL },
		NULL
};
void example()
{
	pipelistern_start(&namedpipe, pipe_execs);
}
*/

//**sigtimer_t定时器触发*************************************************************
typedef void(*sigtimer_cbk)(int t);//定时报警回调函数
//定时报警结构体
typedef struct sigtimer_struct {
	sigtimer_cbk func;//执行函数
	struct sigtimer_struct *next;//下一个对象
} sigtimer_t;

void sigtimer_start(int second);//启动定时器
void sigtimer_add_start(sigtimer_cbk cbk, int second);//添加定时函数并启动定时器
void sigtimer_add(sigtimer_cbk cbk);//添加定时函数
void sigtimer_remove(sigtimer_cbk cbk);//删除定时函数
void sigtimer_destory();//


//**threadpool_t线程池*************************************************************
//链表头结构体
struct list_head {
    struct list_head *next;//下一个结节
    struct list_head *prev;//上一个结点
};
//线程池实体结构体
typedef  struct   threadpool_entry_struct{
	time_t tm;//入列时间
	void *dat;//链表数据
	struct list_head list;
}  threadpool_entry_t;
//线程池结构体
typedef struct threadpool_struct{
	pthread_t	*threadid;//线程标数组,用于存放线程ID
	pthread_cond_t	ready;//条件变量
	pthread_mutex_t		lock;//互斥锁
	 struct list_head queue;//线程池队列
	uint32_t queuelen;
	void		(*execute)(void *arg);//执行函数
	uint8_t			max_thread;//线程池中允许的活动线程数目
	uint8_t			shutdown;//标志变量,是否要销毁线程池
	uint8_t 			pause;//暂停运行
} threadpool_t;

extern int threadpool_listern(threadpool_t* o, int num, void  (*handle)(void *arg));//开始线程池监听
extern void threadpool_destory(threadpool_t* o);//销毁线程池
extern int threadpool_join(threadpool_t* o);//等待线程执行完成
extern void* threadpool_task_alloc(threadpool_t* o, int size);//向线程池申请任务空间

//#ifdef __cplusplus
//}
//#endif

#endif /* LIULQCORE_H_ */
