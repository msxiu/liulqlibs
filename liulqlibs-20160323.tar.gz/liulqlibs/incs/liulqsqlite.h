﻿/*
 * liulqsqlite.h
 *
 *  Created on: 2016年1月12日
 *      Author: root
 */

#ifndef SHAREDLIBS_INCS_LIULQSQLITE_H_
#define SHAREDLIBS_INCS_LIULQSQLITE_H_
#include <sqlite3.h>
#include <liulqcore.h>

//#ifdef __cplusplus
//extern "C" {
//#endif


typedef struct sqlitequery_struct {
	sqlite3* db;
	sqlite3_stmt* stmt;
	dbuffer_t conds;
	linked_list_t paras;
} sqlitequery_t;
extern void sqlitequery_destory(sqlitequery_t* o);
extern int sqlitequery_condition(sqlitequery_t* o, const char* fmt,...);
extern int sqlitequery_tail(sqlitequery_t* o, const char *fmt, ...);
extern int sqlitequery_para_integer(sqlitequery_t* o, int v);
extern int sqlitequery_para(sqlitequery_t* o, const char* v);

extern char sqlitequery_prepare(sqlitequery_t* o, const char* fmt,...);
extern int sqlitequery_recordcount(sqlitequery_t* o, const char* sql);
extern char sqlitequery_execute(sqlitequery_t* o);
extern char sqlitequery_next(sqlitequery_t* o);
extern char sqlitequery_reset(sqlitequery_t* o);
extern char sqlitequery_restart(sqlitequery_t* o);
extern int sqlitequery_vtype(sqlitequery_t* o, int i);
extern int sqlitequery_vlength(sqlitequery_t* o, int i);//--获得字段长度
extern int sqlitequery_columnint (sqlitequery_t* o, int i);
extern const char *sqlitequery_columnchars (sqlitequery_t* o, int i);
extern const void * sqlitequery_column(sqlitequery_t* o, int i);
extern char  sqlitequery_columnhex(sqlitequery_t* o, int i, void* buffer);




typedef struct sqlitedb_struct{
	sqlite3* db;
	const char* faddr;
	const char* tables;
	const char* indexs;
} sqlitedb_t;
extern char sqlitedb_open(sqlitedb_t* o);
extern void sqlitedb_close(sqlitedb_t* o);
extern sqlitequery_t* sqlitedb_statement(sqlitedb_t* o);
extern int sqlitedb_execute(sqlitedb_t* o, const char* sql,...);
extern const char* sqlitedb_errmsg(sqlitedb_t* o);
extern char sqlitedb_begin (sqlitedb_t* o);
extern char sqlitedb_commit(sqlitedb_t* o);
extern char sqlitedb_rollback(sqlitedb_t* o);

//#ifdef __cplusplus
//}
//#endif


#endif /* SHAREDLIBS_INCS_LIULQSQLITE_H_ */
