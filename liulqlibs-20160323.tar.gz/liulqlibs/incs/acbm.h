/*
 * acbm.h
 *
 *  Created on: 2015-12-30
 *      Author: Administrator
 */

#ifndef ACBM_H_
#define ACBM_H_
#include "liulqcore.h"

#define PATTERN_LEN 256


struct acbmtree_struct;
typedef void*(*acbmtree_alloc)(struct acbmtree_struct *o, size_t ln);//内存申请函数

typedef struct _pattern_tree_node {//关键词节点树
	int label;// lable 记录字串来自于初始化数组的第几个输入字串
	int depth;//关建词首字母到当前字母的深度
	unsigned char ch;//节点对应的字符
	int GSshift;
	int BCshift;
	unsigned char one_child;
	struct _pattern_tree_node *childs[256];//子节点
	int nchild;//子节点个数
	struct _pattern_tree_node *parent;//父节点
} pattern_tree_node;

typedef struct _pattern_data {//一个匹配关键词
	unsigned char data[PATTERN_LEN] ;//匹配关键词
	int len ;//关键词长度
} pattern_data ;

typedef struct acbmtree_struct {//编译生成好的匹配关键词对象树
	pattern_tree_node *root;// 树根节点
	int max_depth;//最大字串深度
	int min_pattern_size;//最短的字串长度
	int BCshift[256];//字符在关键词列表中首次出现的位置

	pattern_data *pattern_list;//指向节点数组第一个字串的指针
	int pattern_count;// 包含的字串个数
	acbmtree_alloc memalloc;//内存申请函数
	int buflen, bufpos;//内存位置
	char buffer[];//指向尾部空间
} acbmtree_t;

typedef struct _matched_info {//匹配结果单元
	int pattern_i;//pattern_data关键词数组下标
	unsigned long offset ;//在文本中的位置
} matched_info_t ;

typedef struct acbmftree_struct {//
	filecache_t cache;
	acbmtree_t *tree;
} acbmftree_t;


/** acbm树关键词重置
 * @ptree acbm树
 * @argc 关键词对象个数
 * @argv 关键词对象列表
*/
 extern void acbmtree_resetkeys (acbmtree_t *ptree, int argc, char* argv[]);
extern acbmtree_t* acbmtree_create(int argc, char* argv[]);//初始化AC树
extern acbmtree_t* acbmtree_initialize(void* buffer, int buflen, int argc, char* argv[]);//在指定缓存区初始化AC树
extern void acbmtree_destory(acbmtree_t *o);//销毁对象
/**从指定的多模匹配树中搜索关键词
 * @ptree 编译好的关键词树
 * @text 文本字符串
 * @tlen 文本字符串长度
 * @matcheds 匹配到的关键词结果
 * @nmax 允许匹配的最大个数
 * @nmatched 存放结果的位置
 */
extern int acbmtree_search(acbmtree_t *o, unsigned char *text, int tlen, matched_info_t matcheds[], int nmax, int nmatched);
/**指定节点树进行匹配
 * @o 匹配树对象
 * @text 检测文本
 * @tlen 文本长度
 * @keys 关键词接收缓冲区
 * @nmax 关键词接收缓冲区大小
 * @pos 存放位置
 *@nreply:1去重复,0不去重复
 */
extern int acbmtree_searchkey(acbmtree_t *o, unsigned char *text, int tlen, char* keys[], int nmax, int pos, int nreply);

extern void acbmtree_notify_change(struct inotifynode_struct* o, uint32_t t);//acbmtree_t通知改变响应函数
extern int acbmtree_inotify(inotifywatch_t* o);//acbm文件动态通知加载
extern int acbmftree_initialize(acbmftree_t* o);//动态加载文件的ACBM缓存

#endif /* ACBM_H_ */
