﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"

char *httpd_mappath(httpd_t *o, const char* addr, char *target)//映射地址
{
	sprintf(target, ('/' == addr[0] ? "%s%s" : "%s/%s"), o->config->root, addr);//转换成绝对地址
	return target;
}
char *httpd_maptemplate(httpd_t* o, const char* addr, char* target)//映射模板
{
	sprintf(target, ('/' == addr[0] ? "%s%s" : "%s/%s"), o->config->module, addr);//转换成绝对地址
	return target;
}
const char* httpd_encoding(httpd_t* o)//获得字符编码
{
	return o->config->encoding;
}


int  httpd_initialize(httpd_t *o)
{
	GDB_DEBUG("httpd_initialize;\n");
	int i=0, p = 0, headlen=0, bodylen = 0;
	int rbodylen = 0, icnt = 0;
	char* hv;
	char buffer1[128], buffer[128];

	hv = o->request.header;
	GDB_DEBUGS("httpd_initialize by socket id %d;\n", o->client.connfd);
	headlen=http_read_header(o->client.connfd, hv);
	o->request.vhead = headlen;
	GDB_DEBUGS("read %d byte header!\n", o->request.vhead);
	if(headlen <= 0) return 0;

	while(headlen && hv[i] != ' ') {i++; headlen--;}
	o->request.method.finish = i++;
	o->request.uri.start = i;
	while(headlen && hv[i] != ' ') {i++; headlen--;}
	o->request.uri.finish = i++;
	while(headlen && hv[i] != '\n') {i++; headlen--;}
	i++;
	icnt = o->request.method.finish - o->request.method.start;
	SET_BUFFER(buffer, o->request.header + o->request.method.start, icnt);
	icnt = o->request.uri.finish - o->request.uri.start;
	SET_BUFFER(buffer1, o->request.header + o->request.uri.start, icnt);
	GDB_INFOS("http %s (%s:%d) by '%s'!\n", buffer, o->client.ipaddr, o->client.port, buffer1);

	while(headlen>=0) {//解析头数据
		if(o->request.headcnt >= MAX_HTTP_HEADS) break;
		vfield_t *item = &(o->request.headers[o->request.headcnt]);
		item->key.start = i;
		while(headlen && hv[i] != ':') {i++; headlen--;}
		item->key.finish = i;
		i+=2;
		item->val.start = i;
		while(headlen && hv[i] != '\n') {i++; headlen--;}
		if(i > item->val.start) {
			item->val.finish = i-1;
			SET_BUFFER(buffer, hv+item->key.start, item->key.finish - item->key.start);
			GDB_DEBUGS("%d:%s{%d,%d: %d,%d}\n", o->request.headcnt, buffer, item->key.start, item->key.finish, item->val.start, item->val.finish);
			o->request.headcnt++;
		}
		i++;
		headlen--;
	}
	i=o->request.uri.start; p=0;
	while(i < o->request.uri.finish) {
		if(hv[i] == '?'){
			GDB_DEBUGS("find query string of %d;\n", i);
			p=i; break;
		}
		i++;
	}
	if(p>0){//路径中提交有参数需要处理
		o->request.query.start = p+1;
		o->request.query.finish = o->request.uri.finish;
		o->request.uri.finish = p;
		GDB_DEBUGS("add url parameter %d=>%d!\n", o->request.query.start, o->request.query.finish);
		httpreq_addparam(o, 0);
	}

	vsegment_t t_seg;
	if(httpreq_header_segment(o, "Cookie", &t_seg)) {
		httpreq_addcookies(o, &t_seg);
	}
	vdata_t t_data;
	if(httpreq_header(o, "Content-Length", &t_data)) {
		SET_BUFFER(buffer, t_data.addr, t_data.length);
		bodylen = atoi(buffer);
		GDB_DEBUGS("form data %d byte;\n", bodylen);
	}
	if(bodylen>0) {
		o->request.body =(char*) malloc(bodylen + 10);
		memset(o->request.body, 0, bodylen + 10);
		o->request.vbody = socketc_read(&(o->client), o->request.body, bodylen);
		httpreq_addparam(o, 1);
		GDB_DEBUGS("%d:'%s'!\n", bodylen, o->request.body);
	} else {
		o->request.body = NULL;
	}
	dbuffer_initialize(&(o->response.body), 2048000, 10240);
	GDB_DEBUG("finished httpd_initialize;\n");
	return 1;
}
void httpd_destory(httpd_t* o)
{
	if(NULL != o->request.body && o->request.vbody > 0) {
		GDB_DEBUGS("free o->request.body by %p:%d;\n", o->request.body, o->request.vbody);
		free(o->request.body);
	}
	dbuffer_free(&(o->response.body));
}

