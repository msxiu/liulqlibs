﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"

int httpreq_addparam(httpd_t *o, char tpid) {//tpid{0:query,1:form}
	const char* str = (tpid ? o->request.body : o->request.header + o->request.query.start);
	int is=0, ie=0, iq = 0, ic = 0, bi = (tpid ? o->request.vhead : o->request.query.start),
			il=(tpid ? strlen(o->request.body) : o->request.query.finish - o->request.query.start);
	GDB_DEBUGS("addParameters %d byte data!\n", il);
	while(ie < il) {
		if(o->request.paracnt >= MAX_HTTP_PARA) return o->request.paracnt;
		if(str[ie] == '=') iq = ie;
		if(str[ie] == '&'){
			if(iq > is && ie > iq){
				vfield_t* item = &(o->request.paras[o->request.paracnt]);
				item->key.start = (bi + is);
				item->key.finish = (bi + iq);
				item->val.start = (bi+ iq + 1);
				item->val.finish = (bi + ie);
				o->request.paracnt++;
			}
			is = ie + 1;
		}
		ie++;
	}
	if(iq > is && ie > iq && o->request.paracnt < MAX_HTTP_PARA){
		vfield_t* item = &(o->request.paras[o->request.paracnt]);
		item->key.start = (bi + is);
		item->key.finish = (bi + iq);
		item->val.start = (bi+ iq + 1);
		item->val.finish = (bi + ie);
		o->request.paracnt++;
	}
	return o->request.paracnt;
}
int httpreq_addcookies(httpd_t *o, vsegment_t *cookie)
{
	int is=0, ie=0, iq = 0, bi = cookie->start, il= (cookie->finish - bi);
	char str[il + 10];
	memcpy(str, o->request.header + bi, il);
	str[il] = 0;
	GDB_DEBUGS("addCookies:'%s'\n", str);
	while(ie < il) {
		if(o->request.cookcnt >= MAX_HTTP_TAGS)  return o->request.cookcnt;
		if(str[ie] == '=') iq = ie;
		if(str[ie] == ';'){
			if(iq > is && ie > iq){
				vfield_t* item = &(o->request.cookies[o->request.cookcnt]);
				item->key.start = (bi + is);
				item->key.finish = (bi + iq);
				item->val.start = (bi+ iq + 1);
				item->val.finish = (bi + ie);
				o->request.cookcnt++;
			}
			is = ie + 1;
		}
		ie++;
	}
	if(iq > is && ie > iq && o->request.cookcnt < MAX_HTTP_TAGS){
		vfield_t* item = &(o->request.cookies[o->request.cookcnt]);
		item->key.start = (bi + is);
		item->key.finish = (bi + iq);
		item->val.start = (bi+ iq + 1);
		item->val.finish = (bi + ie);
		o->request.cookcnt++;
	}
	return o->request.cookcnt;
}
//****************************************************
char httpreq_header(httpd_t* o,  const char* key,  vdata_t* v)
{
	int i=0, sln = strlen(key), iln;
	for(;i<o->request.headcnt;i++) {
		vfield_t item = o->request.headers[i];
		iln = item.key.finish - item.key.start;
		if(sln == iln && buffer_equals(key, o->request.header + item.key.start, iln)) {
			v->addr = (o->request.header + item.val.start);
			v->length = (item.val.finish - item.val.start);
			return 1;
		}
	}
	return 0;
}
char httpreq_header_segment(httpd_t* o,  const char* key, vsegment_t* v)
{
	int i=0, sln = strlen(key), iln;
	for(;i<o->request.headcnt;i++) {
		vfield_t item = o->request.headers[i];
		iln = item.key.finish - item.key.start;
		if(sln == iln && buffer_equals(key, o->request.header + item.key.start, iln)) {
			v->start = item.val.start;
			v->finish = item.val.finish;
			return 1;
		}
	}
	return 0;
}
char httpreq_para(httpd_t* o,  const char* key, vdata_t* v)
{
	int i=0, sln = strlen(key), iln;
	for(;i<o->request.paracnt;i++) {
		vfield_t item = o->request.paras[i];
		iln = item.key.finish - item.key.start;
		if(sln != iln) continue;
		if(item.key.start >= o->request.vhead){//form
			int start = (item.key.start - o->request.vhead);
			if(buffer_equals_ignore(key, o->request.body + start, iln)) {
				v->addr = (o->request.body + (item.val.start - o->request.vhead));
				v->length = (item.val.finish - item.val.start);
				return 1;
			}
		} else {//query
			if(buffer_equals_ignore(key, o->request.header + item.key.start, iln)) {
				v->addr = (o->request.header + item.val.start);
				v->length = (item.val.finish - item.val.start);
				return 1;
			}
		}
	}
	return 0;
}
int  httpreq_para_integer(httpd_t* o,  const char* key)
{
	int result = 0;
	vdata_t* item;
	if(httpreq_para(o, key, item)) {
		char buffer[item->length + 4];
		SET_BUFFER(buffer, item->addr, item->length);
		result = atoi(buffer);
	}
	return result;
}
char httpreq_cookie(httpd_t* o, const char* key, vdata_t* v)
{
	int i=0, sln = strlen(key), iln;
	for(;i<o->request.cookcnt;i++) {
		vfield_t item = o->request.cookies[i];
		iln = item.key.finish - item.key.start;
		if(sln == iln && buffer_equals(key, o->request.header + item.key.start, iln)) {
			v->addr = (o->request.header + item.val.start);
			v->length = (item.val.finish - item.val.start);
			return 1;
		}
	}
	return 0;
}
