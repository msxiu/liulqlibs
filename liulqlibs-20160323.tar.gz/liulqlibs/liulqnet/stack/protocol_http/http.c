﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"
#define MAX_HTTP_HEAD		1400
#define MAX_HEADER(x)			(x>MAX_HTTP_HEAD ? MAX_HTTP_HEAD : x)

#define HTTP_MIME_DEFAULT "text/html"

/*--进行http协议判断
char http_comfirm(const char *data)
{
    int index = 0;
    while(data[index] != '\0' && data[index] != '\n') index++;
    return (strncmp(data + index - 10, "HTTP/", 5) == 0 ? 1 : 0) ;
}
*/
char http_comfirm(const char *p)//判断缓存流是否为HTTP协议
{
	int pos =0, method = 0, url = 0;
	while(pos < MAX_HTTP_HEAD && p[pos] != '\0' && p[pos] != '\n') {
		if(p[pos] == ' ') {
			if(!method) {
				method = pos;
			} else {
				url = pos;
			}
		}
		pos++;
	}
	if(p[pos] != '\n' || pos>= MAX_HTTP_HEAD || !method || !url) return 0;
	if (0 == strncmp((p + url + 1), "HTTP/", 5))  return 1;
	if(0 == strncmp(p, "HTTP/", 5)) return 2;
	return 0;
}

char http_protocol_start(const char*p, int sln)//HTTP协议头识别
{
	if(!p||!*p) return 0;
	const char * p1 = (p+1);
	switch(*p) {
	case 'H'://HEAD|HTTTP/
		if(sln > 5 && buffer_equals(p1, "TTP/", 4)) return 2;//响应
		if(sln > 5 && buffer_equals(p1, "EAD ", 4) ) return 1;//HEAD请求
		break;
	case 'G'://GET
		if(sln > 4 && buffer_equals(p1, "ET ", 3)) return 1;
		break;
	case 'P'://POST|PUT
		if((sln > 5 && buffer_equals(p1, "OST ", 4)) || (sln > 4 && buffer_equals(p1, "UT ", 3))) return 1;
		break;
	case 'O'://OPTIONS
		if(sln > 8 && buffer_equals(p1, "PTIONS ", 7)) return 1;
		break;
	case 'D'://DELETE
		if(sln > 7 && buffer_equals(p1, "ELETE ", 6)) return 1;
		break;
	case 'T'://TARCE
		if(sln > 6 && buffer_equals(p1, "ARCE ", 5)) return 1;
		break;
	}
	return 0;
}
char http_discern(const char*p, int sln)//HTTP协议识别
{
	int state = http_protocol_start(p, sln);
	int pos =0, method = 0, url = 0, len = MAX_HEADER(sln);
	switch(state) {
	case 2://HTTP应答
		while(p[pos] && p[pos] != ' ') pos++;
		method = pos++;
		while(p[pos] && p[pos] != ' ') pos++;
		if((pos - method - 1) != 3) return 0;
		if(buffer_is_numeric(p+method + 1, 3)) return state;
		break;
	case 1://HTTP请求
		while(pos < len && p[pos] && p[pos] != '\n') {
			if(p[pos] == ' ') {
				if(!method) {
					method = pos;
				} else {
					url = pos;
				}
			}
			pos++;
		}
		if(pos>= len || p[pos] != '\n' || !method || !url) return 0;
		if (0 == strncmp((p + url + 1), "HTTP/", 5))  return state;
		break;
	}
	return 0;
}
//--返回UTC格式时间
char* http_time_now(char *time_buf)
{
   time_t    now_sec;
    time(&now_sec) ;
    return http_time(time_buf, now_sec);
}
//--返回UTC格式时间
char* http_time(char* time_buf,  time_t src)
{
	static const char wda[7][4] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
	static const char moa[12][4] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
    struct tm    *t;
    t = gmtime(&src);
	sprintf(time_buf, "%.3s %.3s%3d %.2d:%.2d:%.2d %d",
			wda[t->tm_wday], moa[t->tm_mon], t->tm_mday, t->tm_hour, t->tm_min,  t->tm_sec, 1900 + t->tm_year);
    return time_buf;
}

//--根据URL返回数据类型
const char* http_mime_type(char *uri)
{
    int len = strlen(uri);
    int dot = len - 1;
    while( dot >= 0 && uri[dot] != '.') dot--;
    if(dot <= 0) return HTTP_MIME_DEFAULT;
    dot++;
    char *tpo = uri + dot;
    switch(len - dot) {
        case 4:
         if(chars_equals(tpo, "html")) return HTTP_MIME_DEFAULT;
         if(chars_equals(tpo, "jpeg")) return "image/jpeg";
         break;
        case 3:
         if(chars_equals(tpo, "htm")) return HTTP_MIME_DEFAULT;
         if(chars_equals(tpo, "css")) return "text/css";
         if(chars_equals(tpo, "png")) return "image/png";
         if(chars_equals(tpo, "jpg")) return "image/jpeg";
         if(chars_equals(tpo, "gif")) return "image/gif";
         if(chars_equals(tpo, "ico")) return "image/x-icon";
        if(chars_equals(tpo, "txt")) return "text/plain";
         break;
        case 2:
         if(chars_equals(tpo, "js")) return "text/javascript";
         break;
        default:
         return HTTP_MIME_DEFAULT;
         break;
    }
    return HTTP_MIME_DEFAULT;
}

char http_ishtml(char *uri)
{
	return ((0 == strcmp(http_mime_type(uri), HTTP_MIME_DEFAULT)) ? 1 : 0);
}

int http_read_header(int fd, char* hv) //读取HTTP头数据
{
	GDB_DEBUG("http_read_header\n");
	int retval = 0;
	while(1) {
		if(1 != read(fd, hv+retval, 1)) break;
		if(retval>3 && hv[retval] == '\n' && hv[retval - 1] == '\r' && hv[retval - 2] == '\n' && hv[retval - 3] == '\r') break;
		retval++;
	}
	hv[retval] = 0;
	return retval;
}

/********************************************************************************************/
int httpbuffer_comfirm(httpbuffer_t *o)//判断缓存流是否为HTTP协议
{
	const char* p = o->data;
	int state = http_protocol_start(p, o->length);
	int pos =0, len = MAX_HEADER(o->length);
	switch(state) {
	case 2://HTTP应答
		while(p[pos] && p[pos] != ' ') pos++;
		o->method = pos++;
		while(p[pos] && p[pos] != ' ') pos++;
		if((pos - o->method - 1) != 3) return 0;
		if(buffer_is_numeric(p+o->method + 1, 3)) return state;
		break;
	case 1://HTTP请求
		while(p[pos] && pos < len && p[pos] != '\n') {
			if(p[pos] == ' ') {
				if(!o->method) {
					o->method = pos;
				} else {
					o->url = pos;
				}
			}
			pos++;
		}
		o->varsion = pos;
		if(p[pos] != '\n' || pos>= len || !o->method || !o->url) return 0;
		if (0 == strncmp((p + o->url + 1), "HTTP/", 5))  return state;
		break;
	}
	return 0;
}


int httpbuffer_header(httpbuffer_t *o)//从一端buffer数据中解析出http头部长度
{
	const char* hv = o->data;
	int retval = 0;
	while(*(hv + retval) && retval < o->length) {
		if(retval>3 && hv[retval] == '\n' && hv[retval - 1] == '\r' && hv[retval - 2] == '\n' && hv[retval - 3] == '\r') {
			retval++;
			o->header = retval;
			return retval;
		}
		retval++;
	}
	return 0;
}

int httpbuffer_key(httpbuffer_t *o, const char* key, int* len)//从o->data头数据中查找key开头的行
{
	const char* sp = o->data;
	int result = 0, pos = 0, skln = strlen(key);
	while(result < o->header) {
		if(chars_start_with_ignore(sp, key)) {
			result += skln;
			while(char_is_empty(*(o->data + result))) result++;//去掉头部空格
			*len =  buffer_line_length(o->data + result);//设置行长度
			while(char_is_empty(*(o->data + result + *len)))  (*len)--;//去掉尾部空格
			(*len)++;
			return result;
		}
		pos = buffer_line_length(sp);
		if(sp[pos] == '\0') break;
		sp += (pos + 1);
		result += (pos + 1);
	}
	return -1;
}

int httpbuffer_headkey(httpbuffer_t *o, const char* key, vdata_t* val)//从o->data头数据中查找key开头的行
{
	const char* sp = o->data;
	int result = 0, pos = 0, skln = strlen(key);
	int len = 0;
	while(result < o->header) {
		if(chars_start_with_ignore(sp, key)) {
			result += skln;
			while(char_is_empty(*(o->data + result))) result++;//去掉头部空格
			len =  buffer_line_length(o->data + result);//设置行长度
			while(char_is_empty(*(o->data + result + len)))  len--;//去掉尾部空格
			(len)++;
			val->addr = (char*) (o->data + result);
			val->length = len;
			return result;
		}
		pos = buffer_line_length(sp);
		if(sp[pos] == '\0') break;
		sp += (pos + 1);
		result += (pos + 1);
	}
	return -1;
}

static inline httpbuffer_body(httpbuffer_t *o)//提取buffer中body的长度
{
		int pos, sln;
		const char *sp = o->data;
		pos = httpbuffer_key(o, "content-length:", &sln);
		if(pos > -1) {
			char bln[sln+1];
			SET_BUFFER(bln, sp + pos, sln);
			o->body = atoi(bln);
		}
}

int httpbuffer_context(httpbuffer_t *o)//确定缓存数据是否为HTTP协议,并解析HTTP协议
{
	//int state = http_protocol_start(o->data);
	if(httpbuffer_comfirm(o)) {
		httpbuffer_header(o);
		httpbuffer_body(o);
		return 1;
	}
	return 0;
}




/*********************************************************************/
char http_response_ok(const char* p, int sln)//比较响应状态码
{
	int  ps = 5;
	if(sln < 8) return 0;
	if(!chars_start_with(p, "HTTP/")) return 0;
	while(*(p + ps) && (*(p + ps)) != ' ') ps ++;
	ps++;
	if((ps + 6) > sln) return 0;
	return buffer_equals(p+ps, "200 OK", 6);
/*
	//char status[10];
	if(!o->direction) return 0;
	if((o->method + 1 + strlen(state)) >= o->length) return 0;
	return chars_start_with((o->data + o->method + 1), state);
	//SET_BUFFER(status, (o->data + o->method + 1), (o->url - o->method - 1));
	//return (state == atoi(status));
	 * */
}
void httpbuffer_completed(httpbuffer_t *o)//HTTP分段处理完成,重置对象
{
	o->header = 0;
	o->body = 0;
}
int httpbuffer_complete(httpbuffer_t *o, int len)//比较是否完成以次HTTP操作
{
	if(o->header == 0) {//头数据未解析时,解析
		if(!httpbuffer_header(o)) return 0;
		httpbuffer_body(o);//解析主体长度
	}
	if(o->header > 0) {//头数据解析完成时,比较是否完成
		if(o->direction && !http_response_ok(o->data, len) && !(o->body)) return 0;
		return (len >= (o->header + o->body));
	}
	return 0;
}
