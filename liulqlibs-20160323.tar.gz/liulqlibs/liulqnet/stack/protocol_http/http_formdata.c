﻿/*
 * http_formdata.c
 *		处理http协议的form-data上传数据
 *  Created on: 2015年12月18日
 *      Author: 刘龙强
 */
#include <strings.h>
#include <liulqcore.h>
#include <liulqnet.h>

//解析HTTP协议的form-data数据回调函数

static inline int http_form_data_option(const char* body, const char* key, int k1, int mx, int *len)
{
	int k2, kln = strlen(key) - 1;
	while(k1 < mx) {
		if(equals_ignore(body[k1], *key)) {//&& body[k1-1] == ' '
			if(0 == strncasecmp(body+k1 + 1, key+1, kln)) {
				k1+=kln+1;
				k2 = k1;
				while(!(body[k2] == '\r' || body[k2] == '\n')) k2++;
				(*len) = k2-k1;
				return k1;
			}
		}
		k1++;
	}
	return -1;
}
static inline int http_form_data_field(const char* body, const char*key, int k1, int mx, int* len)
{
	int k2, kln = strlen(key) - 1;
	while(k1 < mx) {
		if(body[k1]==*key && body[k1-1] == ' ' && (0 == memcmp(body+k1+1, key+1, kln))){
			k1+=kln+2;//加一个引号位置
			k2 = k1;
			while(body[k2] != '"') k2++;
			(*len) = k2-k1;
			return k1;
		}
		k1++;
	}
	return -1;
}

int http_form_data_file(httpbuffer_t* o, form_data_file_cbk data_cbk, void* par)//解析HTTP协议的form-data数据,支持文件传送
{
	int fldcnt = 0, vps =0, tps = 0, tln = 0, bodyln = o->length-o->header;
	int k1, k2, k3,k4;
	const char* body = o->data + o->header;//获取body数据流
	const char* boundaryfg = "boundary=";
	char *boundarys,  findname;
	tps = httpbuffer_key(o, "content-type", &tln);//从http头中读取'数据类型'
	char buff[tln + 10];
	SET_BUFFER(buff, o->data + tps, tln);//取出content-type数据
	tps = chars_indexof_ignore(buff, boundaryfg, 0);
	if(tps == -1) return fldcnt;

	boundarys =  buff + tps+strlen(boundaryfg) - 2;
	memcpy(boundarys, "--", 2);//
	tln = strlen(boundarys);//typv的长度

	vps = buffer_indexof(body, boundarys, 0, bodyln);
	if(-1 == vps) return fldcnt;

	vps +=  tln +2;
	while((tps = buffer_indexof(body, boundarys, vps, bodyln)) != -1) {
		char keyname[128] = {0}, filename[128] = {0}, filetype[128] = {0};
		k1 = k3 = vps;
		while(!(body[k3] == '\r' && body[k3 + 1] == '\n' && body[k3 + 2] == '\r' && body[k3 + 3] == '\n')) k3++;//找到数据开始位置
		k1 = http_form_data_field(body, "name=", vps, k3, &k2);
		if(k1 != -1) {
			SET_BUFFER(keyname, body+k1, k2);
		}
		k1 = http_form_data_field(body, "filename=", vps, k3, &k2);
		if(k1 != -1) {
			SET_BUFFER(filename, body+k1, k2);
		}
		k1 = http_form_data_option(body, "content-type: ", vps, k3, &k2);
		if(k1 != -1) {
			SET_BUFFER(filetype, body+k1, k2);
		}
		k3 += 4;//去掉双回车
		k4 = tps - k3 - 2;//数据值的长度
		if(k4) {//数据长度大于0
			const char* sv=body+k3;
			fldcnt += data_cbk(par, keyname, filename, filetype, sv, k4);//回调
		}
		if(body[tps+tln] == '-') break;//到了尾部
		vps = tps + tln +2;
	}
	return fldcnt;
}

int http_form_data(httpbuffer_t* o, form_data_cbk data_cbk, void* par)//解析HTTP协议的form-data数据
{
	int fldcnt = 0, vps =0, tps = 0, tln = 0;
	int k1, k2, k3,k4;
	const char* body = o->data + o->header;//获取body数据流
	const char* boundaryfg = "boundary=";
	char *boundarys,  findname;
	tps = httpbuffer_key(o, "content-type", &tln);//从http头中读取'数据类型'
	char buff[tln + 10];
	SET_BUFFER(buff, o->data + tps, tln);//取出content-type数据
	tps = chars_indexof_ignore(buff, boundaryfg, 0);
	if(tps == -1) return fldcnt;

	boundarys =  buff + tps+strlen(boundaryfg) - 2;
	memcpy(boundarys, "--", 2);//
	tln = strlen(boundarys);//typv的长度

	vps = chars_indexof(body, boundarys, 0);
	if(-1 == vps) return fldcnt;

	vps +=  tln +2;
	while((tps = chars_indexof(body, boundarys, vps)) != -1) {
		k1 = k3 = vps;
		while(body[k3] != '\r' && body[k3 + 1] != '\n' && body[k3 + 2] != '\r' && body[k3 + 3] != '\n') k3++;//找到数据开始位置
		findname = k1< k3;
		while(findname) {
			if(body[k1]=='n' && body[k1-1] == ' ' && (0 == memcmp(body+k1+1, "ame=", 4))){
				k1+=6;//name="
				k2 = k1;
				while(body[k2] != '"') k2++;
				k2 = k2-k1;
				findname = 0;
			} else {
				k1++;
				findname = (k1< k3);
			}
		}
		k3 += 6;//去掉双回车
		k4 = tps - k3 - 2;//数据值的长度
		if(k4) {//数据长度大于0
			char sk[k2+10];//= ;
			SET_BUFFER(sk, body+k1, k2);
			const char* sv=body+k3;
			fldcnt += data_cbk(par, sk, sv, k4);//回调
		}
		if(body[tps+tln] == '-') break;//到了尾部
		vps = tps + tln +2;
	}
	return fldcnt;
}

