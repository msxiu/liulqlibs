﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"

void httpres_cache(httpd_t* o,  int v)
{
	o->response.cache = (unsigned short)v;
}
//**cookie operator*************************************************************
char httpres_cookie(httpd_t* o, const char* item)
{
	if((o->response.cookpos + strlen(item) + 1) <= MAXHTTPURI) {
		return 1;
	}
	return 0;
}
char httpres_cookadd(httpd_t* o, const char* name, const char* val, time_t t)
{
	char buffer[256], tms[64];
	sprintf(buffer, "%s=%s;Expires=%s;path=/;", name, val, http_time(tms, t));
	return httpres_cookie(o, buffer);
}
char httpres_cookremove(httpd_t* o, const char* name)//remove响应cookie
{
	char buffer[256];
	sprintf(buffer, "%s=;Expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/;", name);
	return httpres_cookie(o, buffer);
}


//**response operator*************************************************************
char httpres_add(httpd_t* o, const void* buffer, int len)
{
	return dbuffer_write(&(o->response.body), buffer, len);
}
char httpres_addtext(httpd_t* o, const char* buffer)
{
	return httpres_add(o, buffer, strlen(buffer));
}

char httpres_header(httpd_t* o, int bodylen)//生成响应头数据
{
	GDB_DEBUGS("start write %d byte body header data!\n", bodylen);
	char buffer[256], tmbuf[128];
	socketc_t *fd = &(o->client);
	int sln=0;
	socketc_writes(fd, "HTTP/1.0 200 OK\r\n");
	bzero(tmbuf, sizeof(tmbuf));
	http_time_now(tmbuf);//获得系统时间
	sprintf(buffer, "Date:%s\r\n", tmbuf);
	socketc_writes(fd, buffer);
	socketc_writes(fd, "Connection:Keep-Alive\r\n");
	socketc_writes(fd, "Server:Apache/1.3.14(Unix)\r\n");
	if(o->response.cache > 0) {
		bzero(tmbuf, sizeof(tmbuf));
		sprintf(tmbuf, "Cache-Control:max-age=%d\r\n", o->response.cache);//允许客户端缓存的秒数
		GDB_DEBUGS("%s", tmbuf);
		socketc_writes(fd, buffer);
	}

	sln = o->request.uri.finish - o->request.uri.start;
	SET_BUFFER(tmbuf, o->request.header + o->request.uri.start, sln);
	sprintf(buffer, "Content-type:%s\r\n", http_mime_type(tmbuf));//通过请求URI获得媒体类型
	socketc_writes(fd, buffer);

	socketc_writes(fd, "Accept-Language:zh-cn\r\n");
	socketc_writes(fd, "User-Agent:Mozila/4.0(compatible:MSIE5.01:Windows NT5.0)\r\n");
	if(o->response.cookpos > 0) {
		sprintf(buffer, "Set-Cookie:%s\r\n", tmbuf);
		GDB_DEBUGS("Set-Cookie:%s\r\n", buffer);
		socketc_writes(fd, buffer);
	}

	sprintf(buffer, "Content-length:%d\r\n", bodylen);//输出内容长度
	socketc_writes(fd, buffer);
	socketc_writes(fd, "\r\n");
	GDB_INFOS("finished output header of  %d byte body;\n", bodylen);
	return 1;
}

char httpres_write(httpd_t* o)
{
	int i,bodylen=o->response.body.bytecnt;
	int pgcnt = dbuffer_pages(&(o->response.body));
	//write header
	httpres_header(o, bodylen);
	//write body
	for(i=0;i<pgcnt;i++) {
		vdata_t v;
		dbuffer_page(&(o->response.body), i, &v);
		GDB_DEBUGS("send %d packet %d byte data;\n", pgcnt,v.length);
		socketc_write(&(o->client), v.addr, v.length);
		usleep(10000);
	}
	GDB_DEBUGS("write body %d packet %d byte data finished!;\n", pgcnt, bodylen);
	return 1;
}
char httpres_writefile(httpd_t* o, const char* addr)
{
	char fbuf[MAX_FILEADDR_LEN];
	if(file_exists(httpd_mappath(o, addr, fbuf))) {
		socketc_writefile(&(o->client), fbuf, 0, 0);
	}
	return 0;
}
