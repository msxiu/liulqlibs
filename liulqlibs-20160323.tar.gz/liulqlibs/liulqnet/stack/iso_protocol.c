﻿#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iso_protocol.h>

//#define NULL ((void*)0)

inline uint8_t* pkt_ether_smac(char* pkt)//获得二层协议的源mac
{
	return (uint8_t*)(pkt+6);
}
inline uint8_t* pkt_ether_dmac(char* pkt)//获得二层协议的目的mac
{
	return (uint8_t*)(pkt);
}
inline uint16_t pkt_ether_type(char* pkt) //获得二层协议类型
{
	uint16_t ret;
	memcpy(&ret, pkt + 12, 2);
	return ntohs(ret);
}

//***ARP***********************************************************************
 inline char pkt_isarp(char*pkt)//判断是否为ARP协议
 {
		uint16_t ret;
		memcpy(&ret, pkt + 12, 2);
		return (0x0806 == ntohs(ret));
 }
inline struct ether_arp* pkt_arp_body(char*pkt)//获得ARP主体
{
	if(!pkt_isarp(pkt)) return NULL;
	return (struct ether_arp*)(pkt + 14);
}
inline uint16_t pkt_arp_operate(char* pkt)//操作类型,1:ARP请求,2:ARP应答,3:RARP请求,4:RARP应答
{
	struct ether_arp* arp = pkt_arp_body(pkt);
	if(NULL != arp) return ntohs(arp->ea_hdr.ar_op);
	return 0;
}


 //***IP***********************************************************************
 inline char pkt_isip(char*pkt)//判断是否为IP协议
 {
		uint16_t ret;
		memcpy(&ret, pkt + 12, 2);
		return (0x0800 == ntohs(ret));
 }
 inline struct iphdr* pkt_ip_header(char* pkt)//获得IP头
 {
	 return (struct iphdr*)(pkt + 14);
 }
 inline uint8_t pkt_ip_protocal(char* pkt)//获得IP下一层协议{1:ICMP,6:TCP,17:UDP}
 {
	 struct iphdr* hdr =  (struct iphdr*)(pkt + 14);
	if (NULL == hdr)  return 0;
	return hdr->protocol;
 }
inline unsigned char pkt_ip_hdrlen(char*pkt)//获得IP头长度
{
	struct iphdr* hdr =  pkt_ip_header(pkt);
	if (NULL == hdr)  return 0;
	 return 4 * hdr->ihl;
}
inline uint32_t pkt_ip_daddr(char* pkt)//获得目的IP地址
{
	struct iphdr* hdr =  pkt_ip_header(pkt);
	if (NULL == hdr)  return 0;
	 return hdr->daddr;
}
inline uint32_t pkt_ip_saddr(char* pkt)//获得源IP地址
{
	struct iphdr* hdr =  pkt_ip_header(pkt);
	if (NULL == hdr)  return 0;
	 return hdr->saddr;
}
inline uint16_t pkt_ip_identity(char* pkt)//获得IP标识
{
	struct iphdr* hdr =  pkt_ip_header(pkt);
	if (NULL == hdr)  return 0;
	return hdr->id;
}
inline uint32_t pkt_ip_bodypos(char* pkt)//获得IP包数据流位置
{
	return 14 + pkt_ip_hdrlen(pkt);
}
//***ICMP*********************************************************
inline char pkt_isicmp(char* pkt)//是否为ICMP包
{
	struct iphdr* hdr =  pkt_ip_header(pkt);
	if (NULL == hdr)  return 0;
	return (1 == hdr->protocol);
}
inline struct icmphdr* pkt_icmp_header(char* pkt)//获得ICMP头
{
	if(!pkt_isicmp(pkt)) return NULL;
	return (struct icmphdr*)(pkt + pkt_ip_hdrlen(pkt));
}
inline uint8_t pkt_icmp_type(char* pkt)//ICMP类型,0:应答,8:请求
{
	struct icmphdr* hdr = pkt_icmp_header(pkt);
	if (NULL == hdr)  return 0;
	return hdr->type;
}
inline uint8_t pkt_icmp_code(char* pkt)//ICMP code
{
	struct icmphdr* hdr = pkt_icmp_header(pkt);
	if (NULL == hdr)  return 0;
	return hdr->code;
}
inline uint16_t pkt_icmp_checksum(char* pkt)//ICMP校验码
{
	struct icmphdr* hdr = pkt_icmp_header(pkt);
	if (NULL == hdr)  return 0;
	return hdr->checksum;
}
//***UDP***********************************************************
inline char pkt_isudp(char* pkt)//是否为UDP包
{
	if(!pkt_isip(pkt)) return 0;
	struct iphdr* hdr =  pkt_ip_header(pkt);
	return (17 == hdr->protocol);
}
inline struct udphdr* pkt_udp_header(char* pkt)//获得UDP头
{
	if(!pkt_isudp(pkt)) return NULL;
	return (struct udphdr*) (pkt + pkt_ip_hdrlen(pkt));
}
inline uint16_t pkt_udp_dport(char* pkt)//获得UDP目标端口
{
	struct udphdr*  hdr = pkt_udp_header(pkt);
	if (NULL == hdr)  return 0;
	return(hdr->dest);
}
inline uint16_t pkt_udp_sport(char* pkt)//获得UDP源端口
{
	struct udphdr*  hdr = pkt_udp_header(pkt);
	if (NULL == hdr)  return 0;
	return(hdr->source);
}
inline uint16_t pkt_udp_length(char* pkt)//获得UDP包的长度
{
	struct udphdr*  hdr = pkt_udp_header(pkt);
	if (NULL == hdr)  return 0;
	return(hdr->len);
}
inline uint16_t pkt_udp_bodylen(char* pkt)//获得UDP包内容长度
{
	struct udphdr*  hdr = pkt_udp_header(pkt);
	if (NULL == hdr)  return 0;
	return(hdr->len - 8);
}
inline uint16_t pkt_udp_bodypos(char* pkt)//获得UDP包内容位置
{
	return (14 + pkt_ip_hdrlen(pkt) + 8);
}
inline uint16_t pkt_udp_reader(char* pkt, void*buffer)//读取UDP内容到缓存
{
	int ret = pkt_udp_bodylen(pkt);
	memcpy(buffer, (void*)(pkt+pkt_udp_bodypos(pkt)), ret);
	return ret;
}
//***TCP***********************************************************
inline char pkt_istcp(char* pkt)//是否为TCP包
{
	if(!pkt_isip(pkt)) return 0;
	struct iphdr* hdr =  pkt_ip_header(pkt);
	return (6 == hdr->protocol);
}
inline struct tcphdr* pkt_tcp_header(char* pkt)//获得TCP包头
{
	if(!pkt_istcp(pkt)) return NULL;
	return (struct tcphdr*) (pkt + pkt_ip_hdrlen(pkt));
}
inline uint16_t pkt_tcp_dport(char* pkt)//获得TCP包目标端口
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (hdr->dest);
}
inline uint16_t pkt_tcp_sport(char* pkt)//获得TCP包源端口
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (hdr->source);
}
inline uint32_t pkt_tcp_sequence(char* pkt)//获得TCP包序列号
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (hdr->seq);
}
inline uint32_t pkt_tcp_ack(char* pkt)//获得TCP包ack
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (hdr->ack_seq);
}
inline uint32_t pkt_tcp_hdrlen(char* pkt)//获得TCP包头长度
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (4*hdr->doff);
}
inline uint16_t pkt_tcp_window(char* pkt)//获得TCP包window
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return (hdr->window);
}
inline uint16_t pkt_tcp_check(char* pkt)//获得TCP包校验码
{
	struct tcphdr* hdr = pkt_tcp_header(pkt);
	if (NULL == hdr)  return 0;
	return hdr->check;
}
inline uint16_t pkt_tcp_bodypos(char* pkt)//获得TCP包内容位置
{
	return (14 + pkt_ip_hdrlen(pkt) + pkt_tcp_hdrlen(pkt));
}
