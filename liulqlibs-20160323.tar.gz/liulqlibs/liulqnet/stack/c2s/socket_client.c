﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"
#define TRYRECOUNT 3

//---打开一个客户端
int socketc_open(socketc_t *c)
{
	GDB_DEBUGS("not assign net card %s:%d send data;\n", c->ipaddr, c->port);
	int ret = -1;
	static struct sockaddr_in srv_addr;
	memset(&srv_addr, 0, sizeof(srv_addr));

	c->connfd = socket(PF_INET, SOCK_STREAM, 0);
	if(c->connfd <= 0) {
		GDB_ERROR("cannot create communication socket!\n");
		goto labend1;
	}
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.s_addr = inet_addr(c->ipaddr);//ip
	srv_addr.sin_port = htons(c->port);//port

	ret=connect(c->connfd, (struct sockaddr *)&srv_addr, sizeof(srv_addr));
	if(ret == -1) {
		GDB_ERRORS("cannot connect to the server[%s:%d]!\n", c->ipaddr, c->port);
		goto labend2;
	}
	GDB_DEBUGS("open socket of '%d';\n", c->connfd);
	return ret;

labend2:
	socketc_close(c);
labend1:
	return -1;
}

//---指定网卡,打开一个客户端
int socketc_open_card(socketc_t *c, const char* card)
{
	int ret = -1;
	struct ifreq inf;
	struct sockaddr_in srv_addr;
	memset(&srv_addr, 0, sizeof(srv_addr));

	c->connfd = socket(PF_INET, SOCK_STREAM, 0);
	if(c->connfd <= 0) {
		GDB_ERROR("cannot create communication socket!\n");
		goto labend1;
	}

	strncpy(inf.ifr_ifrn.ifrn_name, card, IFNAMSIZ);
	if(setsockopt(c->connfd, SOL_SOCKET, SO_BINDTODEVICE, (char*)&inf, sizeof(inf)) < 0) {
		GDB_ERRORS("setsockopt bind '%s' error!\n", card);
		goto labend1;
	}

	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.s_addr = inet_addr(c->ipaddr);//ip
	srv_addr.sin_port = htons(c->port);//port

	ret=connect(c->connfd, (struct sockaddr *)&srv_addr, sizeof(srv_addr));
	if(ret == -1) {
		GDB_ERRORS("cannot connect to the server[%s:%d]!\n", c->ipaddr, c->port);
		goto labend2;
	}
	return ret;

labend2:
	socketc_close(c);
labend1:
	return -1;
}

//关闭客户端链接
int socketc_close(socketc_t *c)
{
	if(c->connfd>0){
		GDB_INFOS("close socket of '%d';\n", c->connfd);
		close(c->connfd);
		c->connfd=0;
	}
	return 0;
}



//从套接字中读取数据
int socketc_read(socketc_t *c, void* buffer, const unsigned int len)
{
	int nextlen = len, reals = 0, retrycnt = TRYRECOUNT;
	unsigned char* dstart = (unsigned char*)buffer;
	while(nextlen > 0 && retrycnt > 0) {
		usleep(100000);
		reals = read(c->connfd, dstart, nextlen);
		if(reals <= 0){
			retrycnt --;
		} else{
			retrycnt = TRYRECOUNT;
			nextlen -= reals;
			dstart += reals;
		}
	}
	return (retrycnt > 0 ? len : -1);
}
//读取1个整形
int socketc_read_int(socketc_t *c, int * buf)
{
	int ret = socketc_read(c, buf, 4);
	if(-1 != ret) *buf = ntohl(*buf);
	return ret;
}

//向套接字中写入数据
int socketc_write(socketc_t *c, const void* buffer, const unsigned int len)
{
	int nextlen = len, reals = 0, retrycnt = TRYRECOUNT;
	unsigned char* dstart = (unsigned char*)buffer;
	while(nextlen > 0 && retrycnt > 0) {
		reals = write(c->connfd, dstart, nextlen);
		if(reals <= 0){
			retrycnt --;
		} else{
			retrycnt = TRYRECOUNT;
			nextlen -= reals;
			dstart += reals;
		}
	}
	return (retrycnt > 0 ? len : -1);
}

//写入1个整形
int socketc_write_int(socketc_t *c, unsigned int i)
{
	int t = htonl(i);
	t = socketc_write(c, (unsigned char*)&t, 4);
	return t;
}

int socketc_writes(socketc_t *c, const char *buffer)
{
	int sln = strlen(buffer);
	return socketc_write(c, buffer, sln);
}
int socketc_writefile(socketc_t *c, const char* addr, int start, int len)
{
	FILE *fp;
	int rlen = -1, flen, tln,cln, sln = 1024;
	unsigned char buffer[sln];

	fp = fopen(addr, "rb");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	fseek(fp, 0L, SEEK_END);
	flen = ftell(fp);
	if(0 == start && 0 == len) len = flen;
	if(flen < start+len) {
		goto lebel1;
	}
	fseek(fp, start, SEEK_SET);
	rlen = 0;
	while(len) {
		tln = (len > sln ? sln : len);
		cln = fread(buffer, 1, tln, fp);
		if(cln != tln){
			rlen = -1;
			break;
		}
		socketc_write(c, buffer, cln);
		len -= tln;
		rlen += tln;
		usleep(1000);
	}
lebel1:
	fclose(fp);
	return rlen;
}
