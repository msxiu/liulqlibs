﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"

//--设置fd为非阻塞模式----------------------------------------------------
char socket_nonblock(int fd)
{
	GDB_DEBUGS("socket_nonblock %d;\n", fd);
   int flags = fcntl(fd, F_GETFL, 0);
   flags |= O_NONBLOCK;
   return (-1 != fcntl(fd, F_SETFL, flags)) ? 1 : 0;
}

//--新链接监听函数
char epollsvr_onconnect(epollsvr_t *e, int i)
{
	GDB_DEBUG("epollsvr_onconnect\n");
	struct sockaddr_in client_addr;
	socklen_t length=sizeof(client_addr);
	int conn_fd = accept(e->listen_fd, (struct sockaddr *)&client_addr, &length);
	char *client_ip = inet_ntoa(client_addr.sin_addr);
	socketc_t c;
	c.connfd = conn_fd;
	c.port = client_addr.sin_port;
	strcpy(c.ipaddr, client_ip);
	GDB_INFOS("client %s:%d connect on!\n%s", client_ip, client_addr.sin_port, GDB_LINE_NEXT);

	if(NULL == e->connect) {
		GDB_ERRORS("%p object not set 'connect' function!\n",  e);
	}
	struct epoll_event evt;
	evt.events = EPOLLIN;
	evt.data.ptr = e->connect(e, &c);//CreateClient(conn_fd, client_ip, client_addr.sin_port);
	GDB_DEBUGS("[server:%d,client:%d]=EPOLLOUT event;\n", e->epoll_fd, c.connfd);
	epoll_ctl(e->epoll_fd, EPOLL_CTL_ADD, c.connfd, &evt);//3.  把新连接加入到内核_事件表中
	socket_nonblock(conn_fd);//4. 设置成非阻塞
	return 1;
}
void epollsvr_tosend(epollsvr_t *e, socketc_t *c, int i)//告诉epoll， 下次要发送
{
	GDB_DEBUGS("[server:%d,client:%d]=EPOLLOUT event %p;\n", e->epoll_fd, c->connfd, c);
	struct epoll_event evt;
	evt.events = EPOLLOUT;//告诉epoll， 下次要发送
	evt.data.ptr = e->events[i].data.ptr;//c;
	epoll_ctl(e->epoll_fd, EPOLL_CTL_MOD, c->connfd, &evt); //修改事件，等待下一个循环时发送数据，异步处理的精髓
}
void epollsvr_torecv(epollsvr_t *e, socketc_t *c, int i)//把事件类型该为EPOLLIN，等待接收客户端的数据
{
	GDB_DEBUGS("[server:%d,client:%d]=EPOLLIN event %p;\n", e->epoll_fd, c->connfd, c);
    struct epoll_event evt;
    evt.events = EPOLLIN;//告诉epoll， 下次要接收
	evt.data.ptr = e->events[i].data.ptr;//c;
	epoll_ctl(e->epoll_fd, EPOLL_CTL_MOD, c->connfd, &evt);
}


//销毁对象
void epollcnt_destory(epollsvr_t *e, socketc_t *c, int i)
{
	   GDB_ERRORS("[server:%d,client:%d]=EPOLL_CTL_DEL event %p!\n",  e->epoll_fd, c->connfd, c);
	epoll_ctl(e->epoll_fd, EPOLL_CTL_DEL, c->connfd, &(e->events[i])); //从内核_事件表中删除该事件
    shutdown(c->connfd, SHUT_RDWR);//关闭连接SHUT_RDWR
	if(NULL != e->destory) e->destory(e, i);
}


//******************************************************************************************
//---运行服务端,并监听----------------------
void* epollsvr_running(void *p)
{
	epollsvr_t *o = (epollsvr_t*)p;
	int i=0;
	GDB_DEBUGS("wait request form '%s:%d';\n", o->ipaddr, o->port);
	while(1) {
		int ret = epoll_wait(o->epoll_fd, o->events, MAX_EVENT_NUMBER, -1);
		//GDB_DEBUGS("%d events!\n", ret);
		for(i=0; i < ret; ++ i) {
           if(o->events[i].data.fd == o->listen_fd) {
        	   epollsvr_onconnect(o, i);//1. 如果是新的客户端连接
           } else if(o->events[i].events & EPOLLIN) {
        	   if(NULL != o->onrecv) {
					GDB_ERRORS("onrecv %p object %d:%d=>%d event %p handle!\n",  p, i, o->events[i].events, ret, o->events[i].data.ptr);
					o->onrecv(o, i);//2. 客户端发来数据 或者 客户端关闭连接
        	   } else {
        		   GDB_ERRORS("%p object not set 'onrecv' function!\n",  p);
        	   }
           } else if(o->events[i].events & EPOLLOUT) {
        	   if(NULL != o->onsend){
				   GDB_ERRORS("onsend %p object %d[%d]=>%d event %p handle!\n",  p, o->events[i].events, i, ret, o->events[i].data.ptr);
        		   o->onsend(o, i);//3. 服务器有数据要发往客户端
        	   } else {
				   GDB_ERRORS("%p object not set 'onsend' function!\n",  p);
        	   }
           } else {
           	   GDB_DEBUGS("undefined %d on %d;!\n", o->events[i].events, i);
           }
		}//for(int i = 0; i < ret; ++ i)
	}//while(true)
	return p;
}


//开始监听
int epollsvr_start(epollsvr_t *e)
{
	int flags=0, result = -1;
	e->epoll_fd = epoll_create(MAX_EVENT_NUMBER);//生成用于处理accept的epoll专用的文件描述符
	e->listen_fd= socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in server_addr;
	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family=AF_INET;

	server_addr.sin_port=htons(e->port);//port
	if(chars_is_empty(e->ipaddr)) {
		server_addr.sin_addr.s_addr = INADDR_ANY;//ip
		GDB_DEBUGS("bind server  port:%d!\n", e->port);
	} else {
		server_addr.sin_addr.s_addr = inet_addr(e->ipaddr);//ip
		GDB_DEBUGS("bind server ip:%s and port:%d!\n", e->ipaddr, e->port);
	}

	result = bind(e->listen_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
	if(0 != result) return -1;
	listen(e->listen_fd, e->backlog);
	GDB_INFOS("listener port:%d, backlog:%d state:%d!\n", e->port, e->backlog, result);

	struct epoll_event ev;
	ev.data.fd = e->listen_fd;//设置与要处理的事件相关的文件描述符
	ev.events = EPOLLIN;//设置要处理的事件类型
	epoll_ctl(e->epoll_fd, EPOLL_CTL_ADD, e->listen_fd, &ev);//注册epoll事件

	socket_nonblock(e->listen_fd);
	//启动监听线程
	pthread_create(&e->thread_id, NULL, epollsvr_running,  e);
	return result;
}
//等待线程执行完成
int epollsvr_join(epollsvr_t *e)
{
	pthread_join(e->thread_id, NULL);
	return 0;
}
//取消线程执行
int epollsvr_cancel(epollsvr_t *e)
{
	pthread_cancel(e->thread_id);
	return 0;
}
//销毁对象
int epollsvr_destory(epollsvr_t *e)
{
	if(e->listen_fd) {
		close(e->listen_fd);
		e->listen_fd=0;
	}
	if(e->epoll_fd) {
		close(e->epoll_fd);
		e->epoll_fd = 0;
	}
	return 0;
}




