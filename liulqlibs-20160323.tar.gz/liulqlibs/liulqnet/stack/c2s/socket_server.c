﻿#include<liulqnet.h>
#include "../../../incs/liulqdebug.h"

void * socksvrc_running(void* p) {
	socksvrc_t* c = (socksvrc_t*)p;
	c->server->execute(c);
    shutdown(c->sock.connfd, SHUT_RDWR);//关闭连接SHUT_RDWR
    free(p);
	GDB_DEBUGS("%s:%d connect finish!\n%s", c->sock.ipaddr, c->sock.port, GDB_LINE_NEXT);
	return (void*)0;
}
//---运行服务端,并监听----------------------
void* socksvr_running(void *p)
{
	socksvr_t *e = (socksvr_t*)p;
	int i=0;
	GDB_DEBUGS("wait request form '%s:%d';\n", e->ipaddr, e->port);
	while(1)  {
		int ret = epoll_wait(e->epoll, e->events, MAX_EVENT_NUMBER, -1);
		GDB_SEPARATOR("epoll events");
		for(i=0; i < ret; i++) {
			if(e->listen != e->events[i].data.fd) {
				GDB_ERRORS("EPOLL_CTL_DEL[server:%d,client:%d] !\n",  e->epoll, e->events[i].data.fd);
				epoll_ctl(e->epoll, EPOLL_CTL_DEL, e->events[i].data.fd, &(e->events[i])); //从内核_事件表中删除该事件
				continue;
			}
			GDB_DEBUGS("%d/%d events start!\n", i, ret);
			struct sockaddr_in client;
			socklen_t length=sizeof(client);
			int fd  = accept(e->listen, (struct sockaddr *)&client, &length);
			char *ip = inet_ntoa(client.sin_addr);

			socksvrc_t* c = (socksvrc_t*)malloc(sizeof(socksvrc_t));
			c->sock.connfd = fd;
			c->sock.port = client.sin_port;
			strcpy(c->sock.ipaddr, ip);
			c->server = e;

			GDB_INFOS("client %d:{%s:%d} connect on!\n", c->sock.connfd, ip, c->sock.port);
			if(NULL == e->execute) {
				GDB_ERRORS("%p object not set 'execute' function!\n",  e);
			}
			//socket_nonblock(c->sock.connfd);//4. 设置成非阻塞
			pthread_create(&(c->thread), NULL, socksvrc_running,  c);//启动线程
			GDB_DEBUGS("%d/%d events finished!\n", i, ret);
		}
	}
	return p;
}
//开始监听
int socksvr_start(socksvr_t *e)
{
	int flags=0, result = -1;
	e->epoll = epoll_create(MAX_EVENT_NUMBER);//生成用于处理accept的epoll专用的文件描述符
	e->listen= socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in server_addr;
	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family=AF_INET;

	server_addr.sin_port=htons(e->port);//port
	if(chars_is_empty(e->ipaddr)) {
		server_addr.sin_addr.s_addr = INADDR_ANY;//ip
		GDB_DEBUGS("bind server  port:%d!\n", e->port);
	} else {
		server_addr.sin_addr.s_addr = inet_addr(e->ipaddr);//ip
		GDB_DEBUGS("bind server ip:%s and port:%d!\n", e->ipaddr, e->port);
	}

	result = bind(e->listen, (struct sockaddr *)&server_addr, sizeof(server_addr));
	if(0 != result) return -1;
	listen(e->listen, e->backlog);
	GDB_INFOS("listener port:%d, backlog:%d state:%d!\n", e->port, e->backlog, result);

	struct epoll_event ev;
	ev.data.fd = e->listen;//设置与要处理的事件相关的文件描述符
	ev.events = EPOLLIN;//设置要处理的事件类型
	epoll_ctl(e->epoll, EPOLL_CTL_ADD, e->listen, &ev);//注册epoll事件

	socket_nonblock(e->listen);
	//启动监听线程
	pthread_create(&e->thread, NULL, socksvr_running,  e);
	return result;
}


//等待线程执行完成
int socksvr_join(socksvr_t *e)
{
	return pthread_join(e->thread, NULL);
}
//取消线程执行
int socksvr_cancel(socksvr_t *e)
{
	return pthread_cancel(e->thread);
}
//销毁对象
int socksvr_destory(socksvr_t *e)
{
	if(e->listen) {
		close(e->listen);
		e->listen=0;
	}
	if(e->epoll) {
		close(e->epoll);
		e->epoll = 0;
	}
	return 0;
}
