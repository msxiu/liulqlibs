/*
 * httprequest.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include "httpaction.h"
#include "liulqcore.h"



#define HTTPDESCRIBE_ADDHANDLER(o, cbk)  {\
		httpengine_cbk_t* item = calloc(1, sizeof(httpengine_cbk_t));\
		item->execute = (httpengine_execute)cbk;\
		if(NULL != o) {\
			item->next = (o);\
		}\
		(o) = item;\
}while(0)
/**添加邮件处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
void httpdescribe_addhandler_mail(httpengine_handle_t* o, void (*callback)(httpmail_t*, tcpheader_t* e))
{
	HTTPDESCRIBE_ADDHANDLER(o->cbkmail, callback);
}
/**添加论坛处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
void httpdescribe_addhandler_forum(httpengine_handle_t* o, void (*callback)(httpforum_t*, tcpheader_t* e))
{
	HTTPDESCRIBE_ADDHANDLER(o->cbkforum, callback);
}
/**添加网盘处理函数
 *@parameter o:请求描述对象
 *@parameter callback:回调函数
 */
void httpdescribe_addhandler_pan(httpengine_handle_t* o, void (*callback)(httpattach_t*, tcpheader_t* e))
{
	HTTPDESCRIBE_ADDHANDLER(o->cbkpan, callback);
}


int http_regex_request(httpdescribe_t* o, tcpheader_t* e)//正则表达式解析
{
#define CASE_HANDLE(dat)		{\
		switch(o->rule->rule) {\
		case HTTP_AUDIT_MAIL: result =  http_mail_regex(o, e, &dat);break;\
		/*case HTTP_AUDIT_PAN: return http_pan_regex(o, &dat);*/\
		case HTTP_AUDIT_FORUM:  result =  http_forum_regex(o, e, &dat);break;\
		}\
} while(0)

	httpbuffer_t *http = o->http;
	if(http->body) {
		int result = 0;
		vdata_t dat;
		switch(o->rule->resolve) {
		case HTTP_RESOLVE_URLDECODE_REGEX:
			dat.addr = calloc(1, http->body + 10);
			dat.length = http_urldecode_chars(http->data+http->header, http->body, dat.addr, http->body);
			CASE_HANDLE(dat);
			free(dat.addr);
			break;
		case HTTP_RESOLVE_REGEX_URLDECODE:
			dat.addr= (char*)(http->data+http->header);
			dat.length =  http->body;
			CASE_HANDLE(dat);
			break;
		}
		return result;
	}
	return 0;
}

int httpaction_request(httpengine_handle_t *handler, httpbuffer_t* o, tcpheader_t* e)//http请求处理
{
	int pos = 0;
	httpcontentype_t ctype;
	httpdescribe_t item = { .http = o,  .ctype = &ctype, .handles = handler };//.tcp = tcp,
	item.rule = (tb_engine_actioni_t*)httpactionrules_filter(handler, o);//匹配过滤规则
	if(NULL == item.rule) return 0;
	pos = http_contenttype(o,  &ctype);//解析内容类型
	if(!pos) return -1;

	switch(item.rule->resolve) {
	case HTTP_RESOLVE_FORMDATA:
		if(0 == strcasecmp(ctype.contenttype, "multipart/form-data")) {
			switch(item.rule->rule) {
			case HTTP_AUDIT_MAIL: return http_mail_formdata(&item, e);
			case HTTP_AUDIT_PAN: return http_pan_formdata(&item, e);
			case HTTP_AUDIT_FORUM:  return http_forum_formdata(&item, e);
			case HTTP_AUDIT_ATTACH: return http_attach_upload(&item);
			}
		}
		break;
	case HTTP_RESOLVE_URLDECODE:
		if(0 == strcasecmp(ctype.contenttype, "application/x-www-form-urlencoded")) {
			switch(item.rule->rule) {
			case HTTP_AUDIT_MAIL: return http_mail_urlencoded(&item, e);
			//case HTTP_AUDIT_PAN: return http_pan_urlencoded(&item, e);
			case HTTP_AUDIT_FORUM:  return http_forum_urlencoded(&item, e);
			}
		}
		break;
	case HTTP_RESOLVE_ATTACH://附件
		switch(item.rule->rule) {
		case HTTP_AUDIT_PAN: return http_pan_attach(&item, e);
		case HTTP_AUDIT_ATTACH: return http_attach_upload(&item);
		}
		break;
	case HTTP_RESOLVE_URLDECODE_REGEX:
	case HTTP_RESOLVE_REGEX_URLDECODE:
		return http_regex_request(&item, e);
	}

	//http_attach_timeout(handler, handler->attach_timeout);//清除超时附件
	return 0;
}

int http_action(httpengine_handle_t *handler, tcpstream_t *o)//http响应
{
	httpbuffer_t obj = { .data = o->buffer, .length = o->length };
	httpbuffer_context(&obj);

	switch(obj.direction) {
	case 0://0:请求
		return httpaction_request(handler, &obj, &(o->element));
	case 1://1:响应
		break;
	}
	return 0;
}

