/*
 * httpaction_attach.c
 *
 *  Created on: 2016年2月2日
 *      Author: root
 */
#include <pthread.h>

#include "httpaction.h"
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"
#include "httpaction_attach.h"

#define ATTACH_BIND(o, att) {\
	vdata_t v1;\
	SET_BUFFER((att)->m_method, o->http->data, o->http->method);\
	if(httpbuffer_headkey(o->http, "host:", &v1)) {\
		SET_BUFFER((att)->m_domain, v1.addr, v1.length);\
	}\
	SET_BUFFER((att)->m_uri, (o->http->data + o->http->method + 1), (o->http->url - o->http->method - 1));\
	http_cookie_each(o, cookie_parameters, att);\
	http_urlquery_each(o, urlquery_parameters, att);\
}while(0)

#define ATTACH_APPEND(o, att) {\
	ATTACH_BIND(o, att);\
	ATTACHMENT_DEBUG("add attach{%s:%s}\n", (att)->m_domain, (att)->m_uri);\
	list_add_tail(&((att)->list), &o->handles->attachs);\
}while(0)

static pthread_mutex_t attach_lock = PTHREAD_MUTEX_INITIALIZER;


/**销毁对象
 *@parameter o:附件对象
 */
void http_attach_destory(httpattach_t* o)
{
	if(o) {
		if(o->data) {
			free(o->data);
			o->data = NULL;
		}
		if(o->part) {
			free(o->part);
			o->part = NULL;
		}
		free(o);
	}
}

/**从链表中查找分包数据
 *@parameter o:http请求描述
 *@parameter att:附件对象
 */
static httpattach_t* http_attach_findpart(httpdescribe_t* o, httpattach_t* att)
{
	httpattach_t *result=NULL, *pos, *n;
	list_for_each_entry_safe(pos, n, &o->handles->attachs, list) {
		tb_engine_actioni_t* r = o->rule;
		if(httpactionrules_contains(o->rule, pos->m_method, pos->m_domain, pos->m_uri)) {
			if(0 == strcasecmp(att->m_sid, pos->m_sid) && NULL != pos->part && 0 == strcasecmp(pos->part->name, att->part->name)) {
				//GDB_DEBUGS("rule:{domain:'%s',url:'%s'},attach:{domain:'%s',url:'%s',sid:'%s'}\n", r->domain, r->url, pos->m_domain, pos->m_uri, pos->m_sid);
				result = pos;
				break;
			}
		}
	}
	return result;
}



/**附件上传处理程序,分包http post 流附件上传
 *@parameter o:http请求描述
 */
httpattach_t* http_attach_partdata(httpdescribe_t* o)//
{
	int state = 0, partfree = 0;
	httpattach_t* attach, item = {0};
	tb_engine_attach_t* rule = (tb_engine_attach_t*)to_parent_address(o->rule, tb_engine_attach_t, action);//匹配规则
	vdata_t v;
	httattachpart_t* part = calloc(1, sizeof(httattachpart_t));
	httpbuffer_t *http =  o->http;
	char *encoding = (chars_is_empty(o->ctype->charset) ? o->rule->charset : o->ctype->charset);;

	item.rules = rule;
	ATTACHMENT_DEBUG("%p:'%s'\n", rule, rule->name);
	if(httpbuffer_headkey(http, rule->name, &v)) {
		http_urldecode_element(encoding, v.addr, v.length, part->name, 256);
		//SET_BUFFER(part->name, v.addr, v.length);//附件名
	}
	if(httpbuffer_headkey(http, rule->offset, &v)) {
		PARSE_INT_OF(part->offset, v.addr, v.length);//偏移
	}
	if(httpbuffer_headkey(http, rule->aid, &v)) {
		PARSE_INT_OF(part->aid, v.addr, v.length);//非首包
	}
	if(httpbuffer_headkey(http, rule->size, &v)) {
		PARSE_INT_OF(part->size, v.addr, v.length);//总大小
	}
	if(httpbuffer_headkey(http, rule->length, &v)) {
		PARSE_INT_OF(part->length, v.addr, v.length);//当前数据大小
	}
	item.part = part;

	ATTACH_BIND(o, &item);
	attach = http_attach_findpart(o, &item);
	if(NULL == attach) {
		attach = calloc(1, sizeof(httpattach_t));
		ATTACHMENT_DEBUG("%p:create part first attach!\n", attach);
		attach->rules = rule;
		attach->data = calloc(1, part->size + 10);
		attach->part = part;
		pthread_mutex_lock(&attach_lock);
		ATTACH_APPEND(o, attach);
		pthread_mutex_unlock(&attach_lock);

		strcpy(attach->m_name, part->name);
		if(httpbuffer_headkey(http, "content-type:", &v)) {
			SET_BUFFER(attach->m_type, v.addr, v.length);
		}
	} else {
		ATTACHMENT_DEBUG("%p:match part first attach!\n", attach);
		partfree = 1;
	}
	memcpy(attach->data+part->offset, http->data + http->header, part->length);
	attach->part->length += part->length;
	attach->m_size = attach->part->length;
	attach->m_time = time(NULL);
	ATTACHMENT_DEBUG("http_attach_partdata{sid:'%s',name:'%s',type:'%s',len:%d}\n", attach->m_sid, attach->m_name, attach->m_type, attach->part->length);

	state = (attach->part->length < attach->part->size);
	if(partfree) {
		free(part);
		item.part = NULL;
	}
	return (state ? NULL : attach);
}

/**附件上传处理程序,单个http post 流文件上传
 *@parameter o:http请求描述
 */
httpattach_t* http_attach_upfile(httpdescribe_t* o)
{
	httpattach_t* attach;
	tb_engine_attach_t* rule = (tb_engine_attach_t*)to_parent_address(o->rule, tb_engine_attach_t, action);//匹配规则
	//httpattachrule_t* rule =  o->rule->rulenode;
	vdata_t v;

	if(httpbuffer_headkey(o->http, rule->name, &v)) {
		SET_BUFFER(attach->m_name, v.addr, v.length);
	}
	if(httpbuffer_headkey(o->http, "content-type:", &v)) {
		SET_BUFFER(attach->m_type, v.addr, v.length);
	}
	if(httpbuffer_headkey(o->http, "content-type:", &v)) {
		attach->m_time = time(NULL);
		PARSE_INT_OF(attach->m_size, v.addr, v.length);
		attach->data = calloc(1, attach->m_size+10);
		memcpy(attach->data, o->http->data + o->http->header, attach->m_size);
		ATTACH_BIND(o, attach);
		ATTACHMENT_DEBUG("http_attach_upfile{sid:'%s',name:'%s',type:'%s'}\n", attach->m_sid, attach->m_name, attach->m_type);
		return attach;
	}
	return NULL;
}

/**附件上传处理程序,从formdata中提取数据
 *@parameter o:http请求描述
 */
httpattach_t* http_attach_formdata(httpdescribe_t* o) //
{
	tb_engine_attach_t* rule = (tb_engine_attach_t*)to_parent_address(o->rule, tb_engine_attach_t, action);//匹配规则
	httpattach_t* attach = calloc(1, sizeof(httpattach_t)),*base_att;
	ATTACHMENT_DEBUG("rule:%p, data:'%p';\n", rule, rule->data);
	attach->rules = rule;
	if(http_formfiledata(o, formdata_fileparameters, attach) > 0) {
		if(attach->m_pktlen > 0) {
			//formdata 分包处理
			base_att = http_attach_findpart(o, attach);
			if(NULL == base_att) {//首个包
				base_att = attach;
				pthread_mutex_lock(&attach_lock);
				ATTACH_APPEND(o, base_att);
				pthread_mutex_unlock(&attach_lock);
			} else {
				//数据拷贝
				memcpy(base_att->data+attach->m_offset, attach->data, attach->m_pktlen);
				attach->m_time = time(NULL);
			}
		} else {
			//formdata非分包处理
			ATTACH_BIND(o, attach);
			ATTACHMENT_DEBUG("http_attach_formdata{sid:'%s',name:'%s',type:'%s'}\n", attach->m_sid, attach->m_name, attach->m_type);
		}
	} else {
		free(attach);
		attach = NULL;
	}
	return attach;
}


/**附件上传处理程序
 *@parameter o:http请求描述
 */
int http_attach_upload(httpdescribe_t* o)
{
	httpattach_t* attach;
	tb_engine_attach_t* rule = (tb_engine_attach_t*)to_parent_address(o->rule, tb_engine_attach_t, action);//匹配规则
	httpbuffer_t *http =  o->http;
	if(0 == strcasecmp(o->ctype->contenttype, "multipart/form-data")) {
		attach = http_attach_formdata(o);
		if(NULL != attach) {
			pthread_mutex_lock(&attach_lock);
			list_add_tail(&((attach)->list), &o->handles->attachs);
			pthread_mutex_unlock(&attach_lock);
			ATTACHMENT_DEBUG("add attach{%s:%s}\n", attach->m_domain, attach->m_uri);
		}
	} else if(!chars_is_empty(rule->aid)) {//分包处理
		attach = http_attach_partdata(o);
	} else if(NULL != (attach = http_attach_upfile(o))) {
		pthread_mutex_lock(&attach_lock);
		list_add_tail(&((attach)->list), &o->handles->attachs);
		pthread_mutex_unlock(&attach_lock);
		ATTACHMENT_DEBUG("add attach{%s:%s}\n", attach->m_domain, attach->m_uri);
	}
	return (NULL != attach);
}


/**将邮件,论坛中一个附件action的附件数据提取出来
 *@parameter o:HTTP引擎出来实例
 *@parameter act:
 *@parameter sid:匹配数据
 *@parameter list:挂载列表
 */
static inline int http_attach_per_action(httpengine_handle_t* o, tb_engine_actioni_t * act,  const char* sid, struct list_head* list)
{
	int result = 0;
	httpattach_t *pos, *n;
	time_t tm = time(NULL) - o->attach_timeout;

	list_for_each_entry_safe(pos, n, &o->attachs, list) {
		if(httpactionrules_contains(act, pos->m_method, pos->m_domain, pos->m_uri) && 0 == strcasecmp(sid, pos->m_sid)) {
			ATTACHMENT_DEBUG("rule:{domain:'%s',url:'%s'},pos:{domain:'%s',url:'%s',sid:'%s'}\n", act->domain, act->url, pos->m_domain, pos->m_uri, pos->m_sid);
			pthread_mutex_lock(&attach_lock);
			list_del(&(pos->list));//从原链表中删除
			list_add_tail(&(pos->list), list);//挂到list链表
			pthread_mutex_unlock(&attach_lock);
			result++;
		} else if(pos->m_time < tm) {//移除超时
			ATTACHMENT_DEBUG("second:%d,timeout:%d,otime:%d,domain:'%s',uri:'%s'\n", (int)o->attach_timeout, (int)tm, (int)pos->m_time, pos->m_domain, pos->m_uri);
			pthread_mutex_lock(&attach_lock);
			list_del(&(pos->list));//从原链表中删除
			http_attach_destory(pos);
			pthread_mutex_unlock(&attach_lock);
		}
	}
	return result;
}

/**将符合规则的附件移动到list中
 *@parameter o:HTTP引擎出来实例
 *@parameter rules:附件规则
 *@parameter sid:匹配数据
 *@parameter coll:挂载列表
 */
int http_attach_moveto(httpengine_handle_t* o, struct list_head * rules,  const char* sid, struct list_head* coll)
{
	int result = 0, pres = 0;
	if(rules) {
		tb_engine_actioni_t *pos, *n;
		list_for_each_entry_safe(pos, n, rules, attach_rules) {
			ATTACHMENT_DEBUG("%p:{domain:'%s',url:'%s'}\n", pos, pos->domain, pos->url);
			pres= http_attach_per_action(o, pos, sid, coll);
			result += pres;
		}
	}
	return result;
}

