/*
 * action_forum.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include "httpaction.h"
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"

/**
 * list_entry - 获得数据实体
 * @ptr: list_head结构体指针.
 * @type: 链表结构体名称.
 * @member: 链表头成员在结构体中的名称.
 */
#define to_parent_address(ptr, type, member) \
    ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))

static inline int forumdata_parameters(void* par, const char* key, const char* val, int vlen)
{
	httpforum_t *item = (httpforum_t*)par;
	tb_engine_forum_t* rule = (tb_engine_forum_t*)item->rules;//匹配规则
	if(chars_part_equals(rule->subject, key)) {//主题
		SET_BUFFER(item->m_subject, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->content, key)) {//内容
		item->m_content = calloc(1, vlen + 10);
		SET_BUFFER(item->m_content, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->sid, key)) {//附件
		SET_BUFFER(item->m_sid, val, vlen);
		return 1;
	}
	return 0;
}

static inline int forumdata_fileparameters(void* par, const char* key, const char* finalename, const char* filetype, const char* val, int vlen)
{
	httpforum_t *item = (httpforum_t*)par;
	tb_engine_forum_t* rule = (tb_engine_forum_t*)item->rules;//匹配规则

	if(chars_part_equals(rule->subject, key)) {//主题
		SET_BUFFER(item->m_subject, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->content, key)) {//内容
		item->m_content = calloc(1, vlen + 10);
		SET_BUFFER(item->m_content, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->sid, key)) {//附件
		SET_BUFFER(item->m_sid, val, vlen);
		return 1;
	}
	return 0;
}



/**转换HTML编码
 *@parameter mail:邮件
 */
static void http_forum_htmldecode(httpforum_t *mail)
{
	http_htmldecode(mail->m_subject, strlen(mail->m_subject));
	http_htmldecode(mail->m_content, strlen(mail->m_content));
}

int http_forum_formdata(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	tb_engine_forum_t* rule = (tb_engine_forum_t*)to_parent_address(o->rule, tb_engine_forum_t, action);//匹配规则item->rules
	httpforum_t item = { .rules = rule };
	INIT_LIST_HEAD(&(item.attachs));
	http_urlquery_each(o, forumdata_parameters, &item);
	if(http_formfiledata(o, forumdata_fileparameters, &item) <= 0) return -1;

	http_attach_moveto(o->handles, &(rule->action.attach_rules), item.m_sid, &(item.attachs));//匹配附件
	http_forum_htmldecode(&item);
	HTTPENGINE_CALLBACK(o->handles->cbkforum, item, e);
	if(item.m_content) free(item.m_content);
	return result;
}



int http_forum_urlencoded(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	tb_engine_actioni_t* rule_action = (tb_engine_actioni_t*)o->rule;//匹配规则
	tb_engine_forum_t* rule = (tb_engine_forum_t*)to_parent_address(o->rule, tb_engine_forum_t, action);//匹配规则item->rules
	httpforum_t item = { .rules = rule };
	INIT_LIST_HEAD(&(item.attachs));
	http_urlquery_each(o, forumdata_parameters, &item);
	if(http_postdata_each(o, forumdata_parameters, &item) <= 0) return -1;

	http_attach_moveto(o->handles, &(rule->action.attach_rules), item.m_sid, &(item.attachs));//匹配附件
	http_forum_htmldecode(&item);
	HTTPENGINE_CALLBACK(o->handles->cbkforum, item, e);
	if(item.m_content) free(item.m_content);
	return result;
}


int http_forum_regex(httpdescribe_t* o, tcpheader_t* e, vdata_t* dat)
{
	int result  = 0;
	tb_engine_forum_t* rule = (tb_engine_forum_t*)to_parent_address(o->rule, tb_engine_forum_t, action);//匹配规则item->rules
	httpforum_t item = { .rules = rule };
	INIT_LIST_HEAD(&(item.attachs));
	vdata_t vt;
	http_urlquery_each(o, forumdata_parameters, &item);

	if(regexpattern_match(dat->addr, rule->content, 1, &vt)) {//内容
		SET_BUFFER(item.m_content, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->subject, 1, &vt)) {//标题
		SET_BUFFER(item.m_subject, vt.addr, vt.length);
	}
	http_attach_moveto(o->handles, &(rule->action.attach_rules), item.m_sid, &(item.attachs));//匹配附件
	http_forum_htmldecode(&item);
	HTTPENGINE_CALLBACK(o->handles->cbkforum, item, e);
	if(item.m_content) free(item.m_content);
	return result;
}
