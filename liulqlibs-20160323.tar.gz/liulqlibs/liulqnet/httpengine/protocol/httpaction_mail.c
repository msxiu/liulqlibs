/*
 * action_mail.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include "httpaction.h"
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"

//给字段附件值
static inline int field_buffer_attach(char *src, int msl, const char* vs, int vl)
{
	int sln = strlen(src), vln = 0;
	if(sln > 0)  src[sln++] = ',';
	while(vln<vl && sln < msl) {
		*(src+sln) = *(vs+vln);
		sln++;
		vln++;
	}
	src[sln] = 0;
	return 1;
}

static inline int mail_parameter_urlencode(void* par, const char* key, const char* val, int vlen)
{
	httpmail_t *mail = (httpmail_t*)par;
	tb_engine_mail_t* rule = (tb_engine_mail_t*)mail->rules;//匹配规则
	if(chars_part_equals(rule->sender, key)) {//发送人
		SET_BUFFER(mail->m_sender, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->receiver, key)) {//接收人
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->cc, key)) {//抄送
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->bcc, key)) {//密送
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->subject, key)) {//主题
		SET_BUFFER(mail->m_subject, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->content, key)) {//内容
		mail->m_content = calloc(1, vlen + 10);
		SET_BUFFER(mail->m_content, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->sid, key)) {//附件
		SET_BUFFER(mail->m_sid, val, vlen);
		return 1;
	}
	return 0;
}
static inline int mail_parameters_formdata(void* par, const char* key, const char* finalename, const char* filetype, const char* val, int vlen)
{
	httpmail_t *mail = (httpmail_t*)par;
	tb_engine_mail_t* rule = (tb_engine_mail_t*)mail->rules;//匹配规则
	if(chars_part_equals(rule->sender, key)) {//发送人
		SET_BUFFER(mail->m_sender, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->receiver, key)) {//接收人
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->cc, key)) {//抄送
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->bcc, key)) {//密送
		return field_buffer_attach(mail->m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, val, vlen);
	}
	if(chars_part_equals(rule->subject, key)) {//主题
		SET_BUFFER(mail->m_subject, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->content, key)) {//内容
		mail->m_content = calloc(1, vlen + 10);
		SET_BUFFER(mail->m_content, val, vlen);
		return 1;
	}
	if(chars_part_equals(rule->sid, key)) {//附件
		SET_BUFFER(mail->m_sid, val, vlen);
		return 1;
	}
	return 0;
}



/**转换HTML编码
 *@parameter mail:邮件
 */
static void http_mail_htmldecode(httpmail_t *mail)
{
	http_htmldecode(mail->m_subject, strlen(mail->m_subject));
	http_htmldecode(mail->m_content, strlen(mail->m_content));
	http_htmldecode(mail->m_sender, strlen(mail->m_sender));
	http_htmldecode(mail->m_receiver, strlen(mail->m_receiver));
}
/**formdata方式内容解析邮件
 *@parameter o:HTTP请求描述
 *@parameter e:请求五元组数据
 */
int http_mail_formdata(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	tb_engine_mail_t* rule = (tb_engine_mail_t*)to_parent_address(o->rule, tb_engine_mail_t, action);//匹配规则
	httpmail_t mail = { .rules = rule };
	INIT_LIST_HEAD(&(mail.attachs));
	http_urlquery_each(o, mail_parameter_urlencode, &mail);
	if(http_formfiledata(o, mail_parameters_formdata, &mail) <= 0) return -1;

	HTTPACTION_DEBUG("http_mail_formdata:{sid:'%s'}\n", mail.m_sid);
	http_attach_moveto(o->handles, &(rule->action.attach_rules), mail.m_sid, &(mail.attachs));//匹配附件
	http_mail_htmldecode(&mail);
	HTTPENGINE_CALLBACK(o->handles->cbkmail, mail, e);
	if(mail.m_content) free(mail.m_content);
	return result;
}

/**URL编码方式内容解析邮件
 *@parameter o:HTTP请求描述
 *@parameter e:请求五元组数据
 */
int http_mail_urlencoded(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	tb_engine_mail_t* rule = (tb_engine_mail_t*)to_parent_address(o->rule, tb_engine_mail_t, action);//匹配规则
	httpmail_t mail = { .rules = rule };
	INIT_LIST_HEAD(&(mail.attachs));
	http_urlquery_each(o, mail_parameter_urlencode, &mail);
	if(http_postdata_each(o, mail_parameter_urlencode, &mail) <= 0) return -1;

	http_attach_moveto(o->handles, &(rule->action.attach_rules), mail.m_sid, &(mail.attachs));//匹配附件
	HTTPACTION_DEBUG("http_mail_urlencoded:{sid:'%s'}\n", mail.m_sid);
	http_mail_htmldecode(&mail);
	HTTPENGINE_CALLBACK(o->handles->cbkmail, mail, e);
	if(mail.m_content) free(mail.m_content);
	return result;
}

/**正则表达式解析邮件
 *@parameter o:HTTP请求描述
 *@parameter e:请求五元组数据
 *@parameter dat:urldecode 后的数据内容
 */
int http_mail_regex(httpdescribe_t* o, tcpheader_t* e, vdata_t* dat)
{
	int result  = 0;
	tb_engine_mail_t* rule = (tb_engine_mail_t*)to_parent_address(o->rule, tb_engine_mail_t, action);//匹配规则
	httpmail_t mail = { .rules = rule };
	vdata_t vt;

	INIT_LIST_HEAD(&(mail.attachs));

	http_urlquery_each(o, mail_parameter_urlencode, &mail);
	if(regexpattern_match(dat->addr, rule->sender, 1, &vt)) {//发送者
		SET_BUFFER(mail.m_sender, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->receiver, 1, &vt)) {//接收者
		field_buffer_attach(mail.m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->cc, 1, &vt)) {//抄送
		field_buffer_attach(mail.m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->bcc, 1, &vt)) {//秘送
		field_buffer_attach(mail.m_receiver, MSG_SENSITIVE_ALERT_RECEIVE_LEN - 1, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->content, 1, &vt)) {//内容
		mail.m_content = calloc(1, vt.length + 10);
		SET_BUFFER(mail.m_content, vt.addr, vt.length);
	}
	if(regexpattern_match(dat->addr, rule->subject, 1, &vt)) {//标题
		SET_BUFFER(mail.m_subject, vt.addr, vt.length);
	}

	HTTPACTION_DEBUG("http_mail_regex:{sid:'%s'} %d \n", mail.m_sid, result);
	result  = http_attach_moveto(o->handles, &(rule->action.attach_rules), mail.m_sid, &(mail.attachs));//匹配附件

	//result = http_mall_acbm(&mail);
	http_mail_htmldecode(&mail);
	HTTPENGINE_CALLBACK(o->handles->cbkmail, mail, e);
	if(mail.m_content) free(mail.m_content);
	return result;
}
