/*
 * httpbuffer.c
 *
 *  Created on: 2016年2月26日
 *      Author: root
 */
#include <stdio.h>

#include "httpaction.h"

#define MAX_HTTP_HEAD		1400
#define MAX_HEADER(x)			(x>MAX_HTTP_HEAD ? MAX_HTTP_HEAD : x)

char httpbuffer_start(const char*p, int sln)//HTTP协议头识别
{
	if(!p||!*p) return 0;
	const char * p1 = (p+1);
	switch(*p) {
	case 'H'://HEAD|HTTTP/
		if(sln > 5 && buffer_equals(p1, "TTP/", 4)) return 2;//响应
		if(sln > 5 && buffer_equals(p1, "EAD ", 4) ) return 1;//HEAD请求
		break;
	case 'G'://GET
		if(sln > 4 && buffer_equals(p1, "ET ", 3)) return 1;
		break;
	case 'P'://POST|PUT
		if((sln > 5 && buffer_equals(p1, "OST ", 4)) || (sln > 4 && buffer_equals(p1, "UT ", 3))) return 1;
		break;
	case 'O'://OPTIONS
		if(sln > 8 && buffer_equals(p1, "PTIONS ", 7)) return 1;
		break;
	case 'D'://DELETE
		if(sln > 7 && buffer_equals(p1, "ELETE ", 6)) return 1;
		break;
	case 'T'://TARCE
		if(sln > 6 && buffer_equals(p1, "ARCE ", 5)) return 1;
		break;
	}
	return 0;
}

int httpbuffer_comfirm(httpbuffer_t *o)//判断缓存流是否为HTTP协议
{
	const char* p = o->data;
	int state = httpbuffer_start(p, o->length);
	int pos =0, len = MAX_HEADER(o->length);
	switch(state) {
	case 2://HTTP应答
		while(p[pos] && p[pos] != ' ') pos++;
		o->method = pos++;
		while(p[pos] && p[pos] != ' ') pos++;
		if((pos - o->method - 1) != 3) return 0;
		if(buffer_is_numeric(p+o->method + 1, 3)) return state;
		break;
	case 1://HTTP请求
		while(p[pos] && pos < len && p[pos] != '\n') {
			if(p[pos] == ' ') {
				if(!o->method) {
					o->method = pos;
				} else {
					o->url = pos;
				}
			}
			pos++;
		}
		o->varsion = pos;
		if(p[pos] != '\n' || pos>= len || !o->method || !o->url) return 0;
		if (0 == strncmp((p + o->url + 1), "HTTP/", 5))  return state;
		break;
	}
	return 0;
}


int httpbuffer_header(httpbuffer_t *o)//从一端buffer数据中解析出http头部长度
{
	const char* hv = o->data;
	int retval = 0;
	while(*(hv + retval) && retval < o->length) {
		if(retval>3 && hv[retval] == '\n' && hv[retval - 1] == '\r' && hv[retval - 2] == '\n' && hv[retval - 3] == '\r') {
			retval++;
			o->header = retval;
			return retval;
		}
		retval++;
	}
	return 0;
}

int httpbuffer_key(httpbuffer_t *o, const char* key, int* len)//从o->data头数据中查找key开头的行
{
	const char* sp = o->data;
	int result = 0, pos = 0, skln = strlen(key);
	while(result < o->header) {
		if(chars_start_with_ignore(sp, key)) {
			result += skln;
			while(char_is_empty(*(o->data + result))) result++;//去掉头部空格
			*len =  buffer_line_length(o->data + result);//设置行长度
			while(char_is_empty(*(o->data + result + *len)))  (*len)--;//去掉尾部空格
			(*len)++;
			return result;
		}
		pos = buffer_line_length(sp);
		if(sp[pos] == '\0') break;
		sp += (pos + 1);
		result += (pos + 1);
	}
	return -1;
}

int httpbuffer_headkey(httpbuffer_t *o, const char* key, vdata_t* val)//从o->data头数据中查找key开头的行
{
	const char* sp = o->data;
	int result = 0, pos = 0, skln = strlen(key);
	int len = 0;
	while(result < o->header) {
		if(chars_start_with_ignore(sp, key)) {
			result += skln;
			while(char_is_empty(*(o->data + result))) result++;//去掉头部空格
			len =  buffer_line_length(o->data + result);//设置行长度
			while(char_is_empty(*(o->data + result + len)))  len--;//去掉尾部空格
			(len)++;
			val->addr = (char*) (o->data + result);
			val->length = len;
			return result;
		}
		pos = buffer_line_length(sp);
		if(sp[pos] == '\0') break;
		sp += (pos + 1);
		result += (pos + 1);
	}
	return -1;
}

static inline httpbuffer_body(httpbuffer_t *o)//提取buffer中body的长度
{
		int pos, sln;
		const char *sp = o->data;
		pos = httpbuffer_key(o, "content-length:", &sln);
		if(pos > -1) {
			char bln[sln+1];
			SET_BUFFER(bln, sp + pos, sln);
			o->body = atoi(bln);
		}
}

int httpbuffer_context(httpbuffer_t *o)//确定缓存数据是否为HTTP协议,并解析HTTP协议
{
	//int state = http_protocol_start(o->data);
	if(httpbuffer_comfirm(o)) {
		httpbuffer_header(o);
		httpbuffer_body(o);
		return 1;
	}
	return 0;
}
