/*
 * action_pan.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include "httpaction.h"
#include "liulqcore.h"


int http_pan_formdata(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	httpattach_t* attach = (httpattach_t*)http_attach_formdata(o);
	HTTPENGINE_CALLBACK(o->handles->cbkpan, attach, e);
	return result;
}



int http_pan_attach(httpdescribe_t* o, tcpheader_t* e)
{
	int result  = 0;
	httpattach_t* attach = (httpattach_t*)http_attach_upfile(o);
	HTTPENGINE_CALLBACK(o->handles->cbkpan, attach, e);
	return result;
}

