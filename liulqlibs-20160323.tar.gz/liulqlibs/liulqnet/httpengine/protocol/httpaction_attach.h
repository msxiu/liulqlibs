/*
 * httpaction_attach.h
 *
 *  Created on: 2016年3月21日
 *      Author: root
 */

#ifndef LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_ATTACH_H_
#define LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_ATTACH_H_
#include <stdio.h>

/**从formdata的文件数据中解析数据
 *@parameter par:
 *@parameter key:
 *@parameter filename:
 *@parameter filetype:
 *@parameter val:
 *@parameter len:
 */
static int formdata_fileparameters(void* par, const char* key, const char* filename, const char* filetype, const char* val, int vlen)//文件上传
{
	httpattach_t* attach = (httpattach_t*)par;
	tb_engine_attach_t* rule = attach->rules;
	//GDB_DEBUGS("key:'%s', pkey:'%s',filename:'%s',filetype:'%s';\n", key, rule->data, filename, filetype);
	//GDB_DEBUGS("rule:%p{data:'%p',cook:'%p',sid:'%s'};\n", rule, rule->data, rule->cook, rule->sid);
	if(0 == strcasecmp(key, rule->data)) {
		strcpy(attach->m_name, filename);
		strcpy(attach->m_type, filetype);
		attach->m_time = time(NULL);
		attach->m_size = vlen;
		attach->data = calloc(1, vlen+10);
		memcpy(attach->data, val, vlen);
		return 1;
	}

	if(0 == strcasecmp(key, rule->offset)) {//分包处理,表示该包在整个附件中的数据偏移
		PARSE_INT_OF(attach->m_offset, val, vlen);
	} else  if(0 == strcasecmp(key, rule->length)) {//分包处理,表示该包的数据长度
		PARSE_INT_OF(attach->m_pktlen, val, vlen);
	} else  if(0 == strcasecmp(key, rule->size)) {//分包处理,表示整个附件长度
		PARSE_INT_OF(attach->m_size, val, vlen);
	} else if(0 == strcasecmp(key, rule->sid)) {//处理附件关联
		SET_BUFFER(attach->m_sid, val, vlen);
	}
	return 0;
}
static int urlquery_parameters(void* par, const char* key, const char* val, int vlen)//查询参数
{
	httpattach_t* attach = (httpattach_t*)par;
	tb_engine_attach_t* rule = attach->rules;
	if(0 == strcasecmp(key, rule->sid)) {
		SET_BUFFER(attach->m_sid, val, vlen);//处理附件关联
		//GDB_DEBUGS("object:%p,key:'%s:%s',sid:'%s';\n", par, key, rule->sid, attach->m_sid);
		return 0;
	}
	return 0;
}
static int cookie_parameters(void* par, const char* key, const char* val, int vlen)//cookie
{
	httpattach_t* attach = (httpattach_t*)par;
	tb_engine_attach_t* rule = attach->rules;
	if(0 == strcasecmp(key, rule->cook)) {
		SET_BUFFER(attach->m_sid, val, vlen);//处理附件关联
		return 0;
	}
	return 0;
}

#endif /* LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_ATTACH_H_ */
