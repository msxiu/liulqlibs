/*
 * maskdebug.h
 *
 *  Created on: 2016年3月18日
 *      Author: root
 */

#ifndef LIULQNET_HTTPENGINE_MASKDEBUG_H_
#define LIULQNET_HTTPENGINE_MASKDEBUG_H_

/*调试规则*/
#ifdef DEBUG_RULES
#define RULES_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#define RULES_EXECUTE(execute)		(execute)
#else
#define RULES_DEBUG(format, args...)  {}while(0)
#define RULES_EXECUTE(execute)
#endif

//调试HTTP数据
#ifdef DEBUG_HTTPDATA
#define HTTPDATA_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else
#define HTTPDATA_DEBUG(format, args...)  {}while(0)
#endif

//调试HTTP响应
#ifdef DEBUG_HTTPACTION
#define HTTPACTION_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else
#define HTTPACTION_DEBUG(format, args...)  {}while(0)
#endif

//调试HTTP响应
#ifdef DEBUG_ATTACHMENT
#define ATTACHMENT_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else
#define ATTACHMENT_DEBUG(format, args...)  {}while(0)
#endif

#endif /* LIULQNET_HTTPENGINE_MASKDEBUG_H_ */
