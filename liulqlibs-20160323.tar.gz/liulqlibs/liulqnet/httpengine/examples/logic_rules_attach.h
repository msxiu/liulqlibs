/*
 * logic_rules_attach.h
 *
 *  Created on: 2016年3月2日
 *      Author: root
 */

#ifndef HTTPENGINE_EXAMPLES_LOGIC_RULES_ATTACH_H_
#define HTTPENGINE_EXAMPLES_LOGIC_RULES_ATTACH_H_
#include "httpengine.h"

static tb_engine_attach_t rules_attach[] = {
		{//百度网盘
				.ruletype = HTTP_AUDIT_PAN, .ruleid=0,.sid="sid", .cook="",
				.action = 		{
						.id=3, .method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_PAN , .urltype = URLCOMPARE_STARTWITH,
						.domain = "pan.baidu.com", .url ="/rest/2.0/pcs/superfile2"
				},
		},
		{//mail-163附件(formdata)
				.ruletype = HTTP_AUDIT_MAIL, .ruleid=1, .sid="sid", .cook="", .data="filedata",
				.action = {
						.id=1, .method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_ATTACH, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
						.domain = "t3bj.mail.163.com", .url ="/upxmail/upload"
				},
		},
		{//mail-163附件(part packet)
				.ruletype = HTTP_AUDIT_MAIL, .ruleid=1,
				.sid="sid", .name="mail-upload-name:", .aid="mail-upload-aid:", .offset="mail-upload-offset:", .length="mail-upload-length:", .size="mail-upload-size:",
				.action =  {
						.id=2,.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_ATTACH, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
						.domain = "t4bj.mail.163.com", .url ="/upxmail/upload"
				},
		},
		{//附件-新浪邮箱(http post)
				.ruletype = HTTP_AUDIT_MAIL, .ruleid=4,.sid="email", .cook="", .data="filedata",
				.action = {
						.id=3, .method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
						.domain = "m0.mail.sina.com.cn", .url ="/classic/uploadatt.php"
				},
		},
		{//附件-QQ邮箱
				.ruletype = HTTP_AUDIT_MAIL, .ruleid=2,.sid="sid", .cook="",
				.action={
						.id=3, .method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
						.domain = "set2.mail.qq.com", .url ="/rest/2.0/pcs/superfile2"
				},
		},
		0
};





#endif /* HTTPENGINE_EXAMPLES_LOGIC_RULES_ATTACH_H_ */
