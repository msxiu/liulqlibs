/*
 * logic_rules_action.c
 *
 *  Created on: 2016年3月2日
 *      Author: root
 */
#include "httpaction.h"
#include "liulqdebug.h"

#ifndef DETECT_HTTP_EXAMPLES_LOGIC_RULES_ACTION_H_
#define DETECT_HTTP_EXAMPLES_LOGIC_RULES_ACTION_H_



static  tb_engine_mail_t rules_mail[] = {
		{//mail-163
				.action = {
					.id = 1,
						.resolve =HTTP_RESOLVE_URLDECODE_REGEX,//内容解析方式
						.rule = HTTP_AUDIT_MAIL,//审计规则
						.method = HTTP_METHD_POST,//请求方式
						.domain = "mail.163.com",//域名
						.urltype = URLCOMPARE_STARTWITH,
						.url ="/js6/s",//URL网址
						.charset="utf-8",//字符编码
						//.attachs=NULL,//挂载附件规则列表
				},
				.subject = "name=\"subject\">([\\s\\S]+?)</string>",
				.sender = "name=\"account\">([\\s\\S]+?)</string>",
				.receiver="name=\"to\"><string>([\\s\\S]+?)</string>",
				.cc = "name=\"cc\"><string>([\\s\\S]+?)</string>",
				.bcc = "name=\"bcc\"><string>([\\s\\S]+?)</string>",
				.content = "name=\"content\">([\\s\\S]+?)</string>",
				.sid="sid",
		}, {//mail-qqQQ邮箱
			.action = {
				.id=2,
					.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_URLDECODE, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
					.domain = "set2.mail.qq.com", .urltype = URLCOMPARE_STARTWITH,.url ="/cgi-bin/compose_send"
			},
			.subject = "subject", .sender = "sendmailname", .receiver="to", .cc = "cc", .bcc = "bcc", .content = "content_html",
			.sid="sid",
		}, {//mail-sohu搜狐邮箱
			.action = {
				.id=3,
					.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_URLDECODE, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
					.domain = "mail.sohu.com", .url ="/bapp/52/mail"
			},
			.subject = "subject", .sender = "sendmailname", .receiver="to", .cc = "cc", .bcc = "bcc", .content = "content_html"
		}, {//mail-sina
			.action = {//新浪邮箱
				.id=4,
					.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
					.domain = "m0.mail.sina.com.cn", .url ="/classic/send.php"
			},
			.subject = "subj", .sender = "from", .receiver="to", .cc = "cc", .bcc = "bcc",	.content = "msgtxt", .sid="sender",
		},
		0,
};


//static tb_engine_actioni_t rules_actions[]= {//过滤请求
//		{ //mail-163邮件
//				.id = 1,
//				.resolve =HTTP_RESOLVE_URLDECODE_REGEX,//内容解析方式
//				.rule = HTTP_AUDIT_MAIL,//审计规则
//				.rulenode= 1 ,//规则节点
//				.method = HTTP_METHD_POST,//请求方式
//				.domain = "mail.163.com",//域名
//				.urltype = URLCOMPARE_STARTWITH,
//				.url ="/js6/s",//URL网址
//				.charset="utf-8",//字符编码
//				//.attachs=NULL,//挂载附件规则列表
//		}, {//QQ邮箱
//				.id = 2,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_URLDECODE, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 2 , .domain = "set2.mail.qq.com", .urltype = URLCOMPARE_STARTWITH,.url ="/cgi-bin/compose_send"
//		}, {//搜狐邮箱
//				.id=3,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_URLDECODE, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 3 , .domain = "mail.sohu.com", .url ="/bapp/52/mail"
//		}, {//新浪邮箱
//				.id=4,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_MAIL, .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 4 , .domain = "m0.mail.sina.com.cn", .url ="/classic/send.php"
//		},
//
//		{//中华军事论坛
//				.id=5,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_FORUM, .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1 , .domain = "bbs.china.com", .url ="/jsp/bpu/controler.do"
//		}, {//天涯论坛
//				.id=6,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_FORUM, .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 2 , .domain = "bbs.tianya.com", .url ="/api?"
//		},
//
//		{//百度网盘
//				.id = 7,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_PAN , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1 , .domain = "pan.baidu.com", .url ="/rest/2.0/pcs/superfile2"
//		},
//
//
//
//
//		{//mail-163附件
//				.id = 1001,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_ATTACH, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 2 , .domain = "t4bj.mail.163.com", .url ="/upxmail/upload"
//		}, {//mail-163附件
//				.id = 1002,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_ATTACH, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 3 , .domain = "t3bj.mail.163.com", .url ="/upxmail/upload"
//		},{//附件-新浪邮箱
//				.id = 1003,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1 , .domain = "m0.mail.sina.com.cn", .url ="/classic/uploadatt.php"
//		}, {//附件-QQ邮箱
//				.id = 1004,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1 , .domain = "set2.mail.qq.com", .url ="/rest/2.0/pcs/superfile2"
//		}, {
//				.id = 1005,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1 , .domain = "attach.baidu.com", .url ="/rest/2.0/pcs/superfile2"
//		}, {
//				.id = 1006,
//				.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_ATTACH , .urltype = URLCOMPARE_STARTWITH,
//				.rulenode= 1, .domain = "attach.baidu.com", .url ="/rest/2.0/pcs/superfile2"
//		},
//		0, 0
//};



#endif /* DETECT_HTTP_EXAMPLES_LOGIC_RULES_ACTION_H_ */
