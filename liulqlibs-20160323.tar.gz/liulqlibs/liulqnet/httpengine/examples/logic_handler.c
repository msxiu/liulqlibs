/*
 * main_logic.c
 *
 *  Created on: 2016年2月29日
 *      Author: root
 */
#include "../../httpengine/httpaction.h"
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"


/**邮件处理
 *
 */
void http_mall_handler(httpmail_t* mail, tcpheader_t* e)
{
	httpattach_t *pos, *n;
	GDB_DEBUGS("mail address:%p;\n", mail);
	printf("sender:%s;\n", mail->m_sender);
	printf("receiver:%s;\n", mail->m_receiver);
	printf("subject:%s;\n", mail->m_subject);
	printf("content:%s;\n", mail->m_content);

	list_for_each_entry_safe(pos, n, &mail->attachs, list) {
		printf("attach:{'%s':'%s',%d};\n", pos->m_name, pos->m_type, (int)pos->m_size);
		list_del(&(pos->list));//从原链表中删除
		http_attach_destory(pos);
	}
	//return 0;
}

void http_forum_handler(httpforum_t* item)
{
	httpattach_t *pos, *n;
	GDB_INFOS("item address:%p;\n", item);
	printf("subject:%s;\n", item->m_subject);
	printf("content:%s;\n", item->m_content);
	list_for_each_entry_safe(pos, n, &item->attachs, list) {
		printf("attach:{'%s':'%s',%d};\n", pos->m_name, pos->m_type, (int)pos->m_size);
		list_del(&(pos->list));//从原链表中删除
		http_attach_destory(pos);
	}
	//return 0;
}

void http_pan_handler(httpattach_t* pos)
{
	GDB_DEBUGS("attach:{'%s':'%s',%d};\n", pos->m_name, pos->m_type, (int)pos->m_size);
	//return 0;
}

