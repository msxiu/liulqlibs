/* logic_rules.c
 *  Created on: 2016年3月2日
 *  Author: 刘龙强
 *  HTTP协议规则初始化
 */
#include <stdlib.h>

#include "logic_rules_attach.h"
#include "logic_rules_forum.h"
#include "logic_rules_mail.h"
#include "httpaction.h"
#include "httpengine.h"
#include "list.h"
#include "liulqdebug.h"
#include "logic_rules_mail.h"


#define ENGINE_MAKE(T, V, o, mid) {\
	int cnt = 0, mln, i =0;\
	T *ds = (T*)V;\
	while(ds->action.id) {\
		cnt++;\
		ds++;\
		if(*mid < ds->action.id) { *mid = ds->action.id; }\
	}\
	mln = (cnt * sizeof(T));\
	o= (tbrecords_t*)calloc(1, mln + sizeof(tbrecords_t));\
	o->length = cnt;\
	memcpy(o->records, V, mln);\
	for(i=0;i<o->length;i++) {\
		tb_engine_actioni_t* act = &((((T*)o->records)+i)->action);\
		INIT_LIST_HEAD(&(act->attach_rules));\
	}\
}while(0)



tbrecords_t* tipsdb_engine_mail(int* maxid)
{
	tbrecords_t*list;
	ENGINE_MAKE(tb_engine_mail_t, rules_mail, list, maxid);
	return list;
}

tbrecords_t* tipsdb_engine_foruml(int* maxid)
{
	tbrecords_t*list;
	ENGINE_MAKE(tb_engine_forum_t, rules_forum, list, maxid);
	return list;
}

tbrecords_t* tipsdb_engine_attach(int* maxid)
{
	tbrecords_t*list;
	ENGINE_MAKE(tb_engine_attach_t, rules_attach, list, maxid);
	return list;
}
