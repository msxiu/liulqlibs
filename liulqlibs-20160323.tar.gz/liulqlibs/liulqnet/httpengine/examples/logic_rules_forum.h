/*
 * logic_rules_content.h
 *
 *  Created on: 2016年3月2日
 *      Author: root
 */

#ifndef HTTPENGINE_EXAMPLES_LOGIC_RULES_FORUM_H_
#define HTTPENGINE_EXAMPLES_LOGIC_RULES_FORUM_H_
#include "httpengine.h"



static tb_engine_forum_t rules_forum[] = {
		{
				.action={//中华军事论坛
					.id=1,
						.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_FORUM, .urltype = URLCOMPARE_STARTWITH,
						.domain = "bbs.china.com", .url ="/jsp/bpu/controler.do"
				},
				.subject = "subj",  .content = "msgtxt"
		}, {
				.action = {//天涯论坛
					.id=2,
						.method = HTTP_METHD_POST, .resolve =HTTP_RESOLVE_FORMDATA, .rule = HTTP_AUDIT_FORUM, .urltype = URLCOMPARE_STARTWITH,
						.domain = "bbs.tianya.com", .url ="/api?"
				},
				.subject = "subj",  .content = "msgtxt"
		},
		0,
};

//tb_engine_mapattach_t rules_mapattachs[] ={
//		{ .actionid = 1, .attachid = 1001},//163邮箱
//		{ .actionid = 2, .attachid = 1002},//163邮箱
//
//		{ .actionid = 4, .attachid = 1004},//QQ邮箱
//
//		{ .actionid = 5, .attachid = 1001},//SOHU邮箱
//
//		{ .actionid = 3, .attachid = 1003 },//SINA邮箱
//};



#endif /* HTTPENGINE_EXAMPLES_LOGIC_RULES_FORUM_H_ */
