/*
 * logic_cachefile.c
 *
 *  Created on: 2016年3月2日
 *      Author: root
 */
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#include "httpaction.h"
#include "list.h"
#include "liulqcore.h"

extern dhttpconf_t detectconf;
httpengine_handle_t  httphandler = { .attach_timeout = 900 };

extern void http_mall_handler(httpmail_t* mail, tcpheader_t* e);
extern void http_forum_handler(httpforum_t* item, tcpheader_t* e);
extern void http_pan_handler(httpattach_t* pos, tcpheader_t* e);

tbrecords_t* rs_mail, *rs_forum, *rs_attach;//, *rs_mapattach;
//http处理者初始化
void httphandler_initialize()
{
	int mid_action = 0,mid_mail = 0, mid_forum = 0,mid_attach = 0,mid_mapattach = 0;
	INIT_LIST_HEAD(&(httphandler.attachs));

	multifile_folder(&httphandler, detectconf.rulepath);

	httpdescribe_addhandler_mail(&httphandler, http_mall_handler);//添加邮件处理回调函数
	httpdescribe_addhandler_forum(&httphandler, http_forum_handler);//添加论坛处理回调函数
	httpdescribe_addhandler_pan(&httphandler, http_pan_handler);//添加网盘处理回调函数

}

void httphandler_destory()
{
	httpactionrules_destory(&httphandler);
}

/**不带五元组的数据流处理
 * @parameter addr:文件地址
 */
static void file_handler_head0(const char* addr)
{
	printf("file_handler_head0:'%s';\n", addr);
	int fln = file_size(addr);
	int sln = sizeof(tcpstream_t) + fln + 10;
	char *buffer = (char*) malloc(sln);
	if(NULL != buffer) {
		memset(buffer, 0, sln);
		tcpstream_t* o = (tcpstream_t*)buffer;
		o->length= fln;
		char* sbuf = (char*)o->buffer;
		file_read_tobuffer(addr, sbuf);
		fln = http_action(&httphandler, o);
		free(buffer);
	} else {
		printf("malloc error!\n");
	}
}
/**不带五元组的数据流处理
 * @parameter addr:文件地址
 */
static void file_handler_head1(const char* addr)
{
	printf("file_handler_head1:'%s';\n", addr);
	int fln = file_size(addr);
	int sln = sizeof(tcpstream_t) + fln + 10;
	char *buffer = (char*) malloc(sln);
	if(NULL != buffer) {
		memset(buffer, 0, sln);
		file_read_tobuffer(addr, buffer);
		tcpstream_t* o = (tcpstream_t*)buffer;
		fln = http_action(&httphandler, o);
		free(buffer);
	} else {
		printf("malloc error!\n");
	}
}


/** 但个文件数据处理
 *@parameter addr:文件地址
 */
void file_handler(const char* addr)
{
	if(detectconf.head_style) {
		file_handler_head1(addr);
	} else {
		file_handler_head0(addr);
	}
}

/** 批量文件数据处理,文件一行是一个文件数据
 *@parameter addr:文件地址
 */
int file_handler_list(const char* addr)
{
	printf("file_handler_list:%s;\n", addr);
	return file_linecallback(addr, file_handler);
}
