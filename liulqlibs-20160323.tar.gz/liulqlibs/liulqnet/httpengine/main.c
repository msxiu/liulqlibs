/*
 * httpaction.c
 *
 *  Created on: 2016年1月29日
 *      Author: root
 */
#include "../httpengine/httpaction.h"
#include "liulqdebug.h"
#include "liulqcore.h"

//extern httpengine_handle_t  httphandler;
extern void load_configure();

void test_htmldecode()
{
	char buffer[256] = "&lt;div&gt;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&quot;OK!&quot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/div&gt;";
	printf("htmldecode:%s\n", buffer);
	http_htmldecode(buffer, 256);
	printf("htmldecode:%s\n", buffer);
}

int main(int argc, char* argv[])
{
	int i = 0;
	load_configure();
	httphandler_initialize();

	switch(argc) {
	case 1://默认处理
		file_handler_list("./index.list");
		break;
	case 2:
		if(chars_end_with_ignore(argv[1], ".list")) {
			file_handler_list(argv[1]);//列表文件处理
		} else {
			file_handler(argv[1]);//单个文件处理
		}
		break;
	default: {//多文件处理
			for(i=1;i<argc;i++) {
				file_handler(argv[i]);
			}
		}
		break;
	}
	//httpactionrule_destory();
	httphandler_destory();
}




