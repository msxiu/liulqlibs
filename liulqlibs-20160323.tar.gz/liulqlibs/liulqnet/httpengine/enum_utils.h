/*
 * httprule_utils.h
 *
 *  Created on: 2016年3月18日
 *      Author: root
 */

#ifndef LIULQNET_HTTPENGINE_HTTPRULE_HTTPRULE_UTILS_H_
#define LIULQNET_HTTPENGINE_HTTPRULE_HTTPRULE_UTILS_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

//审计规则
static inline const char* getenum_HTTP_AUDIT_RULE(enum HTTP_AUDIT_RULE rule)
{
	switch(rule) {
	case HTTP_AUDIT_MAIL: return "HTTP_AUDIT_MAIL";
	case HTTP_AUDIT_FORUM: return "HTTP_AUDIT_FORUM";
	case HTTP_AUDIT_ATTACH: return "HTTP_AUDIT_ATTACH";
	case HTTP_AUDIT_PAN: return "HTTP_AUDIT_PAN";
	case HTTP_AUDIT_NONE: return "HTTP_AUDIT_NONE";
	}
	return NULL;
}
//HTTP请求方式
static inline const char* getenum_HTTP_METHD(enum HTTP_METHD method)
{
	switch(method) {
	case HTTP_METHD_ANY: return "HTTP_METHD_ANY";
	case HTTP_METHD_GET: return "HTTP_METHD_GET";
	case HTTP_METHD_POST: return "HTTP_METHD_POST";
	}
	return NULL;
}
//URL比较类型
static inline const char* getenum_URLCOMPARE_TYPE(enum URLCOMPARE_TYPE  type)
{
	switch(type) {
	case URLCOMPARE_IGNORE: return "URLCOMPARE_IGNORE";
	case URLCOMPARE_CONTAIN: return "URLCOMPARE_CONTAIN";
	case URLCOMPARE_STARTWITH: return "URLCOMPARE_STARTWITH";
	case URLCOMPARE_ENDWITH: return "URLCOMPARE_ENDWITH";
	}
	return NULL;
}
//http内容解析规则
static inline const char* getenum_HTTPCONTENT_RESOLVE(enum HTTPCONTENT_RESOLVE resolve)
{
	switch(resolve) {
	case HTTP_RESOLVE_FORMDATA: return "HTTP_RESOLVE_FORMDATA";
	case HTTP_RESOLVE_URLDECODE: return "HTTP_RESOLVE_URLDECODE";
	case HTTP_RESOLVE_ATTACH: return "HTTP_RESOLVE_ATTACH";
	case HTTP_RESOLVE_URLDECODE_REGEX: return "HTTP_RESOLVE_URLDECODE_REGEX";
	case HTTP_RESOLVE_REGEX_URLDECODE: return "HTTP_RESOLVE_REGEX_URLDECODE";
	}
	return NULL;
}

static inline void ruleshow_tb_engine_action(tb_engine_actioni_t* o)
{
	printf("{\n\t\tid:%d,\n\t\tresolve:%s,\n\t\trule:%s,\n\t\tmethod:%s,\n\t\tdomain:'%s',\n\t\turltype:%s,\n\t\turl:'%s',\n\t\tcharset:'%s'\n\t}",
		o->id,
		getenum_HTTPCONTENT_RESOLVE(o->resolve),
		getenum_HTTP_AUDIT_RULE(o->rule),
		getenum_HTTP_METHD(o->method),
		o->domain,
		getenum_URLCOMPARE_TYPE(o->urltype),
		o->url,
		o->charset
	);

}

static inline void ruleshow_tb_engine_mail(tb_engine_mail_t* o)
{
	printf("%p=>engine_mail:{\n\taction:", o);
	ruleshow_tb_engine_action(&(o->action));
	printf(",\n\tsid:'%s',\n\tsender:'%s',\n\treceiver:'%s',\n\tcc:'%s',\n\tbcc:'%s',\n\tsubject:'%s',\n\tcontent:'%s',\n\tmask:%d\n},\n",
			o->sid,
			o->sender,
			o->receiver,
			o->cc,
			o->bcc,
			o->subject,
			o->content,
			o->mask
	);
}

static inline void ruleshow_tb_engine_forum(tb_engine_forum_t* o)
{
	printf("%p=>engine_forum:{\n\taction:",o);
	ruleshow_tb_engine_action(&(o->action));
	printf(",\n\tsid:'%s',\n\tsubject:'%s',\n\tcontent:'%s'\n},\n",
			o->sid,
			o->subject,
			o->content
	);
}

static inline void ruleshow_tb_engine_attach(tb_engine_attach_t* o)
{
	printf("%p=>engine_attach:{\n\taction:", o);
	ruleshow_tb_engine_action(&(o->action));
	printf(",\n\tsid:'%s',\n\tcook:'%s',\n\tdata:'%s'\n\truletype:%s,\n\truleid:%d,\n\taid:'%s',\n\tname:'%s',\n\toffset:'%s',\n\tlength:'%s',\n\tsize:'%s'\n},\n",
			o->sid,
			o->cook,
			o->data,
			getenum_HTTP_AUDIT_RULE(o->ruletype),
			o->ruleid,
			o->aid,
			o->name,
			o->offset,
			o->length,
			o->size
	);
}
#endif /* LIULQNET_HTTPENGINE_HTTPRULE_HTTPRULE_UTILS_H_ */
