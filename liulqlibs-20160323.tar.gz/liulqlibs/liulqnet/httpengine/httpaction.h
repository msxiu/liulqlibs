/*
 * discern_http.h
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */

#ifndef LIULQNET_CAPTURE_DISCERN_HTTP_H_
#define LIULQNET_CAPTURE_DISCERN_HTTP_H_
#include <stdint.h>
#include <time.h>

#include "httpengine.h"
#include "liulqcore.h"
#include "maskdebug.h"




extern int httpbuffer_comfirm(httpbuffer_t *o);//判断缓存流是否为HTTP协议
extern int httpbuffer_header(httpbuffer_t *o);//从一端buffer数据中解析出http头部长度
extern int httpbuffer_key(httpbuffer_t *o, const char* key, int* len);//从o->data头数据中查找key开头的行
extern int httpbuffer_headkey(httpbuffer_t *o, const char* key, vdata_t* val);//从o->data头数据中查找key开头的行
extern int httpbuffer_context(httpbuffer_t *o);//确定缓存数据是否为HTTP协议,并解析HTTP协议

//**http_form_data*********************************************
typedef int (*form_data_cbk)(void* par, const char* name, const char* val, int vlen);
//extern int http_form_data(httpbuffer_t* o, form_data_cbk data_cbk, void* par);//解析HTTP协议的form-data数据,不解析文件
typedef int (*form_data_file_cbk)(void* par, const char* name, const char* finalename, const char* filetype, const char* val, int vlen);
//extern int http_form_data_file(httpbuffer_t* o, form_data_file_cbk data_cbk, void* par);//解析HTTP协议的form-data数据,可以解析文件

//********************************************************************************************
typedef struct {//content-type
	char contenttype[128];//文档类型
	char charset[32];//字符编码
	char boundary[128];//数据分隔
} httpcontentype_t;

typedef struct {//一次TCP会话流
	int protocol;//协议
	char direction;//0:client->server,1:server->client
	tcpheader_t element;//五元组
	int length;//数据长度
	uint8_t buffer[];//缓存区
} tcpstream_t;


//回调列表回调函数宏
#define HTTPENGINE_CALLBACK(list, o, e)		{\
	httpengine_cbk_t *cbk = list;\
	while(cbk){\
		cbk->execute(&o, e);\
		cbk = cbk->next;\
	}\
}while(0)

//HTTP请求描述
typedef struct {
	//tcpstream_t* tcp;
	httpbuffer_t* http;
	tb_engine_actioni_t *rule;
	httpcontentype_t* ctype;
	httpengine_handle_t *handles;
} httpdescribe_t;


enum DATAHEAD_STYLE{
	DATAHEAD_STYLE_NONE = 0,
	DATAHEAD_STYLE_USED = 1,
};
typedef struct {
	enum DATAHEAD_STYLE head_style;//测试数据头样式
	char rulepath[128];//规则缓存目录
//	char rulepath_forum[128];//论坛规则缓存目录
//	char rulepath_attach[128];//附件规则缓存目录
} dhttpconf_t;


//********************************************************************************************
extern inline char httprules_contains(tb_engine_actioni_t* rule, const char* method, const char*domain, const char*url);//HTTP请求规则包含
extern int http_contenttype(httpbuffer_t* o, httpcontentype_t* v);//检测HTTP内容类型;out:v 接收参数,1:success,0:fail
extern char chars_part_equals(const char* p, const char* key);//key 是否为p的子选项

extern void http_attach_destory(httpattach_t* o);//销毁对象
extern httpattach_t* http_attach_partdata(httpdescribe_t* o);//分包附件传送
extern httpattach_t* http_attach_upfile(httpdescribe_t* o);//处理单个文件上传
extern httpattach_t* http_attach_formdata(httpdescribe_t* o);//提取formdata中文件数据
extern int http_attach_upload(httpdescribe_t* o);//处理附件上传
extern int http_attach_moveto(httpengine_handle_t* o, struct list_head * rules,  const char* sid, struct list_head* coll);//将符合的附件移动到list中
extern int http_attach_timeout(httpengine_handle_t* o, int m);//超时移除

extern int http_formfiledata(httpdescribe_t* o, form_data_file_cbk data_cbk, void* par);//解析HTTP协议的form-data数据,支持文件传送
extern int http_formdata(httpdescribe_t* o, form_data_cbk data_cbk, void* par);//解析HTTP协议的form-data数据

/**编码转换:从一种编码转为另一种编码
 * @from_charset 源编码方式
 * @to_charset 目标编码方式
 */
 extern int encoding_convert(const char *from_charset, const char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen);
extern int http_urldecode_chars(const char *src, int sln, char *dst, int dln);//url解码字符串
extern int http_cookie_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par);//处理cookie字符串
extern int http_urlquery_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par);//处理url query查询字符串
extern int http_postdata_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par);//解析HTTP协议的url编码数据



//********************************************************************************************
extern int http_action(httpengine_handle_t *handler, tcpstream_t *o);//http响应
//extern int http_urldecode_chars(const char *src, int uSrcSize, char *pcDest, int uDestSize);
extern void  httpactionrule_initialize();//规则初始化
extern void  httpactionrule_destory();//规则销毁

extern int http_forum_formdata(httpdescribe_t* o, tcpheader_t* e);
extern int http_forum_urlencoded(httpdescribe_t* o, tcpheader_t* e);
extern int http_forum_regex(httpdescribe_t* o, tcpheader_t* e, vdata_t* dat);

extern int http_mail_formdata(httpdescribe_t* o, tcpheader_t* e);
extern int http_mail_urlencoded(httpdescribe_t* o, tcpheader_t* e);
extern int http_mail_regex(httpdescribe_t* o, tcpheader_t* e, vdata_t* dat);

extern int http_pan_formdata(httpdescribe_t* o, tcpheader_t* e);
extern int http_pan_attach(httpdescribe_t* o, tcpheader_t* e);


#endif /* LIULQNET_CAPTURE_DISCERN_HTTP_H_ */
