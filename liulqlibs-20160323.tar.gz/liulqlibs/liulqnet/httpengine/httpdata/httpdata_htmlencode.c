/*
 * httpdata_httpencode.c
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static inline char http_htmldecode_charater(char* ikey)
{
	//printf("key:%x,%s;\n", *((unsigned int*)ikey), ikey);
	switch(*((int*)ikey)) {
	case 0x746c: return '<';//&lt;
	case 0x7467: return '>';//&gt;
	case 0x7073626e: return ' ';//&nbsp;
	case 0x746F7571: return '"';//&quot;
	default:
		if('#' == (*ikey)) {
			return (char)atoi(ikey+1);
		}
		break;
	}
	return '-';
}

int http_htmldecode(char *src, int sln)
{
     int i=0, ret= 0, ai=0; /* for result index */
     char ikey[16];
     char *dst = calloc(1, sln + 5);
     if ((src == NULL) || (sln <= 0) )  return 0;
     for (i=0; (i<sln); i++)  {
         switch (src[i]) {
             case '&':
            	 ai=1;
            	 while(ai <16 && (src[i + ai]) && ';' != src[i + ai]) ai++;
            	 if(';' == src[i + ai]) {
            		 memset(ikey, 0, 16);
            		 memcpy(ikey, src+i+1, ai-1);
                	 i += ai;
                	 dst[ret++] = http_htmldecode_charater(ikey);
            	 } else {
            		 dst[ret++] = src[i];
            	 }
                 break;
             default:
                 dst[ret++] = src[i];
                 break;
         }
     }
     if(ret != sln) {
    	 dst[ret] = '\0';
    	 strcpy(src, dst);
     }
     free(dst);
     return ret;
}


