/*
 * httprule_watch.c
 *
 *  Created on: 2016年3月18日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/select.h>
#include "list.h"
#include "multiproperties.h"



//规则监测结构体
typedef struct rulewatch_struct{
	int wd;
	void (*onchange)(const char*);//文件加载函数
	char addr[256];//文件地址
	struct list_head list;//节点列表
} folderwatch_node_t;



int folderwatch_append(folderwatch_t* o, const char* const addr, void (*load_callback)(const char*))
{
	folderwatch_node_t* item = (folderwatch_node_t*)calloc(1, sizeof(folderwatch_t));
	strcpy(item->addr, addr);
	item->onchange = load_callback;
	list_add_tail(&(item->list), &(o->nodes));
	return 0;
}

void folderwatch_destory(folderwatch_t* o)
{
	folderwatch_node_t* item,* next;
	list_for_each_entry_safe(item, next, &(o->nodes), list){
		list_del(&(item->list));
	}
}


static inline void folderwatch_invoke(folderwatch_t* o, struct inotify_event* event)
{
	folderwatch_node_t* item,* next;
	list_for_each_entry_safe(item, next, &(o->nodes), list){
		if(event->wd == item->wd) {
			item->onchange(item->addr);
		}
	}
}

static void* folderwatch_loop(void* arg)
{
	int i, len, nread;
	char buf[BUFSIZ];
	struct inotify_event *event;
	folderwatch_t* o =(folderwatch_t*)arg;
	fd_set rfd;
	struct timeval tv;
	int retval;

	tv.tv_sec = 1;
	tv.tv_usec = 0;
	while(1) {
		FD_ZERO(&rfd);
		FD_SET(o->fd, &rfd);
		retval = select(o->fd + 1, &rfd, NULL, NULL, &tv);
		if(retval <= 0) continue;

		memset(buf, 0, BUFSIZ);
		len = read(o->fd, buf, sizeof(buf) - 1);
		nread = 0;
		while( len > 0 ) {
			event = (struct inotify_event *)&buf[nread];
			folderwatch_invoke(o, event);
			nread = nread + sizeof(struct inotify_event) + event->len;
			len = len - sizeof(struct inotify_event) - event->len;
		}
	}
	return arg;
}

int folderwatch_startup(folderwatch_t* o)//启动检测
{
	folderwatch_node_t* item,* next;
	o->fd = inotify_init();
	if( o->fd < 0 ) {
		fprintf(stderr, "inotify_init failed\n");
		return -1;
	}
	list_for_each_entry_safe(item, next, &(o->nodes), list){
		item->wd = inotify_add_watch(o->fd, item->addr, IN_ALL_EVENTS);//IN_ALL_EVENTS
		if(item->wd >= 0) {
			item->onchange(item->addr);//首次加载调用IN_MODIFY
		}
	}
	pthread_create(&o->threadid, NULL, folderwatch_loop, o);
	return 1;
}
