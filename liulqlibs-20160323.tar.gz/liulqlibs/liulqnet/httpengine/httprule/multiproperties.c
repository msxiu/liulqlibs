/*
 * multiproperties.c
 *
 *  Created on: 2016年3月21日
 *      Author: root
 */
#include <stdio.h>
#include <liulqcore.h>
#include "multiproperties.h"

/*调试规则*/
#ifdef DEBUG_PROPERTIY
#define PROPERTIY_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else
#define PROPERTIY_DEBUG(format, args...)  {}while(0)
#endif

typedef struct {
	unsigned short kstart, klen, vstart, vlen;
}ruleload_segment_t;


/**解析Key:value数据位置
 *@parameter stream:数据指针
 *@parameter length:数据长度
 *@parameter v:结果指针
 */
static int multiproperties_loadoption(char* stream, unsigned int length, ruleload_segment_t* v)
{
	int ret =0;
	memset(v, 0, sizeof(ruleload_segment_t));
	while(char_is_empty(*(stream+v->kstart))) {//跳过首部空格
		v->kstart++;
	}
	while(v->klen < length){//查找等号
		if((*(stream+  (v->kstart+(v->klen++)))) == '=') break;
	}
	if(v->klen < length){//找到等号(=)的情况
		v->vstart = v->kstart+v->klen;
		v->klen--;
		while(char_is_empty(*(stream + (v->kstart+v->klen-1)))) {
			v->klen--;
		}
		while(char_is_empty(*(stream + v->vstart))) {
			v->vstart++;
		}
		v->vlen = length - v->vstart;
		while(char_is_empty(*(stream + (v->vstart+v->vlen-1)))) {
			v->vlen--;
		}
		ret = 1;
	}
	return ret;
}

/**查寻到结束标识的长度
 *@parameter stream:数据指针
 */
static int multiproperties_tagfinish(const char* stream)
{
	char type[64];
	int pos = 0, sln = strlen(stream);
	while(pos < sln) {
		if(*(stream+pos) == ']')  return pos;
		pos ++;
	}
	return -1;
}

int multiproperties_skipline(const char* line)
{
	char c;
	while(!char_is_empty(c =*line++)) {
		return (c == '#');
	}
	return 1;
}
/**文件行回调处理
 *@parameter addr:文件地址
 *@parameter linecallback:行回调处理函数
 */
int multiproperties_loadfile(multiproperties_t* o, const char* addr)
{
#define MAX_LINE		4096
	int ret = 0, sln, lncnt = 0;
	ruleload_segment_t segment;
	const char* tagstart="[properties.";
	char key[128], value[1024], tag[128];
	char *line = malloc(MAX_LINE);
	multiproperties_option_t option = { .key = key, .value = value };
	FILE *fp = fopen(addr, "rb");
	if(NULL == fp) {
		printf("open file '%s' error!\n", addr);
		return ret;
	}
	while(!feof(fp)) {
		if(NULL == fgets(line, MAX_LINE, fp)) continue;
		lncnt++;
		if(multiproperties_skipline(line)) continue;
		if(chars_start_with_ignore(line, tagstart)) {//一个实体开始[rule.mail]
			int spos = multiproperties_tagfinish(line+ strlen(tagstart));
			if(-1 != spos) {
				SET_BUFFER(tag, line+ strlen(tagstart), spos);
				PROPERTIY_DEBUG("%s:%d [%s] start\n", addr, lncnt, tag);
				o->callback_mount(o, tag);
			}
			continue;
		}
		if(chars_start_with_ignore(line, "[/properties.")) {//一个实体开始
			PROPERTIY_DEBUG("%s:%d %s finish\n", addr, lncnt, line);
			o->callback_inipost(o);
			continue;
		}
		if(multiproperties_loadoption(line, strlen(line), &segment)) {
			SET_BUFFER(option.key, line + segment.kstart, segment.klen);
			SET_BUFFER(option.value, line + segment.vstart, segment.vlen);
			o->callback_inioption(o, &option);
		}
	}
	free(line);
	fclose(fp);
	return ret;
}


