/*
 * multiproperties.h
 *
 *  Created on: 2016年3月21日
 *      Author: root
 */

#ifndef LIULQNET_HTTPENGINE_HTTPRULE_MULTIPROPERTIES_H_
#define LIULQNET_HTTPENGINE_HTTPRULE_MULTIPROPERTIES_H_

//回调的以个选项值
typedef struct{
	char* key;//名称
	char* value;//数据值
} multiproperties_option_t;


typedef struct multiproperties_struct{
	void* parameter;
	/**将ini配置文件的一行解析成一个配置选项
	 *@parameter param:当前结构体中的parameter指针
	 *@parameter item:key=value对象
	 */
	char (* callback_inioption)(struct multiproperties_struct* param, multiproperties_option_t* item);
	/**提交解析到的配置结构体的数据
	 *@parameter param:当前结构体中的parameter指针
	 */
	void (* callback_inipost)(struct multiproperties_struct* param);
	/**数据结构体映射安装
	 *@parameter param:当前结构体中的parameter指针
	 *@parameter stream:数据流
	 */
	void (*callback_mount)(struct multiproperties_struct* param, const char* stream);

} multiproperties_t;

extern int multiproperties_loadfolder(multiproperties_t* o, const char* addr);


typedef struct folderwatch_struct {
	int fd;//启动是生成的内部ID
	pthread_t threadid;//线程ID
	struct list_head nodes;//节点列表
} folderwatch_t;//检测文件集合

extern int folderwatch_append(folderwatch_t* o, const char* const addr, void (*load_callback)(const char*));
extern void folderwatch_destory(folderwatch_t* o);
extern int folderwatch_startup(folderwatch_t* o);//启动检测
#endif /* LIULQNET_HTTPENGINE_HTTPRULE_MULTIPROPERTIES_H_ */
