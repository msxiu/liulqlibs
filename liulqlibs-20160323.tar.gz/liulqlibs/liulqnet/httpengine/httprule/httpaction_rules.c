/*
 * httprules.h
 *
 *  Created on: 2016年2月3日
 *      Author: root
 */
#include "httpaction_rules.h"


/**检测HTTP内容类型;out:v 接收参数,1:success,0:fail
 *@parameter o:http缓存对象
 *@parameter v:结果数据
 */
int http_contenttype(httpbuffer_t* o, httpcontentype_t* v)
{
	vdata_t vt;
	unsigned int i = httpbuffer_headkey(o, "content-type:", &vt);
	int p, q;
	if(i == -1) return 0;
	memset(v, 0, sizeof(httpcontentype_t));
	i = 0;
	while(i < vt.length) {
		if(';' ==* (vt.addr + i)) break;
		i++;
	}
	SET_BUFFER(v->contenttype, vt.addr, i);
	if(i == vt.length) return 1;
	p = i;
	q = 0;
	while(i < vt.length) {
		switch(*(vt.addr + i)) {
			case '=': q = i;break;
			case ';': {
				if(q) http_contenttype_write(v, vt.addr, p+1, q, i);
				p = i;
				q = 0;
			}
			break;
		}
		i++;
	}
	if(q && p != i) http_contenttype_write(v, vt.addr, p+1, q, i);
	return 1;
}

/**判断key 是否为p的子选项
 *@parameter p:源字符串
 *@parameter key:包含子串
 */
char chars_part_equals(const char* p, const char* key)
{
	if(!chars_is_empty(p)) {
		int  pos = 0;
		char tmp[128];
		while(*p) {
			while(p[pos] && '|' !=  p[pos]) pos++;
			if(pos) {
				SET_BUFFER(tmp, p, pos);
				if(0 == strcasecmp(key, tmp)) return 1;
			}
			pos++;
			p+=pos;
			pos = 0;
		}
	}
	return 0;
}

/**规则初始化
 *@parameter o:处理这指针
 *@parameter rs_action:
 *@parameter rs_mail:
 *@parameter rs_forum;
 *@parameter rs_attach:
 *@parameter rs_mapattach:
 */
void  httpactionrule_from_records(httpengine_handle_t* o, tbrecords_t* rs_mail, tbrecords_t*rs_forum, tbrecords_t *rs_attach)//
{
	int i=0, j=0;
	for(i=0;i<rs_mail->length;i++) {
		httpactionrule_addmails(o, ((tb_engine_mail_t*)rs_mail->records) + i);
	}
	for(i=0;i<rs_forum->length;i++) {
		httpactionrule_addforums(o, ((tb_engine_forum_t*)rs_forum->records) + i);
	}
	for(i=0;i<rs_attach->length;i++) {
		httpactionrule_addattachs(o, ((tb_engine_attach_t*)rs_attach->records) + i);
	}
}


//void  httpactionrule_from_folder(httpengine_handle_t* o, const char* mail, const char* forum, const char* attach)
//{
//	rules_folder_mail(mail, o, httpactionrule_addmails);
//	rules_folder_forum(forum, o, httpactionrule_addforums);
//	rules_folder_attach(attach, o, httpactionrule_addattachs);
//}

/**比较HTTP请求规则是否为指定请求
 *@parameter rule:比较规则
 *@parameter method:HTTP请求方式(GET,POST)
 *@parameter domain:域名
 *@parameter url:URL地址
 */
char httpactionrules_contains(tb_engine_actioni_t* rule, const char* method, const char*domain, const char*url)
{
	int allow_next = 0;
	if(chars_equals_ignore(domain, rule->domain)) {//域名比较
		switch(rule->method) {//比较请求方式
		case HTTP_METHD_ANY: allow_next = (char)1; break;
		case HTTP_METHD_GET: allow_next = (0 == strcasecmp(method, "get")); break;
		case HTTP_METHD_POST: allow_next = (0 == strcasecmp(method, "post")); break;
		}
		if(allow_next) {
			allow_next = 0;
			switch(rule->urltype) {//根据不同的方式对URL比较
			case URLCOMPARE_IGNORE: allow_next = (char)1; break;
			case URLCOMPARE_CONTAIN: allow_next = (-1 != chars_indexof_ignore(url, rule->url, 0)); break;
			case URLCOMPARE_STARTWITH: allow_next =  chars_start_with_ignore(url, rule->url); break;
			case URLCOMPARE_ENDWITH: allow_next =  chars_end_with_ignore(url, rule->url); break;
			}
		}
	}
	return allow_next;
}

/**过滤获得HTTP协议解析规则
 *@parameter handler:协议处理者对象
 *@parameter o:请求缓存数据
 */
tb_engine_actioni_t* httpactionrules_filter(httpengine_handle_t* handler, httpbuffer_t* o)
{
	buffernext_t* rules = handler->rules;
	char allow_next = 0;
	vdata_t vh = { 0 }, vm = { .addr = (char*)o->data, .length = o->method },  vu =  { .addr = (char*)(o->data + o->method + 1), .length = (o->url - o->method - 1) };
	int pos = 0, index = 0;
	pos = httpbuffer_headkey(o, "host:", &vh);
	char domain[vh.length + 5], url[vu.length + 5], method[vm.length + 5];
	if(-1 == pos) return NULL;
	SET_BUFFER(domain, vh.addr, vh.length);
	SET_BUFFER(url, vu.addr, vu.length);
	SET_BUFFER(method, vm.addr, vm.length);

	while(rules) {
		tb_engine_actioni_t* rule = (tb_engine_actioni_t*)(rules->data + rules->type);
		if(httpactionrules_contains(rule, method, domain, url)) {
			//GDB_DEBUGS("rule[%d]{domain:'%s'=='%s', url:'%s'=='%s'}\n", index, rule->domain, domain, rule->url, url);
			return rule;
		}
		rules = rules->next;
		index++;
	}
	return NULL;
}


/**数据内存释放
 *@parameter o:协议处理者对象
 */
void httpactionrules_destory(httpengine_handle_t* o)
{
	buffernext_t* opt = o->rules, *next;
	while(opt) {
		next = opt->next;
		free(opt);
		opt = next;
	}
}


