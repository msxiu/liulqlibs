/*
 * httpaction_rules.h
 *
 *  Created on: 2016年3月17日
 *      Author: root
 */

#ifndef LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_RULES_H_
#define LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_RULES_H_

#include "httpaction.h"
#include "list.h"
#include "liulqdebug.h"
#include "enum_utils.h"

#define MAP_RECORD(T,rs, oid, node) {\
	int mpi=0;\
	for(mpi=0;mpi<rs->length;mpi++){\
		T* mapv = (((T *)rs->records) + mpi);\
		if(mapv->id == oid) {node = mapv; }\
	}\
}while(0)

extern dhttpconf_t detectconf;


static inline void* httpactionrule_addrules(httpengine_handle_t* o, void* item, size_t ln, unsigned int type)
{
	buffernext_t* node = (buffernext_t*)calloc(1, sizeof(buffernext_t) + ln);
	memcpy(node->data, item, ln);
	node->type = type;
	if(o->rules) {node->next = o->rules;}
	o->rules =node;
	return node->data;
}

/**添加规则
 *@parameter o:引擎处理器对象
 *@parameter item:规则
 */
static inline void httpactionrule_addmails(httpengine_handle_t* o, tb_engine_mail_t* item)
{
	//RULES_DEBUG("add mail rule '%s:%s';\n", item->action.domain, item->action.url);
	tb_engine_mail_t* nitem;
	nitem = httpactionrule_addrules(o, item, sizeof(tb_engine_mail_t), member_offset(tb_engine_mail_t, action));
	INIT_LIST_HEAD(&(nitem->action.attach_rules));
	RULES_EXECUTE(ruleshow_tb_engine_mail(nitem));
}
static inline void httpactionrule_addforums(httpengine_handle_t* o, tb_engine_forum_t* item)
{
	tb_engine_forum_t* nitem;
	//RULES_DEBUG("add forum rule '%s:%s';\n", item->action.domain, item->action.url);
	nitem = httpactionrule_addrules(o, item, sizeof(tb_engine_forum_t), member_offset(tb_engine_forum_t, action));
	INIT_LIST_HEAD(&(nitem->action.attach_rules));
	RULES_EXECUTE(ruleshow_tb_engine_forum(nitem));
}
/**添加附件
 *@parameter o:引擎处理器对象
 *@parameter item:附件
 */
static inline void httpactionrule_addattachs(httpengine_handle_t* o, tb_engine_attach_t* item)
{
	tb_engine_attach_t* nitem;
	buffernext_t* opt = o->rules, *next;
	nitem = httpactionrule_addrules(o, item, sizeof(tb_engine_attach_t), member_offset(tb_engine_attach_t, action));
	INIT_LIST_HEAD(&(nitem->action.attach_rules));
	RULES_EXECUTE(ruleshow_tb_engine_attach(nitem));

	while(opt) {
		tb_engine_actioni_t* act = (tb_engine_actioni_t*)(opt->data +opt->type);
		opt = opt->next;
		if(act->rule == nitem->ruletype && act->id == nitem->ruleid) {//附件包含判断
			RULES_DEBUG("%p:match %s attach %p:{'%s:%s'};\n\n", act, act->domain, nitem, nitem->action.domain, nitem->action.url);
			list_add_tail(&(nitem->action.attach_rules), &(act->attach_rules));
//		} else {
//			RULES_DEBUG("match %s fail '%s:%s',rule(%s==%s)&& id(%u==%u);\n", act->domain, nitem->action.domain, nitem->action.url, getenum_HTTP_AUDIT_RULE(act->rule), getenum_HTTP_AUDIT_RULE(nitem->ruletype), act->id, nitem->ruleid);
		}
	}
}


static inline void http_contenttype_write(httpcontentype_t* v, char* addr, int start, int equals, int end)//对content-type赋值
{
	char name[64];
	int vln;
	memset(&name, 0, 64);
	while(char_is_empty(*(addr + start))) start ++;
	vln = equals - start;
	SET_BUFFER(name, addr+start, vln);
	vln = (end - (equals + 1));
	if(0 == strcasecmp(name, "charset")) {
		SET_BUFFER(v->charset, (addr + equals + 1), vln);
	} else if(0 == strcasecmp(name, "boundary")) {
		SET_BUFFER(v->boundary, (addr + equals + 1), vln);
	}
}

#endif /* LIULQNET_HTTPENGINE_PROTOCOL_HTTPACTION_RULES_H_ */
