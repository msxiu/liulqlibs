/*
 * httprule_ini.c
 *
 *  Created on: 2016年3月21日
 *      Author: root
 */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>
#include "liulqcore.h"
#include "httpengine.h"
#include "httpaction_rules.h"
#include "multiproperties.h"


//规则加载结构体
typedef struct {
	httpengine_handle_t* node;//引擎处理节点
	void* item;//设置数据对象
	unsigned char itemtype;//设置数据对象的类型
	tb_engine_mail_t mail;
	tb_engine_forum_t forum;
	tb_engine_attach_t attach;
} multifile_t;


//*******************************************************************************
static inline char multifile_parse_action(tb_engine_actioni_t*action, multiproperties_option_t* opt)
{
	if(strcasecmp("action.id", opt->key) == 0){
		action->id = atoi(opt->value);
	} else if(strcasecmp("action.rule", opt->key) == 0) {
		action->rule = atoi(opt->value);
	} else if(strcasecmp("action.domain", opt->key) == 0) {
		strcpy(action->domain,  opt->value);
	} else if(strcasecmp("action.method", opt->key) == 0) {
		action->method = atoi(opt->value);
	} else if(strcasecmp("action.urltype", opt->key) == 0) {
		action->urltype = atoi(opt->value);
	} else if(strcasecmp("action.url", opt->key) == 0) {
		strcpy(action->url,  opt->value);
	} else if(strcasecmp("action.charset", opt->key) == 0) {
		strcpy(action->charset,  opt->value);
	} else if(strcasecmp("action.resolve", opt->key) == 0) {
		action->resolve = atoi(opt->value);
	}
	return 0;
}
//****************************************************************************************
//邮件参数解析函数
static char multifile_parse_mail(multiproperties_t*par, multiproperties_option_t* opt)
{
	tb_engine_mail_t* item =(tb_engine_mail_t*)(((multifile_t*)par->parameter)->item);
	if(strcasecmp("sid", opt->key) == 0) {
		strcpy(item->sid,  opt->value);
	} else if(strcasecmp("sender", opt->key) == 0) {
		strcpy(item->sender,  opt->value);
	} else if(strcasecmp("receiver", opt->key) == 0) {
		strcpy(item->receiver,  opt->value);
	} else if(strcasecmp("cc", opt->key) == 0) {
		strcpy(item->cc,  opt->value);
	} else if(strcasecmp("bcc", opt->key) == 0) {
		strcpy(item->bcc,  opt->value);
	} else if(strcasecmp("subject", opt->key) == 0) {
		strcpy(item->subject,  opt->value);
	} else if(strcasecmp("content", opt->key) == 0) {
		strcpy(item->content,  opt->value);
	} else if(strcasecmp("mask", opt->key) == 0) {
		item->mask = atoi(opt->value);
	} else {
		return multifile_parse_action(&(item->action), opt);
	}
	return 0;
}
//****************************************************************************************
//论坛参数解析函数
static char multifile_parse_forum(multiproperties_t*par, multiproperties_option_t* opt)
{
	tb_engine_forum_t* item =(tb_engine_forum_t*)(((multifile_t*)par->parameter)->item);
	if(strcasecmp("sid", opt->key) == 0) {
		strcpy(item->sid,  opt->value);
	} else if(strcasecmp("subject", opt->key) == 0) {
		strcpy(item->subject,  opt->value);
	} else if(strcasecmp("content", opt->key) == 0) {
		strcpy(item->content,  opt->value);
	} else {
		return multifile_parse_action(&(item->action), opt);
	}
	return 0;
}
//****************************************************************************************
//附件参数解析函数
static char multifile_parse_attach(multiproperties_t*par, multiproperties_option_t* opt)
{
	tb_engine_attach_t* item =(tb_engine_attach_t*)(((multifile_t*)par->parameter)->item);
	if(strcasecmp("ruleid", opt->key) == 0) {
		item->ruleid = atoi(opt->value);
	} else if(strcasecmp("ruletype", opt->key) == 0) {
		item->ruletype = atoi(opt->value);
	} else if(strcasecmp("sid", opt->key) == 0) {
		strcpy(item->sid,  opt->value);
	} else if(strcasecmp("aid", opt->key) == 0) {
		strcpy(item->aid,  opt->value);
	} else if(strcasecmp("cook", opt->key) == 0) {
		strcpy(item->cook,  opt->value);
	} else if(strcasecmp("data", opt->key) == 0) {
		strcpy(item->data,  opt->value);
	} else if(strcasecmp("length", opt->key) == 0) {
		strcpy(item->length,  opt->value);
	} else if(strcasecmp("name", opt->key) == 0) {
		strcpy(item->name,  opt->value);
	} else if(strcasecmp("offset", opt->key) == 0) {
		strcpy(item->offset,  opt->value);
	} else if(strcasecmp("size", opt->key) == 0) {
		strcpy(item->size,  opt->value);
	} else {
		return multifile_parse_action(&(item->action), opt);
	}
	return 0;
}


//*******************************************************************************
static inline void multifile_callback_mount(multiproperties_t* item, const char* type)
{
	multifile_t* o = (multifile_t*)item->parameter;
	if(0 == strcasecmp("mail", type)) {
		o->itemtype = 1;
		o->item = &(o->mail);
		memset(o->item, 0,  sizeof(tb_engine_mail_t));
		item->callback_inioption = multifile_parse_mail;

	} else if(0 == strcasecmp("forum", type)) {
		o->itemtype = 2;
		o->item =&(o->forum);
		memset(o->item, 0,  sizeof(tb_engine_forum_t));
		item->callback_inioption = multifile_parse_forum;

	} else if(0 == strcasecmp("attach", type)) {
		o->itemtype = 3;
		o->item = &(o->attach);
		memset(o->item, 0,  sizeof(tb_engine_attach_t));
		item->callback_inioption = multifile_parse_attach;
	}
}

static inline void multifile__addrules(multiproperties_t* item)
{
	multifile_t* o = (multifile_t*)item->parameter;
	switch(o->itemtype) {
	case 1://mail
		httpactionrule_addmails(o->node, o->item);
		break;
	case 2://forum
		httpactionrule_addforums(o->node, o->item);
		break;
	case 3://attach
		httpactionrule_addattachs(o->node, o->item);
		break;
	}
	o->item = NULL;
}




//****************************************************************************
/**规则文件回调,将ini解析成规则结构体对象,再进行规则解析
 *@parameter folder:目录地址
 *@parameter o:规则加载结构体对象
 */
static inline void multifile_callback(multiproperties_t* o, const char* folder)
{
	char wkdir[256];
	DIR *dp;
	struct dirent *entry;
	struct stat statbuf;
	getcwd(wkdir, sizeof(wkdir));//保存当前工作目录
	if(NULL == (dp = opendir(folder))) {//打开目录失败
		return;
	}
	chdir(folder);
	while(NULL != (entry = readdir(dp))) {
		lstat(entry->d_name, &statbuf);
		if(S_ISREG(statbuf.st_mode)) {//判断是否为一般文件
			multiproperties_loadfile(o, entry->d_name);
//		} else	if(S_ISDIR(statbuf.st_mode)) {//判断是否为路径
//		} else if(S_ISLNK(statbuf.st_mode)) {//判断是否为连接文件
//		} else if(S_ISSOCK(statbuf.st_mode)) {//判断是否为套接字文件
//		} else if(S_ISFIFO(statbuf.st_mode)) {//判断是否为命名管道文件
//		} else if(S_ISBLK(statbuf.st_mode)) {//判断是否为块设备
//		} else if(S_ISCHR(statbuf.st_mode)) {//判断是否为字符设备
		}
	}
	closedir(dp);
	chdir(wkdir);//还回原工作目录
}


/**解析目录下文件到规则中,每个规则回调handle函数
 *@parameter folder:目录地址
 *@parameter handle:回调函数
 */
void multifile_folder(httpengine_handle_t* obj, const char* folder)
{
	multifile_t item = { .node = obj };
	multiproperties_t rule_properties = {
			.parameter = &item,
			.callback_mount = multifile_callback_mount,
			.callback_inipost = multifile__addrules,
			.callback_inioption = NULL,
	};
	multifile_callback(&rule_properties, folder);
}


