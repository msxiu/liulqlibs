/*
 * httpaction.c
 *
 *  Created on: 2016年1月29日
 *      Author: root
 */
#include "liulqdebug.h"
#include "liulqcore.h"
#include "local.h"
#include "application.h"
#include "examples/examples.h"

extern void load_configure();


ipfrag_t ipfrag = { 0 };//IP碎片处理对象
tcpflow_t tcpflow = { 0 };//TCP流汇聚处理对象

int pkt_index = 0;//处理包下标

/**对pcap包进行碎片处理
 *@parameter pkt:数据包指针地址
 *@parameter len:数据包长度
 */
static void push_pcap_packet(void* pkt, unsigned int len)
{
	pkt_index++;
	ipfrag_addpacket(&ipfrag, pkt, len);//添加IP碎片处理函数
}

/**IP碎片重组后,包回调处理
 *@parameter packet:数据包指针地址
 *@parameter len:数据包长度
 */
static int ipfrag_callback(void* packet, uint32_t len)
{
	//int tcpflow_addpacket(tcpflow_t* o, void* pkt, unsigned int skblen)
	return tcpflow_addpacket(&tcpflow, packet, len);
}

int main(int argc, char* argv[])
{
	int i = 0;
	load_configure();

	//IP碎片处理初始化
	ipfrag_initialize(&ipfrag, 256, ipfrag_callback, NULL);//初始化IP碎片处理器

	//TCP流汇聚初始化
	tcpflow_initialize(&tcpflow, 65536, tcp_segment_process, tcpflow_packet, tcp_recover_process);//初始化TCP流汇聚处理器

	//加载pcap文件,调用push_pcap_packet处理包
	pcapfile_handler(argc, argv, push_pcap_packet);
}




