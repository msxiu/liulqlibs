/*
 * tcp_ftpcontrol.h
 *
 *  Created on: 2016年3月16日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_PROTOCOL_FTP_TCP_FTPCONTROL_H_
#define LIULQNET_TCPCONVERGE_PROTOCOL_FTP_TCP_FTPCONTROL_H_

#include <liulqcore.h>
#include <liulqdebug.h>
#include "local.h"
#include "application.h"
#include "ftp.h"

static inline int ftpcontrol_lastcmd(tcpsession_t *ht, int cmd)//设置最后命令
{
	ftpcontrol_t* item = (ftpcontrol_t*)ht->content;
	if(! item) {
		return 0;
	}
	if(! item->last) {
		return 0;
	}
	item->last->cmd = cmd;
	return cmd;
}

static inline int ftpcontrol_user(tcpsession_t *ht, tcppacket_t *o)//保存用户名
{
	ftpcontrol_t* item = (ftpcontrol_t*)ht->content;
	if(NULL != item) {
		SET_BUFFER(item->user, o->buffer+5, o->length - 7);
		return FTP_CMD_USER;
	}
	return 0;
}
static inline int ftpcontrol_pass(tcpsession_t *ht, tcppacket_t *o)//保存密码
{
	ftpcontrol_t* item = (ftpcontrol_t*)ht->content;
	if(NULL != item) {
		SET_BUFFER(item->pass, o->buffer+5, o->length - 7);
		return FTP_CMD_PASS;
	}
	return 0;
}

static inline int ftpcontrol_path(tcpsession_t *ht, tcppacket_t *o)//保存当前路径
{
	ftpcontrol_t* item = (ftpcontrol_t*)ht->content;
	if(NULL != item) {
		const char* p = ((const char*)o->buffer)+4;
		int pos = 4;
		while(*p && '"' != *p) p++;
		if('"' != *p) return 0;
		p++;
		while(p[pos] && '"' != p[pos]) pos++;
		if('"' != p[pos]) return 0;
		SET_BUFFER(item->path, p, pos);
		return FTP_STATE_257;
	}
	return 0;
}

/**指定数据连接的文件名
 *@parameter ht:TCP会话对象
 *@parameter o:IP数据包
 */
static inline int ftpcontrol_filename(tcpsession_t *ht, tcppacket_t *o)
{
	ftpcontrol_t* ftp = (ftpcontrol_t*)ht->content;
	if(ftp && ftp->last) {
		GDB_MSGL("ftpcontrol_filename:%s\n", o->buffer, o->length);
		SET_BUFFER(ftp->last->fname, o->buffer + 5, o->length - 7);
		return 1;
	}
	return 0;
}

#endif /* LIULQNET_TCPCONVERGE_PROTOCOL_FTP_TCP_FTPCONTROL_H_ */
