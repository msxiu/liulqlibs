/*
 * ftp_links.c
 *
  *  Created on: 2016年3月11日
 *      Author: root
 */
#include "tcp_ftpcontrol.h"

/**FTP命令识别
 *@parameter p:数据指针
 *@parameter len:数据长度
 */
int ftpcontrol_command(const char*p,unsigned int len)
{
	const char* p1 = (p + 1);
	switch(*p) {
	case '2':
		if(chars_start_with(p1, "27 ")) return FTP_STATE_227;
		break;
	case 'A':
		if(chars_start_with(p1, "BOT")) return FTP_CMD_ABOT;
		if(chars_start_with(p1, "CCT")) return FTP_CMD_ACCT;
		if(chars_start_with(p1, "LLO")) return FTP_CMD_ALLO;
		if(chars_start_with(p1, "PPE")) return FTP_CMD_APPE;
		break;
	case 'C':
		if(chars_start_with(p1, "DUP")) return FTP_CMD_CDUP;
		if(chars_start_with(p1, "WD")) return FTP_CMD_CWD;
		break;
	case 'D':
		if(chars_start_with(p1, "ELE")) return FTP_CMD_DELE;
		break;
	case 'H':
		if(chars_start_with(p1, "ELP")) return FTP_CMD_HELP;
		break;
	case 'L':
		if(chars_start_with(p1, "IST")) return FTP_CMD_LIST;
		break;
	case 'M':
		if(chars_start_with(p1, "KD")) return FTP_CMD_MKD;
		if(chars_start_with(p1, "ODE")) return FTP_CMD_MODE;
		break;
	case 'N':
		if(chars_start_with(p1, "LST")) return FTP_CMD_NLST;
		if(chars_start_with(p1, "OOP")) return FTP_CMD_NOOP;
		break;
	case 'P':
		if(chars_start_with(p1, "ASS")) return FTP_CMD_PASS;
		if(chars_start_with(p1, "ASV")) return FTP_CMD_PASV;
		if(chars_start_with(p1, "ORT")) return FTP_CMD_PORT;
		if(chars_start_with(p1, "WD")) return FTP_CMD_PWD;
		break;
	case 'Q':
		if(chars_start_with(p1, "UIT")) return FTP_CMD_QUIT;
		break;
	case 'R':
		if(chars_start_with(p1, "EIN")) return FTP_CMD_REIN;
		if(chars_start_with(p1, "EST")) return FTP_CMD_REST;
		if(chars_start_with(p1, "ETR")) return FTP_CMD_RETR;
		if(chars_start_with(p1, "MD")) return FTP_CMD_RMD;
		if(chars_start_with(p1, "NFR")) return FTP_CMD_RNFR;
		if(chars_start_with(p1, "NTO")) return FTP_CMD_RNTO;
		break;
	case 'S':
		if(chars_start_with(p1, "ITE")) return FTP_CMD_SITE;
		if(chars_start_with(p1, "MNT")) return FTP_CMD_SMNT;
		if(chars_start_with(p1, "TAT")) return FTP_CMD_STAT;
		if(chars_start_with(p1, "TOR")) return FTP_CMD_STOR;
		if(chars_start_with(p1, "TOU")) return FTP_CMD_STOU;
		if(chars_start_with(p1, "TRU")) return FTP_CMD_STRU;
		if(chars_start_with(p1, "YST")) return FTP_CMD_SYST;
		break;
	case 'T':
		if(chars_start_with(p1, "YPE")) return FTP_CMD_TYPE;
		break;
	case 'U':
		if(chars_start_with(p1, "SER")) return FTP_CMD_USER;
		break;
	}
	return 0;
}

/**FTP控制连接对象初始化
 *@parameter ht:tcp会话对象
 */
void ftpcontrol_initialize(tcpsession_t *ht)
{
	ftpcontrol_t* item = (ftpcontrol_t*)malloc(sizeof(ftpcontrol_t));
	memset(item, 0, sizeof(ftpcontrol_t));
	ht->content = item;
	ht->protocol = PROTOCOL_FTP;
}





/**FTP控制连接的IP包处理程序
 *@parameter ht:tcp会话对象
 *@parameter o:数据包
 */
int ftpcontrol_process(tcpsession_t *ht, tcppacket_t *o)
{
	//本次命令处理
	switch(ftpcontrol_command(o->buffer, o->length)) {
	case FTP_CMD_USER://指定远程系统上的用户名称
		APPLYFTP_DEBUG("FTP_CMD_USER handle:'%s'\n", (char*)o->buffer);
		return ftpcontrol_user(ht, o);
	case FTP_CMD_PASS://向远程系统发送用户的密码
		APPLYFTP_DEBUG("FTP_CMD_PASS handle:'%s'\n", (char*)o->buffer);
		return ftpcontrol_pass(ht, o);
	case FTP_CMD_PWD:
		break;
	case FTP_STATE_257:
		return ftpcontrol_path(ht, o);

	case FTP_CMD_PASV://协商接口,被动发送
		//ht->direction = FTP_CMD_PASV;//等待下一个服务器还回的IP与端口
		APPLYFTP_DEBUG("FTP_CMD_PASV receive!\n");
		return FTP_CMD_PASV;
	case FTP_STATE_227:
		return ftpdata_addport(ht, o, FTP_CMD_PASV);
	case FTP_CMD_PORT://协商接口,主动发送:PORT 192,168,2,204,239,185
		GDB_MSGL("FTP_CMD_PORT handle:'%s'\n", (char*)o->buffer, o->length);
		return ftpdata_addport(ht, o, FTP_CMD_PORT);


	case FTP_CMD_APPE://让服务器准备接收一个文件并指示它把这些数据附加到指定的文件名，如果指定的文件尚未存在，就创建它
		APPLYFTP_DEBUG("FTP_CMD_APPE handle:'%s'\n", (char*)o->buffer);
		return FTP_CMD_APPE;
	case FTP_CMD_STOR://让服务器接收一个来自数据连接的文件
		APPLYFTP_DEBUG("FTP_CMD_STOR handle:'%s'\n", (char*)o->buffer);
		if(ftpcontrol_filename(ht, o)) {
			return ftpcontrol_lastcmd(ht, FTP_CMD_STOR);
		}
		break;
	case FTP_CMD_STOU://让服务器准备接收一个文件
		APPLYFTP_DEBUG("FTP_CMD_STOU handle:'%s'\n", (char*)o->buffer);
		if(ftpcontrol_filename(ht, o)) {
			return ftpcontrol_lastcmd(ht, FTP_CMD_STOU);
		}
		break;
	case FTP_CMD_RETR: //让服务器给客户传送一份在路径名中指定的文件的副本
		APPLYFTP_DEBUG("FTP_CMD_RETR handle:'%s'\n", (char*)o->buffer);
		if(ftpcontrol_filename(ht, o)) {
			return ftpcontrol_lastcmd(ht, FTP_CMD_RETR);
		}
		break;
	case FTP_CMD_QUIT://终止连接
		APPLYFTP_DEBUG("FTP_CMD_QUIT handle:'%s'\n", (char*)o->buffer);
		ftplinks_control_clean((ftpcontrol_t*)ht->content);
		return FTP_CMD_QUIT;
	default:
		APPLYFTP_DEBUG("FTP_CMD_NONE handle:'%s'\n", (char*)o->buffer);
		return FTP_CMD_NONE;
	}
	return FTP_CMD_NONE;
}

