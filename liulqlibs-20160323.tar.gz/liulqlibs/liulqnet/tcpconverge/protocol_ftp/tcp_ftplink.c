/*
 * tcp_ftplink.c
 *
 *  Created on: 2016年3月15日
 *      Author: root
 */
#include "liulqcore.h"
#include "liulqdebug.h"

#include "local.h"
#include "ftp.h"
#include "list.h"

#define IP_EQUALS(a,b)	((a).ip==(b).ip && (a).port == (b).port)
static LIST_HEADM(ftp_files);//FTP数据文件链表头

/**检测是否为FTP数据连接
 *@parameter e:通信五元组
 */
ftplink_t* ftplinks_indexof(tcpflowhdr_t *e)
{
	ftplink_t* pos, *next;
	list_for_each_entry_safe(pos, next, &ftp_files, list)  {
		if(IP_EQUALS(e->dst, pos->sonsult) || IP_EQUALS(e->src, pos->sonsult)) {
			return pos;
		}
	}
	return NULL;
}


/**添加一个FTP连接
 *@parameter item:FTP连接对象
 */
int ftplinks_append(ftplink_t* item)
{
	list_add_tail(&(item->list), &(ftp_files));
	return 1;
}

/**删除一个数据连接
 *@parameter e:通信五元组
 */
int ftplinks_remove(ftplink_t *e)
{
	list_del(&(e->list));
	return 0;
}

/**删除一个FTP控制连接中所有数据连接
 *@parameter c:FTP控制连接
 */
int ftplinks_control_clean(ftpcontrol_t *c)
{
	int ret = 0;
	ftplink_t* pos, *next;
	list_for_each_entry_safe(pos, next, &ftp_files, list)  {
		if(IP_EQUALS(c->src, pos->control->src) || IP_EQUALS(c->dst, pos->control->dst)) {
			ret ++;
		}
	}
	return ret;
}



