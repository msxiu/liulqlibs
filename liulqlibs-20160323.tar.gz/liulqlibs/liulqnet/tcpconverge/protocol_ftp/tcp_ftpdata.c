/*
 * tcp_ftpdata.c
 *
 *  Created on: 2016年3月15日
 *      Author: root
 */
#include "liulqcore.h"
#include "liulqdebug.h"

#include "local.h"
#include "application.h"
#include "ftp.h"

//extern linked_list_t ftp_data_links;

//int ftp_logger(tcpflowhdr_t* e, tcppacket_t *o)//记录FTP哈希文件日志
//{
////	uint32_t ticks =  get_ticks();//获得时间cuo
////	char logname[128];
////    int hash =(e->dst.ip ^ e->src.ip) + (e->dst.port + (e->src.port << 16));
////	sprintf(logname, "%s/%s/%x-%x.txt", "/home/logs", "ftp", ticks, hash);
////	file_addbuffer(logname, (o)->buffer, (o)->length);
//	return 1;
//}

#define IS_NUMBER(a)		(a>='0' && a<= '9')
/**将FTP连接数组转换成IP地址
 *@parameter p:数据缓存地址指针
 */
static uint64_t parse_ipaddr(const char* p)
{
	uint64_t result = 0;
	int  pos = 0, bt =0, tmp;
	while(bt < 6) {
		while(IS_NUMBER(p[pos])) pos++;
		if(!pos) return 0;
		result = result << 8;
		PARSE_INT_OF(tmp, p, pos);
		result += tmp;
		pos++;
		p+=pos;
		pos = 0;
		bt++;
	}
	return result;
}


int ftpdata_addport(tcpsession_t* ht, tcppacket_t *o, uint16_t type) //添加一个协商端口
{
	//解析被动端口:227 Entering Passive Mode (115,47,154,30,35,73)
	//解析主动端口:PORT 192,168,2,204,239,185
	uint64_t ip;
	const char* p = (const char*)o->buffer;
	ftpcontrol_t* ftp = (ftpcontrol_t*)ht->content;
	if(NULL == ftp) {
		GDB_WARN("ftpcontrol_t is NULL!\n");
		return 0;
	}
	if(chars_start_with(o->buffer, "227 ")) {
		while(*p != '(') p++;
		p++;
		ip = parse_ipaddr(p);
	}
	if(chars_start_with(o->buffer, "PORT ")) {
		GDB_MSGL("%s;\n", p + 5, o->length - 5);
		ip = parse_ipaddr(p + 5);
	}
	if( ip > 0) {
		ftplink_t* item = NULL;
		item = (ftplink_t*)malloc(sizeof(ftplink_t));
		if(!item) {
			return 0;
		}
		memset(item, 0, sizeof(ftplink_t));
		const char* ipfmt = "add ftp data(" FMT_IPADDR ":%d), %d ftp data!\n";
		item->sonsult.ip = (uint32_t)((ip >> 16) & 0xFFFFFFFF);
		item->sonsult.port = (uint16_t)(ip & 0xFFFF);
		item->created = time(NULL);
		ftp->last = item;
		item->control = ftp;
		item->method = type;
		ftplinks_append(item);
		return type;
	}
	return 0;
}


int ftpdata_process(ftplink_t* item)//, tcpstream_t *o
{
	//ftplink_t* item = (ftplink_t*)ftp_links_of(&(o->element));//查找数据链接
	switch(item->cmd) {
	case FTP_CMD_STOR:
	case FTP_CMD_STOU: {
			const char* fmt = FMT_IPADDR ":%d=>%s;\n";
			GDB_DEBUGS(fmt, TO_IPADDR(item->sonsult.ip), item->sonsult.port, item->fname);
			//ALLOW_FTP(logger_ftp(o->buffer, o->length));//记录网页邮件
			//match_ftp_for_sensitive(item, o);//调用邮件处理函数
		}
		break;
	default: {
			const char* fmt = FMT_IPADDR ":%d;\n";
			GDB_DEBUGS(fmt, TO_IPADDR(item->sonsult.ip), item->sonsult.port);
			//ALLOW_FTP(logger_ftp(o->buffer, o->length));//记录网页邮件
		}
		break;
	}
	ftplinks_remove(item);//处理完成,删除数据链接
	return PROTOCOL_FTP;
}

