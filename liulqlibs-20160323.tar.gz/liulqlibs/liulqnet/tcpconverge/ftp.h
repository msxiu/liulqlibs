/*
 * ftp.h
 *
 *  Created on: 2015年12月13日
 *      Author: root
 */
#ifndef DETECT_DAC_NIDS_FTP_H_
#define DETECT_DAC_NIDS_FTP_H_
#include "liulqcore.h"
#define LARGEKEYNUM	1024

#ifdef DEBUG_APPLYFTP

#define APPLYFTP_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else

#define APPLYFTP_DEBUG(format, args...)  {}while(0)

#endif

//FTP指令
enum ftp_command {
	FTP_CMD_NONE = 0,//未知命令
	FTP_CMD_ABOT=100,//中止上一次FTP服务命令及所有相关的数据传输
	FTP_CMD_ACCT,//指定用户的帐号信息。这条命令只能在发送PASS命令并接收到332代码之后发送
	FTP_CMD_ALLO,//发送文件前在服务器上分配X个字节
	FTP_CMD_APPE,//让服务器准备接收一个文件并指示它把这些数据附加到指定的文件名，如果指定的文件尚未存在，就创建它
	FTP_CMD_CDUP,//把当前目录改为远程文件系统的根目录
	FTP_CMD_CWD ,//把当前目录改为远程文件系统的指定路径
	FTP_CMD_DELE,//删除服务器站点上在路径名中指定的文件
	FTP_CMD_HELP,//让服务器通过到客户的控制连接发送有关其实现状态的帮助信息
	FTP_CMD_LIST,//让服务器给客户发送一份列表
	FTP_CMD_MKD ,//创建一个在路径名中指定的目录
	FTP_CMD_MODE,//指定传输模式
	FTP_CMD_NLST,//让服务器给客户发送一份目录列表
	FTP_CMD_NOOP,//不进行操作的命令
	FTP_CMD_PASS,//向远程系统发送用户的密码
	FTP_CMD_PASV,//告诉服务器在一个非标准端口上收听数据连接
	FTP_CMD_PORT,//为数据连接指定一个IP地址和本地端口
	FTP_CMD_PWD ,//在应答中返回当前工作目录的名称
	FTP_CMD_QUIT,//终止连接
	FTP_CMD_REIN,//终止一个用户
	FTP_CMD_REST,//标识出文件内的数据点，将从这个点开始继续传送文件
	FTP_CMD_RETR,//让服务器给客户传送一份在路径名中指定的文件的副本
	FTP_CMD_RMD ,//删除一个在路径名中指定的目录
	FTP_CMD_RNFR,//文件重命名进程的前一半
	FTP_CMD_RNTO,//文件重命名进程的后一半
	FTP_CMD_SITE,//服务器使用SITE提供了某些服务特性
	FTP_CMD_SMNT,//允许用户装配另一个文件系统的数据结构而无需改变登录、帐号信息或传输参数
	FTP_CMD_STAT,//使一个状态响应以应答的形式通过控制连接发送出去
	FTP_CMD_STOR,//让服务器接收一个来自数据连接的文件
	FTP_CMD_STOU,//让服务器准备接收一个文件
	FTP_CMD_STRU,//指定传达数据的结构类型
	FTP_CMD_SYST,//查明服务器上操作系统的类型
	FTP_CMD_TYPE,//确定数据的传输方式
	FTP_CMD_USER,//指定远程系统上的用户名称

	FTP_STATE_227, //被动协商端口
	FTP_STATE_257,//还回当前路径
};

typedef struct {
	char direction;//0:client->server,1:server->client
	void* buffer;//缓存区
	int length;//数据长度
} tcppacket_t;


struct ftpcontrol_struct;
//FTP协商的数据连接
typedef struct{
	packetjack_t sonsult;//协商IP与端口
	uint16_t cmd;//命令
	uint16_t method;//传递方式{FTP_CMD_PORT:主动,FTP_CMD_PASV:被动}
	time_t created;//创建时间
	uint8_t fname[128];//文件名
	struct ftpcontrol_struct* control;//ftp控制流,在ftp_data_port_add中赋值
	struct list_head list;//链表头
} ftplink_t;

//FTP控制连接
typedef struct ftpcontrol_struct {
	packetjack_t src;//原IP与端口
	packetjack_t dst;//目的IP与端口
	uint16_t command;//最后命令
	uint8_t path[128];//上传文件路径
	uint8_t user[64];//用户名
	uint8_t pass[64];//密码
	ftplink_t* last;//最后一个会话数据
} ftpcontrol_t;


extern ftplink_t* ftplinks_indexof(tcpflowhdr_t *e);//检测是否为FTP数据连接
extern int ftplinks_append(ftplink_t* item);//添加FTP数据连接
extern int ftplinks_remove(ftplink_t *e);//删除一个数据连接
extern int ftplinks_control_clean(ftpcontrol_t *c);//删除一个FTP控制连接中所有数据连接

//-------------------------------------------------------------------------------
extern void ftpcontrol_initialize(tcpsession_t *ht);//FTP控制初始化
extern int ftpcontrol_command(const char*p, unsigned int len);//FTP命令识别
extern void ftpcontrol_initialize(tcpsession_t *ht);//FTP控制初始化
extern int ftpcontrol_process(tcpsession_t *ht, tcppacket_t *o);//处理FTP控制连接指令

//--------------------------------------------------------------
extern int ftpdata_addport(tcpsession_t* ht, tcppacket_t *o, uint16_t type);//添加一个协商端口
extern int ftpdata_process(ftplink_t *item);//提交FTP数据连接文件

#endif /* DETECT_DAC_NIDS_FTP_H_ */
