/*
 * dbarea.h
 *
 *  Created on: 2016年3月10日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_DBAREA_H_
#define LIULQNET_TCPCONVERGE_DBAREA_H_
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#ifdef DEBUG_MEMPAGE

#define MEMPAGE_DEBUG(format, args...) {\
		printf("%s:%d  ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else

#define MEMPAGE_DEBUG(format, args...)  {}while(0)

#endif

//填充区域数据结构体
typedef struct fillarea_struct {
	uint32_t start;
	uint32_t finish;
	struct fillarea_struct* next;
} fillarea_t;

//数据区域数据
typedef struct {
	uint32_t finish;//已完成大小
	fillarea_t* areas;//数据区域列表
} dbarea_t;
/**判断数据是否完整
 *@parameter o: dbarea_t结构体对象
 */
int dbarea_hasfinish(dbarea_t* o);



//******************************************************************************
//内存池对象内存映射节点
typedef struct mapbuffer_struct {
	struct mapbuffer_struct* next;//下一个节点
	unsigned char buffer[];//数据缓存区
} mapbuffer_t;

//内存池的页内存申请
typedef mapbuffer_t*(*pagemem_alloc)(unsigned int psize);
//内存池的页内存释放
typedef void (*pagemem_free)(void*);

//页内存池
typedef struct {
	pthread_mutex_t	lock;//互斥锁
	unsigned int byteused;//使用字节数
	unsigned int bytemax;//填充的最大数据位置
	unsigned int pagesize;//一页数据大小
	pagemem_alloc page_alloc;//申请一页内存
	pagemem_free page_free;//释放一页内存
	mapbuffer_t* head;//内存页链表头
}mempagepool_t;


//******************************************************************************
//file header for snort DacPcap format log files
typedef struct {
	uint32_t magic;
	uint16_t version_major;
	uint16_t version_minor;
	uint32_t timezone;
	uint32_t sigfigs;
	uint32_t snaplen;
	uint32_t linktype;
} pcapfilehdr_t;

typedef struct  {
	char filename[128];//文件名
	FILE *stream;//文件流
	pcapfilehdr_t hdr;
} pcapfile_t;


typedef struct {
	uint32_t tv_sec, tv_usec;
}pcaptimeval_t;
// this is equivalent to the pcap pkthdr struct
typedef struct  {
	pcaptimeval_t ts;     // packet timestamp
	uint32_t caplen;      // packet capture length
	uint32_t pktlen;      // packet "real" length
} pcappkthdr_t;


/**PCAP包文件读取器
 *@parameter addr:文件地址
 *@parameter callback:回调函数
 */
void pcapfile_reader(const char* addr, void (*callbak)(void* pkt, unsigned int len));
/**打开PCAP对象文件
 *@parameter pcap:pcap文件对象
 */
int pcapfile_open(pcapfile_t* pcap);
/**关闭PCAP对象文件
 *@parameter pcap:pcap文件对象
 */
void pcapfile_close(pcapfile_t* pcap);
/**向pcap文件写记录包
 *@parameter pcap:pcap文件对象
 *@parameter pkt:包数据
 *@parameter caplen:包长度
 *@parameter len:数据长度
 */
int pcapfile_write(pcapfile_t* pcap, void* pkt, int caplen, int len);
#endif /* LIULQNET_TCPCONVERGE_DBAREA_H_ */
