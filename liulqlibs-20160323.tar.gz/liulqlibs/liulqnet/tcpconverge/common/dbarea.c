/*
 * dbarea.c
 *
 *  Created on: 2016年3月9日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "liulqdebug.h"
#include "local.h"

#ifdef DEBUG_DBAREA

#define DBAREA_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#else

#define DBAREA_DEBUG(format, args...)  {}while(0)

#endif

/**判断是否为重复数据
 *@parameter o: dbarea_t结构体对象
 *@parameter offset:数据偏移
 *@parameter finish:结束位置
 */
char dbarea_inareas(dbarea_t* o, uint32_t offset, uint32_t finish)
{
	fillarea_t* item = o->areas;
	while(item) {
		if(item->start <= offset && item->finish > offset) {//数据重叠
			DBAREA_DEBUG("part repeat {start:%u,finish:%u} include {offset:%u,finish:%u}\n", item->start, item->finish, offset, finish);
			return 1;
		}
		if(item->start == offset && item->finish == finish) {
			DBAREA_DEBUG("repeat data{start:%u,finish:%u}=={offset:%u,finish:%u}\n", item->start, item->finish, offset, finish);
			return 1;
		}
		item=item->next;
	}
	//GDB_DEBUGS("offset:%u,finish:%u\n", offset, finish);
	return 0;
}

/**合并数据区
 *@parameter o: dbarea_t结构体对象
 */
static inline void dbarea_merge(dbarea_t* o)
{
	fillarea_t* item = o->areas, *itemn;
	if(o->areas) {
		while(item) {
			itemn=item->next;
			if(itemn && item->finish == itemn->start) {
				DBAREA_DEBUG("merge segment{start:%u,finish:%u}<<{offset:%u,finish:%u}\n", item->start, item->finish, itemn->start, itemn->finish);
				item->finish = itemn->finish;
				//从列表中删除节点
				item->next = itemn->next;
				free(itemn);
			}
			item=item->next;
		}
	}
}

/**添加数据区域
 *@parameter o: dbarea_t结构体对象
 *@parameter offset:数据偏移
 *@parameter finish:结束位置
 */
char dbarea_addarea(dbarea_t* o, uint32_t offset, uint32_t finish)
{
	int added = 0;
	//GDB_DEBUGS("%p{offset:%u,finish:%u}\n", o, offset, finish);
	fillarea_t* item = o->areas, *itemn, *nitem, *litem;
	if(o->areas) {
		while(item) {
			if(item->start == finish + 1) {//在节点首部,合并
				item->start = offset;
				return 1;
			}
			if(item->finish + 1 == offset) {//在节点尾部,合并
				item->finish = finish;
				return 1;
			}
			item=item->next;
		}

		item = o->areas;
		while(item) {//没有相连,则添加
			litem = item;
			itemn=item->next;
			if(offset < item->start) {
				nitem = (fillarea_t*)calloc(1, sizeof(fillarea_t));
				nitem->start = offset;
				nitem->finish = finish;
				DBAREA_DEBUG("insert segment{start:%u,finish:%u}<={offset:%u,finish:%u}\n", item->start, item->finish, itemn->start, itemn->finish);
				//添加节点到列表
				nitem->next = itemn;
				item->next = nitem;
				added = 1;
				break;
			}
			item=itemn;
		}
		if(!added) {
			fillarea_t* tmp = (fillarea_t*)calloc(1, sizeof(fillarea_t));
			tmp->start = offset;
			tmp->finish = finish;
			litem->next = tmp;
			//DBAREA_DEBUG("append segment{start:%u,finish:%u} + {offset:%u,finish:%u}\n", litem->start, litem->finish, tmp->start, tmp->finish);
		}
	} else {//第一次添加
		o->areas = (fillarea_t*)calloc(1, sizeof(fillarea_t));
		o->areas->start = offset;
		o->areas->finish = finish;
		DBAREA_DEBUG("first segment{start:%u,finish:%u}\n", o->areas->start, o->areas->finish);
	}
	dbarea_merge(o);
	return 0;
}


/**判断数据是否完整
 *@parameter o: dbarea_t结构体对象
 */
int dbarea_hasfinish(dbarea_t* o)
{
	return ((NULL != o->areas && NULL == o->areas->next));
}

void dbarea_showparts(dbarea_t* o)
{
	if(!o) return;
	char has=0;
	fillarea_t* item = o->areas, *next;
	while(item) {
		next = item->next;
		if(next) {
			printf("[%u-%u]", item->finish, next->start);
			has = 1;
		}
		item = next;
	}
	if(has) {
		printf("\n");
	}
}
/**释放节点内存
 *@parameter o: dbarea_t结构体对象
 */
void dbarea_free(dbarea_t* o)
{
	fillarea_t* item = o->areas, *next;
	while(item) {
		next = item->next;
		DBAREA_DEBUG("delete segment{start:%u,finish:%u}\n", item->start, item->finish);
		free(item);
		//item = NULL;
		item = next;
	}
	o->areas = NULL;
	o->finish = 0;
}

