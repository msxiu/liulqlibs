/*
 * pcapfile.c
 *
 *  Created on: 2016年3月11日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "dbarea.h"


/**PCAP包文件读取器
 *@parameter addr:文件地址
 *@parameter callback:回调函数
 */
void pcapfile_reader(const char* addr, void (*pcapcallback)(void* pkt, unsigned int len))
{
	int state = 0;
	void* buffer;
	pcapfilehdr_t fhdr;
	pcappkthdr_t phdr;
	pcapfile_t pcap;// = { .filename = addr };

	printf("pcapfile_reader:'%s';\n", addr);
	strcpy(pcap.filename, addr);
	pcap.stream = fopen(addr, "rb");
	if(NULL == pcap.stream) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return;
	}
	state = fread(&fhdr, sizeof(pcapfilehdr_t), 1, pcap.stream);

	while(!feof(pcap.stream)) {
		state =  fread(&phdr, sizeof(pcappkthdr_t), 1, pcap.stream);
		buffer = calloc(1, phdr.caplen);
		state =  fread(buffer, phdr.caplen, 1, pcap.stream);
		pcapcallback(buffer, phdr.caplen);
		free(buffer);
	}
	fclose(pcap.stream);
}

/**打开PCAP对象文件
 *@parameter pcap:pcap文件对象
 */
int pcapfile_open(pcapfile_t* pcap)
{
	pcap->stream = fopen(pcap->filename, "rb");
	if(NULL == pcap->stream) {
		GDB_WARNS("open pcap file '%s' error:%s", pcap->filename, strerror(errno));
		return -1;
	}
	if(fwrite((char *)&(pcap->hdr), sizeof(pcapfilehdr_t), 1, pcap->stream) != 1) {
		GDB_WARNS("PcapLogInit(): %s", strerror(errno));
	}
	fflush(pcap->stream);
	return 0;
}

/**关闭PCAP对象文件
 *@parameter pcap:pcap文件对象
 */
void pcapfile_close(pcapfile_t* pcap)
{
	fclose(pcap->stream);
}

/**向pcap文件写记录包
 *@parameter pcap:pcap文件对象
 *@parameter pkt:包数据
 *@parameter caplen:包长度
 *@parameter len:数据长度
 */
int pcapfile_write(pcapfile_t* pcap, void* pkt, int caplen, int len)//
{
	time_t curr_time;      /* place to stick the clock data */
	curr_time = time(NULL);
	pcappkthdr_t dacPcapPktHeader;
	dacPcapPktHeader.ts.tv_sec = curr_time;
	dacPcapPktHeader.ts.tv_usec = 0;
	dacPcapPktHeader.caplen = caplen;
	dacPcapPktHeader.pktlen = len;

	if(fwrite((void*)(&(dacPcapPktHeader)), sizeof(pcappkthdr_t), 1, pcap->stream) != 1) {
		GDB_WARNS("PcapPktHeader: write failed: %s\n", strerror(errno));
	}
	if(pkt && fwrite(pkt, caplen, 1, pcap->stream) != 1) {
		GDB_WARNS("PcapPktHeader: write failed: %s\n", strerror(errno));
	}
	fflush(pcap->stream);
	return 0;
}
