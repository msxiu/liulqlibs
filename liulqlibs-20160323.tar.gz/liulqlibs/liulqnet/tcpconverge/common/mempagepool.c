/*
 * api_poolbuffer.c
 *
 *  Created on: 2016年1月10日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

#include "local.h"
#include "liulqdebug.h"

#define RESET_POOLBUFFER(o)	{\
	o->byteused = 0;\
	o->bytemax = 0;\
	o->head = NULL;\
} while(0)

static pthread_mutex_t mempagepool_lock = PTHREAD_MUTEX_INITIALIZER;//互斥锁


//************************************************************************************************
/**释放一页内存
 *@parameter o:内存池对象
 *@parameter addr:内存地址
 */
static inline void mempagepool_free_memory(mempagepool_t *o, void* addr)//回收内存,利于gdb查看地址
{
	if(o && addr) {//&& addr >= 0x1000000
		//MEMPAGE_DEBUG("%p=>free %p\n", o, addr);
	    pthread_mutex_lock(&mempagepool_lock);//在操作全局变量pool之前,需要先上锁
		o->page_free(addr);
		addr = NULL;
	    pthread_mutex_unlock(&mempagepool_lock);//
	}
}

/**申请一页内存
 *@parameter o:内存池对象
 */
static inline mapbuffer_t* mempagepool_calloc(mempagepool_t *o)
{
	int max_cnt = 5;
	mapbuffer_t* addr = NULL;
	//while(!addr && max_cnt--) {
		pthread_mutex_lock(&mempagepool_lock);//在操作全局变量pool之前,需要先上锁
		addr = o->page_alloc(o->pagesize);
		pthread_mutex_unlock(&mempagepool_lock);//
		//if(!addr) usleep(5);
	//}
	if(NULL == addr) {
		GDB_WARNS("%p:mempagepool_calloc fail!\n", o);
	} else {
		//MEMPAGE_DEBUG("%p=>alloc %p\n", o, addr);
	}
	return addr;
}

/**向内存写入数据,利于gdb查看地址
 *@parameter o:内存池对象
 *@parameter pa:页地址
 *@parameter ps:页偏移
 *@parameter data:数据
 *@parameter len:数据长度
 */
static inline void mempagepool_write_data(mempagepool_t *o, void* pa, unsigned int ps, const void* data, unsigned int len)
{
	if(o) {
		if((ps + len) > o->pagesize){
			GDB_DEBUGS("write warn {pa:%p,ps:%d,data:%p,len:%d,override:%d};\n", pa, ps, data, len, (ps+len-o->pagesize));
		}
		memcpy((char*)pa + ps, data, len);
	}
}
/**向内存写入数据,利于gdb查看地址
 *@parameter o:内存池对象
 *@parameter pa:页地址
 *@parameter ps:页偏移
 *@parameter data:数据
 *@parameter len:数据长度
  */
static inline void mempagepool_read_data(mempagepool_t *o, void* pa, unsigned int ps, const void* data, unsigned int len)//
{
	if(o) {
		memcpy((char*)pa + ps, data, len);
	}
}

/**计算页地址
 *@parameter o:内存池对象
 *@parameter pg:页码
  */
static mapbuffer_t* calculate_page_address(mempagepool_t *o, int pg)
{
#define MOVETO_NEXT(a) 	((a)=(a)->next)
	int index = 0;
	mapbuffer_t* page = o->head, *lastpage=NULL;

	while(page && index < pg) {
		lastpage = page;
		page = page->next;
		index++;
	}
	//GDB_DEBUGS("page index:%d, finish!\n", index);

	while(index < pg) {
		page = mempagepool_calloc(o);
		if(NULL == page) {
			GDB_DEBUGS("page index:%d, malloc fail!\n", pg);
			return NULL;
		}
		if(lastpage) {
			lastpage->next = page;
			MOVETO_NEXT(lastpage);
		} else {
			lastpage = o->head = page;
		}
		index++;
	}
	//GDB_DEBUGS("%p:%d(%p)!\n", o, pg, lastpage);
	return lastpage;
}

//************************************************************************************************
/**初始化内存池对象
 *@parameter o:内存池对象
  */
char mempagepool_initialize(mempagepool_t *o)
{
	pthread_mutex_init(&(o->lock), NULL);//初始化 互斥锁
	RESET_POOLBUFFER(o);
	return 1;
}

/**向缓存区写数据
 *@parameter o:内存池对象
 *@parameter offset:数据写入位置
 *@parameter str:写入数据
 *@parameter len:数据长度
 */
int mempagepool_write(mempagepool_t *o, unsigned int offset, const void* data, unsigned int len)//
{
	if((len <=  0)) return -1;//超出最大值
	if( (offset +len) > (o->byteused + o->pagesize)) {
		MEMPAGE_DEBUG("over max memory:%p=>alloc %u+%u\n", o, offset, len);
		return -1;
	}
	unsigned int pnext, pgindex = (offset / o->pagesize) + ((0 != offset && 0 == (offset % o->pagesize)) ? 0 : 1);//pi = (unsigned int) (o->byteused / o->pagesize),
	unsigned int ps = (0 == offset) ? 0 : (offset - ((pgindex-1) * o->pagesize));//当前页使用空间
	unsigned int pl = o->pagesize - ps, lastpos = offset + len;//当前页空闲空间
	mapbuffer_t* map = (mapbuffer_t*)calculate_page_address(o, pgindex);
	if(!map)  {
		GDB_WARNS("calculate_page_address error(%p:%d) offset:%u\n", o, pgindex, offset);
		return -1;
	}
//	GDB_DEBUGS("pg%u:%p{used:%u, ps:%u, len:%u}\n", pgindex, map, o->byteused, ps, len);
    pthread_mutex_lock(&o->lock);//在操作全局变量pool之前,需要先上锁
	void* pa = (void*)map->buffer;
	if(pl > len) {
		mempagepool_write_data(o, pa, ps, data, len);
		o->byteused += len;
		if(o->bytemax < lastpos) o->bytemax = lastpos;
	} else {
		//写入数据到原页尾 memcpy(pa + ps, data, pl);
		mempagepool_write_data(o, pa, ps, data, pl);
		pnext = len - pl;
		while(pnext > 0) {
			pgindex++;
			map= (mapbuffer_t*)calculate_page_address(o, pgindex);
			if(!map)  return -1;
			pa= (void*)map->buffer;
			if(pnext < o->pagesize){
				mempagepool_write_data(o, pa, 0, ((const char*)data + pl), pnext);
				pnext = 0;
			} else {
				mempagepool_write_data(o, pa, 0,  ((const char*)data + pl), o->pagesize);
				pnext -= o->pagesize;
				pl += o->pagesize;
			}
		}
		o->byteused += len;
		if(o->bytemax < lastpos) o->bytemax = lastpos;
	}
    pthread_mutex_unlock(&o->lock);//在操作完全局变量pool后,需要解锁
	return len;
}

/**向缓存区写字符串数据
 *@parameter o:内存池对象
 *@parameter offset:数据写入位置
 *@parameter str:写入字符串
 */
int  mempagepool_writes(mempagepool_t *o, unsigned int offset, const char* str)
{
	return mempagepool_write(o, offset, str, strlen(str) );
}

/**获得首页数据地址
 *@parameter o:内存池对象
 */
void* mempagepool_first(mempagepool_t *o)//
{
	mapbuffer_t* map = (mapbuffer_t*)o->head;
	return (map ? map->buffer : NULL);
}

/**读取完后清空数据
*@parameter o:内存池对象
*@parameter buffer:数据存储缓冲区
 */
unsigned int mempagepool_readreset(mempagepool_t *o, void* buffer, unsigned int mlen)
{
	if(o->byteused <= 0 || !buffer) return 0;
	int i=0, pgmax=0, pos = 0, pgbys, ret = 0;
    pthread_mutex_lock(&o->lock);//在操作完全局变量pool后,需要解锁
	mapbuffer_t* map = o->head, *tmap;
	while(map) {
		pgmax = (i * o->pagesize);
		pgbys = (o->byteused - pgmax);
		if(pgbys > o->pagesize) pgbys = o->pagesize;

		if(pos + pgbys <= o->bytemax) {
			mempagepool_read_data(o, buffer, pos, map->buffer, pgbys);
		} else {
			MEMPAGE_DEBUG(" %p[%u/%u]:<=%p(%u:%u)\n", buffer, pos, mlen, map->buffer, pgbys, o->bytemax);
		}
		pos += o->pagesize;
		ret += pgbys;
		tmap = (mapbuffer_t*)map->next;
		mempagepool_free_memory(o, map);
		map = tmap;
		i++;
	}
	RESET_POOLBUFFER(o);
    pthread_mutex_unlock(&o->lock);//在操作完全局变量pool后,需要解锁
	if(pos < mlen){
		memset(((char*)buffer + pos), 0, 1);//置0最后一位
	}
	return ret;
}

/**重置缓存区
*@parameter o:内存池对象
 */
void mempagepool_reset(mempagepool_t *o)
{
	pthread_mutex_lock(&o->lock);//在操作完全局变量pool后,需要解锁
	if(o->byteused > 0) {
		mapbuffer_t* map = o->head, *tmap;
		while(map) {
			tmap = (mapbuffer_t*)map->next;
			mempagepool_free_memory(o, map);
			map = tmap;
		}
		RESET_POOLBUFFER(o);
	}
	pthread_mutex_unlock(&o->lock);//在操作完全局变量pool后,需要解锁
}

/**回收缓存区
*@parameter o:内存池对象
 */
void mempagepool_free(mempagepool_t *o)
{
	pthread_mutex_lock(&o->lock);//在操作完全局变量pool后,需要解锁
	if(o->byteused > 0) {
		mapbuffer_t* map = o->head, *tmap;
		while(map) {
			tmap = (mapbuffer_t*)map->next;
			mempagepool_free_memory(o, map);
			map = tmap;
		}
		RESET_POOLBUFFER(o);
	}
	pthread_mutex_unlock(&o->lock);//在操作完全局变量pool后,需要解锁
}

