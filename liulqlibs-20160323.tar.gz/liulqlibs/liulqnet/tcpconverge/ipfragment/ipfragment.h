/*
 * ip_fragment.h
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */

#ifndef LIULQNET_LIULQFLOW_IP_FRAGMENT_H_
#define LIULQNET_LIULQFLOW_IP_FRAGMENT_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "dbarea.h"
//标志:更多碎片
#define IP_ME			0x2000
//碎片位置部分
#define IP_OFFSET		0x1FFF

enum ether_type {
	ETHER_IP = 0x0800,
	ETHER_ARP = 0x0806,
	ETHER_IPV6 = 0x86dd,
};

#ifdef DEBUG_IPFRAG
extern int pkt_index;

#define IPFRAG_DEBUG(format, args...) {\
		printf("%s:%d pkt:%u ", __FILE__, __LINE__, pkt_index);\
		printf(format, ##args);\
}
#else

#define IPFRAG_DEBUG(format, args...)  {}while(0)

#endif


//******************************************************************************
//IP碎片哈希结构体
typedef struct {
	uint32_t src;//原IP
	uint32_t dst;//目的IP
} ipfraghash_t;

//IP碎片内存对象
typedef struct {
	uint32_t total;//总大小
	dbarea_t area;//数据区域记录
	uint8_t buffer[];//数据缓存去
}memipfrag_t;

/**申请一个dbarea_t数据对象
 * @parameter size:数据缓存区大小
 */
memipfrag_t* memipfrag_alloc(uint32_t size);

/**向dbarea_t结构体填充数据
 *@parameter o: dbarea_t结构体对象
 *@parameter data:填充数据
 *@parameter len:填充数据长度
 *@return 还回是否完整
 */
int memipfrag_filldata(memipfrag_t* o, uint32_t offset, void* data, uint32_t len);


#endif /* LIULQNET_LIULQFLOW_IP_FRAGMENT_H_ */
