/*
 * ipfragmem.c
 *
 *  Created on: 2016年3月10日
 *      Author: root
 */
#include <stdio.h>

#include "local.h"

/**申请一个dbarea_t数据对象
 * @parameter size:数据缓存区大小
 */
memipfrag_t* memipfrag_alloc(uint32_t size)
{
	memipfrag_t *res = (memipfrag_t*)calloc(1, sizeof(memipfrag_t) + size);
	if(NULL != res) {
		res->total = size;
		res->area.finish = 0;
		res->area.areas = NULL;
	}
	return res;
}

void memipfrag_destory(memipfrag_t* o)
{
	dbarea_free(&(o->area));
	free(o);
}

/**向memipfrag_t结构体填充数据
 *@parameter o: memipfrag_t结构体对象
 *@parameter data:填充数据
 *@parameter len:填充数据长度
 *@return 还回是否完整
 */
int memipfrag_filldata(memipfrag_t* o, uint32_t offset, void* data, uint32_t len)
{
	int finish = (offset + len);
	if(!dbarea_inareas(&(o->area), offset, finish)) {
		IPFRAG_DEBUG("ip frag add(%u+%u=%u)\n", offset, len, (offset + len));
		memcpy(o->buffer+offset, data, len);
		dbarea_addarea(&(o->area), offset, finish);
	}
	return (o->total == o->area.finish && dbarea_hasfinish(&(o->area)));
}
