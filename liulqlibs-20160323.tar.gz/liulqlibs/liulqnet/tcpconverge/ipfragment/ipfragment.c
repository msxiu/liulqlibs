/*
 * ipfragment.c
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>

#include "liulqdebug.h"
#include "local.h"


/**添加IP碎片处理初始化
 *@parameter o:对象
 *@parameter mx:最大hash数
 */
int ipfrag_initialize(ipfrag_t* o, int mx, ipfrag_execute process_ip, ipfrag_execute process_arp)
{
	o->map = (hashmap_t*)hashmap_ipfrag_create(mx);
	o->handle_ip = process_ip;
	o->handle_arp = process_arp;
	return 0;
}

static inline uint16_t ipfrag_ether_type(char* pkt) //获得二层协议类型
{
	uint16_t ret;
	memcpy(&ret, pkt + 12, 2);
	ret = ntohs(ret);
	return ret;
}
static inline int fpfrag_ippacket(ipfrag_t* o, void* pkt, unsigned int len)
{
	int offset, flags, ip_off, tot_len, head_len;
	struct ip* iph =(struct ip*)(((char*)pkt) + LEN_ETHER_HEADER);
	ipfraghash_t fhdr;// = { .src = ntohl(iph->ip_src.s_addr), .dst = ntohl(iph->ip_dst.s_addr) };

	fhdr.src = ntohl(iph->ip_src.s_addr);
	fhdr.dst = ntohl(iph->ip_dst.s_addr);

	ip_off = offset = ntohs(iph->ip_off);
	head_len = (4 * iph->ip_hl);
	flags = offset & ~IP_OFFSET;
	offset &= IP_OFFSET;
	tot_len = ntohs(iph->ip_len);

	if(((flags & IP_ME) == 0) && (offset == 0)) {//非IP碎片
		IPFRAG_DEBUG("[ip complate]" FMT_IPADDR "=>" FMT_IPADDR ",flags:%u&%u,tot_len:%d;\n", TO_IPADDR(fhdr.src), TO_IPADDR(fhdr.dst), flags, IP_ME, tot_len);
		o->handle_ip(pkt, len);
		return 1;
	}

	//IP碎片
	memipfrag_t* frag = (memipfrag_t*)hashmap_find(o->map, &fhdr);
	if(NULL == frag) {//没有匹配到对象,需新建
		frag = memipfrag_alloc(tot_len + head_len + LEN_ETHER_HEADER);
	}
	if(0 == offset) {//首包处理,需要添加IP头数据
		if(memipfrag_filldata(frag, 0, pkt, len)) {
			//IPFRAG_DEBUG("[first ip frag]" FMT_IPADDR "=>" FMT_IPADDR ",headlen:%d,ip_off:%d(offset:%d|flags:%d),tot_len:%d;\n", TO_IPADDR(fhdr.src), TO_IPADDR(fhdr.dst), head_len, ip_off, offset, flags, tot_len);
			o->handle_ip(frag->buffer, frag->area.finish);
			hashmap_delitem(o->map, &fhdr);
			return 1;
		}
	} else {//其他包处理
		if(memipfrag_filldata(frag, offset, pkt + head_len, len - head_len)) {
			//IPFRAG_DEBUG("[ip frag]" FMT_IPADDR "=>" FMT_IPADDR ",headlen:%d,ip_off:%d(offset:%d|flags:%d),tot_len:%d;\n", TO_IPADDR(fhdr.src), TO_IPADDR(fhdr.dst), head_len, ip_off, offset, flags, tot_len);
			o->handle_ip(frag->buffer, frag->area.finish);
			hashmap_delitem(o->map, &fhdr);
			return 1;
		}
	}
	IPFRAG_DEBUG("[ip frag fail]" FMT_IPADDR "=>" FMT_IPADDR ",headlen:%d,ip_off:%d(offset:%d|flags:%d),tot_len:%d;\n", TO_IPADDR(fhdr.src), TO_IPADDR(fhdr.dst), head_len, ip_off, offset, flags, tot_len);
	return 0;
}

/**添加IP包
 *@parameter o:对象
 *@parameter packet:数据包
 *@parameter len:数据包长度
 */
int ipfrag_addpacket(ipfrag_t* o, void* pkt, unsigned int len)
{
	uint16_t ethtype = ipfrag_ether_type(pkt);
	switch(ethtype)
	{
	case ETHER_ARP: {
		struct ether_arp* arp = (struct ether_arp*)(pkt + 14);
		uint32_t srcip =*((uint32_t*)arp->arp_spa);
		IPFRAG_DEBUG("[ARP packet] ethtype:%x, src ip:" FMT_IPADDR ";\n", ethtype, TO_IPLOCAL(srcip));
		if(o->handle_arp) {
			return o->handle_arp(pkt, len);
		}
		return 0;
	}
	case ETHER_IP:
		if(o->handle_ip) {
			return fpfrag_ippacket(o, pkt, len);
		}
		return 0;
	}
	IPFRAG_DEBUG("[ignore packet] ethtype:%x;\n", ethtype);
	return 0;
}

