/*
 * iphash.c
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>

#include "local.h"


//*******************************************************
static int hashmap_ipfrag_compare(const void* a, const void* b)//
{
	ipfraghash_t* ip1 = (ipfraghash_t*)a, * ip2 = (ipfraghash_t*)b;
	return ((ip1->src == ip2->src) && (ip1->dst == ip2->dst));
}
static void hashmap_ipfrag_bind(hashelement_t* o,  const void* key)
{
	size_t mln = sizeof(ipfraghash_t);
	if(!o->key) o->key = malloc(mln);
	memcpy(o->key, key, mln);
}
static uint16_t hashmap_ipfrag_key(const void* key, uint32_t maxhash)
{
    uint32_t hash = 0;
    ipfraghash_t ap =  *((ipfraghash_t*)key);
    hash = ((ap.src>>16) & 0xFFFF) + (ap.src & 0xFFFF) + ((ap.dst>>16) & 0xFFFF) + (ap.dst & 0xFFFF);
	while(hash >= maxhash) {
		hash = (hash / maxhash) + (hash % maxhash);
	}
    return hash;
}

//****************************************************************************
hashmap_t* hashmap_ipfrag_create(int size) //创建存储汇聚流需要的哈希table
{
	return hashmap_create(size, &hashmap_ipfrag_compare, &hashmap_ipfrag_key, &hashmap_ipfrag_bind);
}


