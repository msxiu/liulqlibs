/*
 * local.h
 *
 *  Created on: 2016年3月9日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_LOCAL_H_
#define LIULQNET_TCPCONVERGE_LOCAL_H_

#include "dbarea.h"
#include "ipfragment/ipfragment.h"
#include "tcpflow/tcpflow.h"
#include "liulqtcpconverge.h"

//物理包头长度
#define LEN_ETHER_HEADER	14
//小于
#define THAN_LESS(a,b)		((int)((a)-(b)) < 0)
//大于
#define THAN_GREAT(a,b)		((int)((b)-(a)) < 0)


#endif /* LIULQNET_TCPCONVERGE_LOCAL_H_ */
