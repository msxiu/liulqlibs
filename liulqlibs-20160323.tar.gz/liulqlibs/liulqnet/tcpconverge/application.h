/*
 * application.h
 *
 *  Created on: 2016年3月10日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_APPLICATION_APPLICATION_H_
#define LIULQNET_TCPCONVERGE_APPLICATION_APPLICATION_H_
#include "liulqtcpconverge.h"

#ifdef DEBUG_TCPAPPLY
extern int pkt_index;

#define TCPAPPLY_DEBUG(format, args...) {\
		printf("%s:%d %u ", __FILE__, __LINE__, pkt_index);\
		printf(format, ##args);\
}
#else

#define TCPAPPLY_DEBUG(format, args...)  {}while(0)

#endif


enum TIPS_APP_PROTOCOL {
	PROTOCOL_NONE = 0,//未知协议
	PROTOCOL_HTTP = 1,//HTTP
	PROTOCOL_220		= 2,
	PROTOCOL_SMTP = 3,//SMTP
	PROTOCOL_FTP = 4,//FTP
	//PROTOCOL_FTP_DATA,
	PROTOCOL_OTHER	= 999,
};

/**流汇聚时包处理函数
 *@parameter tcp:流汇聚对象
 *@parameter buffer:数据缓存
 *@parameter len:数据长度
 *@return :还回真,需回调流处理
 */
extern char tcpflow_packet(tcpsession_t* ht, char fclient, uint32_t offset, void* p, uint32_t len);
extern int tcp_segment_process(tcpsession_t* ht);//TCP流部分提交处理
extern int tcp_recover_process(tcpsession_t* ht);//TCP流部分提交处理

#endif /* LIULQNET_TCPCONVERGE_APPLICATION_APPLICATION_H_ */
