/*
 * appmemptool.c
 * 用于TCP流汇聚时的页内存申请
 *  Created on: 2016年3月11日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dbarea.h"

/**内存池的页内存申请
 *@parameter psize:申请页大小
 */
mapbuffer_t* tcppagemem_alloc(unsigned int psize)
{
	return (mapbuffer_t*)calloc(1, sizeof(mapbuffer_t) + psize);
}

/**内存池的页内存释放
 *@parameter addr:释放地址
 */
void tcppagemem_free(void* addr)
{
	free(addr);
}
