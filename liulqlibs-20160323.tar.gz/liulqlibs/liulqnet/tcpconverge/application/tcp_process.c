/*
 * action_process.c
 *
 *  Created on: 2016年3月11日
 *      Author: root
 */
#include <stdio.h>
#include "liulqdebug.h"
#include "local.h"
#include "application.h"
#include "ftp.h"

int tcp_segment_process(tcpsession_t* ht)//TCP流部分提交处理
{
	if(NULL != ht->content &&  ((memtcpflow_t*)ht->content)->pagepool.byteused > 0) {
		switch(ht->protocol) {
			case PROTOCOL_HTTP: return tcp_http_process(ht);
			case PROTOCOL_SMTP: return tcp_smtp_process(ht);
			//case PROTOCOL_FTP: return tcp_ftp_process(ht);//FTP在此不能处理
		}
		ftplink_t* ftp = ftplinks_indexof(&(ht->hdr));
		if(NULL != ftp) {//FTP数据连接
			return ftpdata_process(ftp);
		}
	}
	return PROTOCOL_NONE;
}

int tcp_recover_process(tcpsession_t* ht)//TCP流部分提交处理
{
	switch(ht->protocol) {
		case PROTOCOL_FTP:
			ftplinks_control_clean((ftpcontrol_t*)ht->content);
		break;
		default:break;
	}
	return 0;
}

int tcp_http_process(tcpsession_t* ht)
{
	memtcpflow_t* item = (memtcpflow_t*)ht->content;
	char* buffer, hln[1024];
	int start, len, vln, pos;
	if(memtcpflow_complete(item)) {
		pos = memtcpflow_readreset(item, &buffer);
		if(buffer) {
			ht->validcount = 0;
			//GDB_DEBUGS("length:%d\n%s\n", pos, buffer);
			buffer_readline(buffer, &start, &len);
			vln = len - start;
			SET_BUFFER(hln, buffer+start, (vln > 1024 ? 1000 : vln));
			//GDB_WARNS("(length:%d)%s\n", pos, hln);
			free(buffer);
		}
	} else {
#ifdef DEBUG_TCPAPPLY
		GDB_WARNS("%p(%u/%u)\n", item, item->area.finish, item->size_max);
		dbarea_showparts(&(item->area));
#endif
		memtcpflow_reset(item);
	}
	return 0;
}

int tcp_smtp_process(tcpsession_t* ht)
{
	return 0;
}

//
//int tcp_ftp_process(tcpsession_t* ht)
//{
//	TCPAPPLY_DEBUG("tcp_ftp_process invoke error!\n");
//	return 0;
//}


