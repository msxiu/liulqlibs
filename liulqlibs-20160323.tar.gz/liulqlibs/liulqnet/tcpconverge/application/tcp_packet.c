/*
 * tcp_packet.c
 *
 *  Created on: 2016年3月11日
 *      Author: root
 */
#include "liulqdebug.h"
#include "local.h"
#include "application.h"
#include "ftp.h"


static inline void protocol_header_discern(tcpsession_t* ht, void* p, uint32_t len)
{
	switch(ht->protocol) {
		case PROTOCOL_NONE: {//首个数据包
			if(httpbuffer_start(p, len)) {
				ht->protocol = PROTOCOL_HTTP;
			} else  {
				if(discern_proto220(p, len)) {
					ht->protocol = PROTOCOL_220;
					if(smtp_discern(p, len)) {
						ht->protocol = PROTOCOL_SMTP;
					} else if(ftp_discern(p, len)) {
						ftpcontrol_initialize(ht);
					}
				}else {
					ht->protocol = PROTOCOL_OTHER;
				}
			}
		}
		break;
		case PROTOCOL_220: {//再次识别协议
			if(smtp_hello(p, len)) {
				ht->protocol =PROTOCOL_SMTP;
			} else if(ftpcontrol_command(p, len)) {
				ftpcontrol_initialize(ht);
			} else {
				//ht->protocol = PROTOCOL_OTHER;
			}
		}
		break;
	}
}

/**还回内存实体
 *@parameter ht:流汇聚对象
 */
static inline memtcpflow_t* get_memtcpflow_entity(tcpsession_t* ht)
{
	if(NULL == ht->content) {
		ht->content = memtcpflow_alloc(tcppagemem_alloc, tcppagemem_free, 10240);
	}
	return (memtcpflow_t*)ht->content;
}


/**流汇聚时包处理函数
 *@parameter ht:流汇聚对象
 *@parameter buffer:数据缓存
 *@parameter len:数据长度
 *@return :还回真,需回调流处理
 */
char tcpflow_packet(tcpsession_t* ht, char fclient, uint32_t offset, void* p, uint32_t len)
{
	char ret = 0;
	memtcpflow_t* buffer;
	if((ht->protocol == PROTOCOL_NONE ||ht->protocol == PROTOCOL_220) && len > 0) {
		protocol_header_discern(ht, p, len);//协议识别
	}
	switch(ht->protocol) {
		case PROTOCOL_HTTP: {
			buffer = get_memtcpflow_entity(ht);
			//TCPAPPLY_DEBUG("%p:{fclient:%d,offset:%u,len:%u, used:%u}\n", buffer, fclient, offset, len, buffer->pagepool.byteused);
			if(buffer->pagepool.byteused > 0) {
				int state = httpbuffer_start(p, len);
				if(state) {
					tcp_http_process(ht);
					ret= 1;
					//memtcpflow_reset(buffer);
				}
			}
			if(!ht->refuse) {
				memtcpflow_write(buffer, fclient, offset, p, len);
				TCPAPPLY_DEBUG("%p:{fclient:%d,offset:%u,len:%u, used:%u}\n", buffer, fclient, offset, len, buffer->pagepool.byteused);
			}
		break;
		}
		case PROTOCOL_SMTP: {
			buffer = get_memtcpflow_entity(ht);
			if(!ht->refuse) {
				memtcpflow_write(buffer, fclient, offset, p, len);
			}
			if(chars_start_with(p, "221 ")) {
				tcp_smtp_process(ht);
			}
			break;
		}
		case PROTOCOL_FTP: {//FTP控制链接
			ftpcontrol_command(p,len);
			break;
		}
		case PROTOCOL_OTHER: {
			ftplink_t*  ftpo = ftplinks_indexof(&(ht->hdr));
			if(NULL != ftpo) {//FTP数据连接
				if(!ht->refuse) {
					buffer = get_memtcpflow_entity(ht);
					memtcpflow_write(buffer, fclient, offset, p, len);
					//ALLOW_ADNDO(BIT_POS(BIT_STEP) | BIT_POS(BIT_FTP), printf("ftp command %d '%s';\n", ftpo->cmd, ftpo->fname));
					//PBUFFER_WRITE(&(ht->buffer), pkt->buffer, pkt->length);
				}
			}
			break;
		}
	}
	return ret;
}

