/*
 * tcp_protocol.c
 *
 *  Created on: 2016年3月11日
 *      Author: root
 */
#include <string.h>
#define MAX_SMTP_LINE	512

/**判断缓存流是否为SMTP协议
 *@parameter p:数据指针
 */
char smtp_comfirm(const char *p)
{
	int pos =4;
	if(!chars_start_with(p, "220 ")) return 0;
	while(pos < MAX_SMTP_LINE && p[pos] != '\0' && p[pos] != ' ') pos++;
	if(MAX_SMTP_LINE == pos) return 0;
	pos++;
	if(!chars_start_with(p+pos, "ESMTP")) return 0;
	if(!char_is_empty(*(p+pos+5))) return 0;
	return 1;
}
/**SMTP协议识别
 *@parameter p:数据指针
 *@parameter len:数据长度
 */
char smtp_discern(const char*p, int len)
{
	int pos =4;
	while(pos < len && p[pos] != '\0' && p[pos] != ' ') pos++;
	if(len == pos) return 0;
	pos++;
	if(!chars_start_with(p+pos, "ESMTP")) return 0;
	if(!char_is_empty(*(p+pos+5))) return 0;
	return 1;
}

/**SMTP/FTP协议头识别
 *@parameter p:数据指针
 *@parameter len:数据长度
 */
char discern_proto220(const char*p, int len)
{
	if(len < 4) return 0;
	if(chars_start_with(p, "220 ")) return 1;
	if(chars_start_with(p, "220-")) return 1;
	return 0;
}
/**SMTP协议识别
 *@parameter p:数据指针
 *@parameter len:数据长度
 */
char smtp_hello(const char*p, int len)
{
	const char *p1 = p+1;
	if(len < 5) return 0;
	switch(*p) {
		case 'E': return chars_start_with(p1, "HLO ");
		case 'H':return chars_start_with(p1, "ELO ");
	}
	return 0;
}

/**判断流是否为FTP协议
 *@parameter p:数据指针
 */
char ftp_comfirm(const char* p)
{
	int pos =4;
	while(pos < MAX_SMTP_LINE && p[pos] != '\0' && p[pos] != '\n') {
		if(p[pos] == 'F' && p[pos+1] == 'T' && p[pos+2] == 'P') return 1;
		pos++;
	}
	return 0;
}
/**FTP协议识别
 *@parameter p:数据指针
 *@parameter len:数据长度
 */
char ftp_discern(const char*p, int len)
{
	int pos =4;
	while(pos < len && p[pos] != '\0' && p[pos] != '\n') {
		if(p[pos] == 'F' && p[pos+1] == 'T' && p[pos+2] == 'P') return 1;
		pos++;
	}
	return 0;
}
