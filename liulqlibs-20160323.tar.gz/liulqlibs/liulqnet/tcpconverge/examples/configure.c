/*
 * configure.c
 *
 *  Created on: 2016年2月26日
 *      Author: root
 */
#include "local.h"

extern gdbentry_t gdbentry;//GDB调试设置对象


void config_print(void)
{
	printf("gdbentry.level:%d;\n", gdbentry.level);
	printf("gdbentry.state:%d;\n", gdbentry.state);
}
//参数解析函数
char argument_parse(void* par,const char* key, const unsigned int klen, const char *val, const unsigned int vlen)
{
	char pkey[klen+5];
	SET_BUFFER(pkey, key, klen);

	if(strcmp("gdbentry.level", pkey) == 0) {
		PARSE_INT_OF(gdbentry.level,  val, vlen);
	} else if(strcmp("gdbentry.state", pkey) == 0) {
		PARSE_INT_OF(gdbentry.state,  val, vlen);
	}
	return 0;
}

void load_configure()
{
	iniconfig_load("config.ini", argument_parse, NULL);//加载配置文件
	config_print();
}


