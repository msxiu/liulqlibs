/*
 * examples.h
 *
 *  Created on: 2016年3月11日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_EXAMPLES_EXAMPLES_H_
#define LIULQNET_TCPCONVERGE_EXAMPLES_EXAMPLES_H_

/**pcap文件加载处理
 *@parameter argc:地址个数
 *@parameter argv:地址数组
 *@parameter callback:回调函数
 */
int pcapfile_handler(int argc, char* argv[], void (*callbak)(void* pkt, unsigned int len));



#endif /* LIULQNET_TCPCONVERGE_EXAMPLES_EXAMPLES_H_ */
