/*
 * logic_cachefile.c
 *
 *  Created on: 2016年3月2日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "liulqdebug.h"
#include "local.h"


extern tcpflow_t tcpflow;
extern int pkt_index;
//**************************************************************************************************
//定义回调函数变量
static void (*pcapfile_callback)(void* pkt, unsigned int len);

/**不带五元组的数据流处理
 * @parameter addr:文件地址
 */
void pcapfile_handler_pcap(const char* addr)
{
	if(!chars_is_empty(addr)) {
		pkt_index = 0;
		pcapfile_reader(addr, pcapfile_callback);
		GDB_DEBUGS("pcap:%s\n", addr);
		tcpflow_sow(&tcpflow);
	}
}

/** 批量文件数据处理,文件一行是一个文件数据
 *@parameter addr:文件地址
 */
static int pcapfile_handler_list(const char* addr)
{
	printf("pcapfile_handler_list:%s;\n", addr);
	return file_linecallback(addr, pcapfile_handler_pcap);
}

/**pcap文件加载处理
 *@parameter argc:地址个数
 *@parameter argv:地址数组
 *@parameter callback:回调函数
 */
int pcapfile_handler(int argc, char* argv[], void (*callbak)(void* pkt, unsigned int len))
{
	int ret = 0, i;
	pcapfile_callback = callbak;
	switch(argc) {
	case 1://默认处理
		//pcapfile_handler_pcap("./pcap_data.pcap");
		pcapfile_handler_list("./index.list");
		break;
	case 2:
		if(chars_end_with_ignore(argv[1], ".list")) {
			pcapfile_handler_list(argv[1]);//列表文件处理
		} else {
			pcapfile_handler_pcap(argv[1]);//单个文件处理
		}
		break;
	default: {//多文件处理
			for(i=1;i<argc;i++) {
				pcapfile_handler_pcap(argv[i]);
			}
		}
		break;
	}
	return ret;
}


