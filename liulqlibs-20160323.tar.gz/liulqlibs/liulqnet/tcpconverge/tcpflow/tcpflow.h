/*
 * tcpflow.h
 *
 *  Created on: 2016年3月9日
 *      Author: root
 */

#ifndef LIULQNET_LIULQFLOW_TCPFLOW_H_
#define LIULQNET_LIULQFLOW_TCPFLOW_H_
#include <netinet/ip.h>
#include <netinet/tcp.h>

#include "liulqdebug.h"
#include "dbarea.h"
#include "liulqtcpconverge.h"
//物理包头长度
#define LEN_ETHER_HEADER	14


#ifdef DEBUG_TCPFLOW

#define TCP_DEBUG(format, args...) {\
		printf("%s:%d ", __FILE__, __LINE__);\
		printf(format, ##args);\
}
#define TCP_MESSAGE(format, args...) {\
		printf(format, ##args);\
}

extern int pkt_index;
#define tcp_packet_msg(pkt, format, args...)		(printf("%s:%d %d ", __FILE__, __LINE__, pkt_index), printf(format, ##args), tcp_packet_printf(pkt))
static inline void tcp_packet_printf(void* pkt)
{
	struct ip* iph =(struct ip*)(((char*)pkt) + LEN_ETHER_HEADER);
	struct tcphdr* tcph = (struct tcphdr*)(((char*)pkt) + LEN_ETHER_HEADER + (4 * iph->ip_hl));
	uint32_t sip= ntohl(iph->ip_src.s_addr), dip= ntohl(iph->ip_dst.s_addr);
	uint16_t sport = ntohs(tcph->source),dport = ntohs(tcph->dest);
	uint32_t iplen = ntohs(iph->ip_len);
	uint32_t datalen = (iplen - (4* iph->ip_hl) - (4*tcph->th_off ));

	//printf("%s:%d %d pkt(" FMT_IPADDR ":%d=>" FMT_IPADDR ":%d)%u flags:%u[", fname, nln, pkt_index,  TO_IPADDR(sip), sport, TO_IPADDR(dip), dport, datalen, tcph->th_flags);
	printf(" (" FMT_IPADDR ":%d=>" FMT_IPADDR ":%d),datalen:%u flags:%u[",  TO_IPADDR(sip), sport, TO_IPADDR(dip), dport, datalen, tcph->th_flags);
	if (tcph->th_flags & TH_SYN) printf(" SYN");
	if (tcph->th_flags & TH_ACK) printf(" ACK");
	if (tcph->th_flags & TH_RST) printf("RST");
	printf("]ack:%u,seq:%u,win:%u\n", ntohl(tcph->th_ack), ntohl(tcph->th_seq), ntohs(tcph->th_win));
}

#else

#define TCP_DEBUG(format, args...)  {}while(0)
#define TCP_MESSAGE(format, args...)  {}while(0)
#define tcp_packet_msg(pkt, format, args...)	 	{}while(0)

#endif


//TCP流汇聚哈希结构体
typedef struct {
	packetjack_t ipmin;//小IP
	packetjack_t ipmax;//大IP
} tcpflowhash_t;

//******************************************************************************
extern mapbuffer_t* tcppagemem_alloc(unsigned int psize);//内存池的页内存申请
extern void tcppagemem_free(void* addr);//内存池的页内存释放
//******************************************************************************
//TCP流汇聚内存池对象
typedef struct {
	char fclient;//是否为客户端,用于上层保存数据状态
	uint32_t size_max;//当前最后大小
	uint32_t size_last;//客户端转换前的最后大小

	dbarea_t area;//数据区域记录
	mempagepool_t pagepool;//内存池
}memtcpflow_t;


/**申请TCP流汇聚内存对象
 *@parameter page_alloc:页内存申请函数
 *@parameter page_free:页内存释放函数
 */
extern memtcpflow_t* memtcpflow_alloc(pagemem_alloc page_alloc, pagemem_free page_free, unsigned int pgsize);
/**销毁TCP流汇聚内存对象
 *@parameter o:TCP流汇聚内存对象
 */
extern void memtcpflow_destory(memtcpflow_t* o);
/**向TCP流汇聚内存对象写入数据
 *@parameter o:TCP流汇聚内存对象
 *@parameter offset:写入位置
 *@parameter data:写入数据
 *@parameter len:数据长度
 */
extern int memtcpflow_write(memtcpflow_t* o, char fclient, uint32_t offset, void* data, uint32_t len);
/**判断TCP流汇聚是否完整
 *@parameter o:TCP流汇聚内存对象
 */
extern int memtcpflow_complete(memtcpflow_t* o);

#endif /* LIULQNET_LIULQFLOW_TCPFLOW_H_ */
