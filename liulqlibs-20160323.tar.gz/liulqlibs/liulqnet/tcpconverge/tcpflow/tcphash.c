/*
 * iphash.c
 *
 *  Created on: 2016年3月8日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>

#include "local.h"


//*******************************************************
static int hashmap_tcpflow_compare(const void* a, const void* b)//
{
#define TCPJACK_COMP(a,b)	((a.ip == b.ip) && (a.port == b.port))
	tcpflowhash_t* ip1 = (tcpflowhash_t*)a, * ip2 = (tcpflowhash_t*)b;
	return (TCPJACK_COMP(ip1->ipmin, ip2->ipmin) && TCPJACK_COMP(ip1->ipmax, ip2->ipmax));
}
static void hashmap_tcpflow_bind(hashelement_t* o,  const void* key)
{
	size_t mln = sizeof(tcpflowhash_t);
	if(!o->key) o->key = malloc(mln);
	memcpy(o->key, key, mln);
}
static uint16_t hashmap_tcpflow_key(const void* key, uint32_t maxhash)
{
    uint32_t hash = 0;
    tcpflowhash_t ap =  *((tcpflowhash_t*)key);
    hash = ((ap.ipmin.ip>>16) & 0xFFFF) + (ap.ipmin.ip & 0xFFFF) + ((ap.ipmax.ip>>16) & 0xFFFF) + (ap.ipmax.ip & 0xFFFF) + ap.ipmin.port + ap.ipmax.port;
	while(hash >= maxhash) {
		hash = (hash / maxhash) + (hash % maxhash);
	}
    return hash;
}

//****************************************************************************
hashmap_t* hashmap_tcpflow_create(int size) //创建存储汇聚流需要的哈希table
{
	return hashmap_create(size, &hashmap_tcpflow_compare, &hashmap_tcpflow_key, &hashmap_tcpflow_bind);
}


