/*
 * memtcpflow.c
 *
 *  Created on: 2016年3月10日
 *      Author: root
 */

#include "liulqdebug.h"
#include "local.h"

/**申请TCP流汇聚内存对象
 *@parameter page_alloc:页内存申请函数
 *@parameter page_free:页内存释放函数
 */
memtcpflow_t* memtcpflow_alloc(pagemem_alloc page_alloc, pagemem_free page_free, unsigned int pgsize)
{
	memtcpflow_t* o = (memtcpflow_t*)calloc(1, sizeof(memtcpflow_t));
	mempagepool_initialize(&(o->pagepool));
	o->pagepool.page_alloc = page_alloc;
	o->pagepool.page_free = page_free;
	o->pagepool.pagesize = pgsize;
	return o;
}

/**销毁TCP流汇聚内存对象
 *@parameter o:TCP流汇聚内存对象
 */
void memtcpflow_destory(memtcpflow_t* o)
{
	dbarea_free(&(o->area));
	mempagepool_free(&(o->pagepool));
	free(o);
}

/**向TCP流汇聚内存对象写入数据
 *@parameter o:TCP流汇聚内存对象
 *@parameter offset:写入位置
 *@parameter data:写入数据
 *@parameter len:数据长度
 */
int memtcpflow_write(memtcpflow_t* o, char fclient, uint32_t offset, void* data, uint32_t len)
{
	uint32_t loffset, lfinish;
	if(len > 0) {
		uint32_t finish = (offset + len);
		if(o->fclient != fclient) {
			o->size_last = o->size_max;
			o->fclient = fclient;
		}

		loffset= o->size_last + offset;
		lfinish = o->size_last + finish;
		if(o->size_max < lfinish) o->size_max = lfinish;
		//GDB_DEBUGS("fclient:%u,%p:{fclient:%u,last:%u,max:%u},offset:%u,finish:%u, len:%u\n", fclient, o, o->fclient, o->size_last, o->size_max, loffset, lfinish, len);
		//GDB_MSGL("\n%s", data, len);

		if(!dbarea_inareas(&(o->area), loffset, lfinish)) {
			mempagepool_write(&(o->pagepool), loffset, data, len);
			dbarea_addarea(&(o->area), loffset, lfinish);
		}
	}
	return memtcpflow_complete(o);
}
/**读取后重置
 *@parameter o:TCP流汇聚内存对象
 *@parameter buffer:数据缓存
 */
int memtcpflow_readreset(memtcpflow_t* o, void** buffer)
{
	int pos = 0, mlen = o->pagepool.bytemax;
	*buffer = calloc(1, mlen + 10);
	if(NULL != *buffer) {
		pos = mempagepool_readreset(&(o->pagepool), *buffer, mlen);
		o->size_last = 0;
		o->size_max = 0;
		mempagepool_reset(&(o->pagepool));
		dbarea_free(&(o->area));
	}
	return pos;
}
void memtcpflow_reset(memtcpflow_t* o)
{
	o->size_last = 0;
	o->size_max = 0;
	//GDB_DEBUGS("%p:{fclient:%u,last:%u,max:%u}\n\n", o, o->fclient, o->size_last, o->size_max);
	mempagepool_reset(&(o->pagepool));
	dbarea_free(&(o->area));
}
/**判断TCP流汇聚是否完整
 *@parameter o:TCP流汇聚内存对象
 */
int memtcpflow_complete(memtcpflow_t* o)
{
	return dbarea_hasfinish(&(o->area));
	//return (o->pagepool.bytemax == o->area.finish && dbarea_hasfinish(&(o->area)));
}
