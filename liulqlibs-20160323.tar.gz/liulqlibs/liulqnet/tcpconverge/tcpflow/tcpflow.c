/*
 * tcpflow.c
 *
 *  Created on: 2016年3月9日
 *      Author: root
 */
#include "tcpflow_funcs.h"

#define FIN_SENT		120
#define FIN_CONFIRMED	121

/**添加TCP流汇聚处理初始化
 *@parameter o:对象
 *@parameter mx:最大hash数
 */
int tcpflow_initialize(tcpflow_t* o, int mx, tcpflow_execute process_stream, tcpflow_writepkt process_pkt, tcpflow_execute process_recover)
{
	o->map = (hashmap_t*)hashmap_tcpflow_create(mx);
	o->handle_packet = process_pkt;
	o->handle_stream = process_stream;
	o->handle_recover = process_recover;
	return 0;
}

/**TCP流汇聚处理过程显示
 *@parameter o:对象
 */
void tcpflow_sow(tcpflow_t* o)
{
	printf("hashsize:%u\n", o->map->count);
}
/**会话回收
 *@parameter o:对象
 *@parameter thdr:会话头
 *@parameter item:会话对象
 */
static inline void tcpflow_recover(tcpflow_t* o, tcpflowhash_t* thdr, tcpsession_t* item)
{
	o->handle_recover(item);
	hashmap_delitem(o->map, thdr);
}
/**添加数据包
 *@parameter o:对象
 *@parameter packet:数据包
 *@parameter len:数据包长度
 */
int tcpflow_addpacket(tcpflow_t* o, void* pkt, unsigned int skblen)
{
#define EXP_SEQ (snd->first_data_seq + rcv->count + rcv->urg_count)
	int iplen, datalen, onclient, cur_seq;//IP包长度
	uint32_t tmp_ts;
	struct ip* iph =(struct ip*)(((char*)pkt) + LEN_ETHER_HEADER);
	struct tcphdr* tcph = (struct tcphdr*)(((char*)pkt) + LEN_ETHER_HEADER + (4 * iph->ip_hl));
	tcpsession_t* item;//TCP流汇聚实体
	tcpflowhalf_t *rcv, *snd;
	tcpflowhash_t thdr;
	uint32_t sip= ntohl(iph->ip_src.s_addr), dip= ntohl(iph->ip_dst.s_addr);
	iplen = ntohs(iph->ip_len);

	//IP包长度小于IP头+TCP头长度,表示无效数据
	if((unsigned)iplen < (4 * iph->ip_hl + sizeof(struct tcphdr))) {
		tcp_packet_msg(pkt, " invalid ip packet(length:%d) ", iplen);
		return 0;
	}
	if((datalen = (iplen - (4* iph->ip_hl) - (4*tcph->th_off ))) < 0) {//计算TCP数据长度
		tcp_packet_msg(pkt, " invalid tcp packet(length:%d) ", datalen);
		return 0;
	}
	if((iph->ip_src.s_addr | iph->ip_dst.s_addr) == 0) {//IP无效
		tcp_packet_msg(pkt, "invalid ip address");
		return 0;
	}

	make_tcp_hashkey(&thdr, sip, ntohs(tcph->th_sport), dip, ntohs(tcph->th_dport));
	item = hashmap_find(o->map, &thdr);
	//第一次握手
	if(NULL == item) {
		if((tcph->th_flags & TH_SYN) && !(tcph->th_flags & TH_ACK) && !(tcph->th_flags & TH_RST)) {
			item = tcpsyn_1(pkt);
			hashmap_addpointer(o->map, &thdr, item);
		} else{
			tcp_packet_msg(pkt, "not match tcp session ");
		}
		return 0;
	}
	onclient = ((item->hdr.src.ip == sip) && (item->hdr.dst.ip == dip));//计算是否为客户端
	snd = (onclient ? &item->client : &item->server);
	rcv = (onclient ? &item->server : &item->client);

	//第二词握手
	if(tcph->th_flags & TH_SYN) {
		if(onclient || item->client.state != TCP_SYN_SENT || item->server.state != TCP_CLOSE || !(tcph->th_flags & TH_ACK)) {
			tcp_packet_msg(pkt, "client or server state error ");
			return 0;
		}
		if(item->client.seq != ntohl(tcph->th_ack)) {
			tcp_packet_msg(pkt, "seq error  client:%u,th_ack:%u", item->client.seq, ntohl(tcph->th_ack));
			return 0;
		}
		tcpsyn_2(item, tcph);
		return 0;
	}
	cur_seq= ntohl(tcph->th_seq);//提取当前序列号

	//非窗口内数据,忽略
#define HALF_WIN(o)		(o->ack_seq + o->window*o->wscale)

	if((datalen > 0) && (cur_seq < (rcv->ack_seq + rcv->window))) {
		TCP_DEBUG("%d=>not in window seq:%u, datalen:%u, rcv->ack_seq:%u,window:%u\n", pkt_index, cur_seq, datalen, rcv->ack_seq, rcv->window);
		//return 0;
	}
//	if(!(!datalen && cur_seq == rcv->ack_seq) && (THAN_GREAT(cur_seq, HALF_WIN(rcv)) || THAN_LESS(cur_seq + datalen, rcv->ack_seq))) {
//		TCP_DEBUG("%d=>not in window seq:%u >= rcv:%u,datalen:%u,rcv->ack_seq:%u,(%d || %d)\n", pkt_index, cur_seq, HALF_WIN(rcv), datalen, rcv->ack_seq,
//				THAN_LESS(cur_seq, rcv->ack_seq + rcv->window*rcv->wscale), THAN_LESS(cur_seq + datalen, rcv->ack_seq));
//		//tcp_packet_msg(pkt);
//		return 0;
//	}
	if(tcph->th_flags & TH_RST) {//TCP重置
		tcp_packet_msg(pkt, "tcp reset");
		return 0;
	}
	if(rcv->ts_on && get_ts(tcph, &tmp_ts) && THAN_LESS(tmp_ts, snd->curr_ts)) {
		tcp_packet_msg(pkt, "get_ts error");
		return 0;
	}
	//第三次握手
	if(tcph->th_flags & TH_ACK){
		if(onclient && item->client.state == TCP_SYN_SENT && item->server.state == TCP_SYN_RECV) {
			if(ntohl(tcph->th_ack) == item->server.seq) {
				tcpsyn_3(item, tcph);
			}
			return 0;
		}
	}

	//挥手过程
	if(tcph->th_flags & TH_ACK) {
		handle_ack(snd, ntohl(tcph->th_ack));
		if((tcph->th_flags & TH_FIN)){
			if((item->validcount > 0)) {
				TCP_DEBUG("%d=>tcpfin handle ,flags:%u, rcv->state:%d,snd->state:%d\n", pkt_index, tcph->th_flags, rcv->state, snd->state);
				o->handle_stream(item);
				tcpflow_recover(o, &thdr, item);
			} else {
				tcp_packet_msg(pkt, "repeat finish flags, rcv->state:%d,snd->state:%d",  rcv->state, snd->state);
			}
			return 0;
		}
	}

	//上次清空了序列号,此时更新
	if(0 == snd->first_data_seq) {
		snd->first_data_seq = cur_seq;
	}

	if(datalen + (tcph->th_flags & TH_FIN) > 0) {
		char* data = ((char*)tcph) + (4 *tcph->th_off);
		int offset;
		if(cur_seq >= snd->first_data_seq) {
			offset =cur_seq - snd->first_data_seq;
		}else  {//补以前数据包
			//offset = snd->first_data_seq - (snd->first_data_seq - cur_seq);
			TCP_DEBUG("<0 data %p:(offset:%d,window:%u,cwin:%u,dlen:%u)\n", item, offset, rcv->window, (cur_seq - rcv->ack_seq), datalen);
			return 0;
		}
		if(offset > 15000000 || offset < 0) {
			TCP_DEBUG(">max data %p:(offset:%d,window:%u,cwin:%u,dlen:%u)\n", item, offset, rcv->window, (cur_seq - rcv->ack_seq), datalen);
			return 0;
		}
		TCP_DEBUG("%d=>tcp data segment, fclient:%u ,offset:%u(%u-%u), length:%u\n", pkt_index, onclient, offset, cur_seq, snd->first_data_seq, datalen);
		//紧急数据尚未处理
		if(THAN_GREAT(cur_seq, EXP_SEQ)) {//非重复数据
			if(THAN_GREAT(cur_seq + datalen + (tcph->th_flags & TH_FIN), EXP_SEQ)) {
				get_ts(tcph, &snd->curr_ts);
				item->validcount += datalen;
				snd->count += datalen;
				if(o->handle_packet(item, onclient, offset, data, datalen)) {
					rcv->first_data_seq = 0;
				}
			}
		} else {
			item->validcount += datalen;
			snd->count += datalen;
			if(o->handle_packet(item, onclient, offset, data, datalen)) {
				rcv->first_data_seq = 0;
			}
		}
	} else {
		tcp_packet_msg(pkt, "invalid packet ");
	}
	snd->window = ntohs(tcph->th_win);
	return 1;
}


