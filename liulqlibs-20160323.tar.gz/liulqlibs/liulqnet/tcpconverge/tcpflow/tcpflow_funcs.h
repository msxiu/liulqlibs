/*
 * tcpflow_funcs.h
 *
 *  Created on: 2016年3月10日
 *      Author: root
 */

#ifndef LIULQNET_TCPCONVERGE_TCPFLOW_TCPFLOW_FUNCS_H_
#define LIULQNET_TCPCONVERGE_TCPFLOW_TCPFLOW_FUNCS_H_
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include "liulqdebug.h"

#include "local.h"


//****************************************************************************
/**生成TCP会话的哈希KEY
 *@parameter thdr:哈希KEY结构体对象
 *@parameter sip:原IP地址
 *@parameter sport:原端口
 *@parameter dip:目的IP
 *@parameter dport:目的端口
 */
static inline void make_tcp_hashkey(tcpflowhash_t* thdr, unsigned int sip, unsigned short sport, unsigned int dip, unsigned short dport)
{
	if((sip + sport) > (dip + dport)) {
		thdr->ipmin.ip = dip;
		thdr->ipmin.port = dport;
		thdr->ipmax.ip = sip;
		thdr->ipmax.port = sport;
	} else {
		thdr->ipmin.ip = sip;
		thdr->ipmin.port = sport;
		thdr->ipmax.ip = dip;
		thdr->ipmax.port = dport;
	}
}

static inline int get_ts(struct tcphdr *tcph, unsigned int * ts)
{
	int len = 4 * tcph->th_off;
	unsigned int tmp_ts;
	unsigned char* options = (unsigned char*) (tcph +1);
	int ind = 0, ret = 0;
	while(ind <= len - (int)sizeof(struct tcphdr) - 10) {
		switch(options[ind]) {
		case 0: return ret;//TCPOPT_EOL
		case 1: ind++;continue;//TCPOPT_NOP
		case 8:
			memcpy((char*)&tmp_ts, options + ind + 2, 4);
			*ts = ntohl(tmp_ts);
			ret = 1;
			//no break, intentionally
		default:
			if(options[ind+1] < 2) return ret;
			ind += options[ind +1];
		}
	}
	return ret;
}

static inline int get_wscale(struct tcphdr* tcph, unsigned int *ws)
{
	int len = 4 * tcph->th_off;
	unsigned int tmp_ws;
	unsigned char* options = (unsigned char*) (tcph +1);
	int ind = 0, ret = 0;
	while(ind <= len - (int)sizeof(struct tcphdr) - 10) {
		switch(options[ind]) {
		case 0: return ret;//TCPOPT_EOL
		case 1: ind++;continue;//TCPOPT_NOP
		case 3:
			tmp_ws = options[ind + 2];
			if(tmp_ws > 14) tmp_ws = 14;
			*ws = (1 << tmp_ws);
			ret = 1;
			//no break, intentionally
		default:
			if(options[ind+1] < 2) return ret;
			ind += options[ind +1];
		}
	}
	return ret;
}

/**TCP通信的第一次握手处理
 *@parameter pkt:数据包
 */
static inline tcpsession_t* tcpsyn_1(void* pkt)
{
	struct ip* iph =(struct ip*)(((char*)pkt) + LEN_ETHER_HEADER);
	struct tcphdr* tcph = (struct tcphdr*)(((char*)pkt) + LEN_ETHER_HEADER + (4 * iph->ip_hl));
	tcpsession_t*item = (tcpsession_t*)calloc(1, sizeof(tcpsession_t));

	memcpy(item->hdr.dmac, pkt, 6);
	memcpy(item->hdr.smac, pkt+6, 6);
	item->hdr.startrawtime=time(NULL);
	item->hdr.src.ip = ntohl(iph->ip_src.s_addr);
	item->hdr.src.port = ntohs(tcph->source);
	item->hdr.dst.ip = ntohl(iph->ip_dst.s_addr);
	item->hdr.dst.port = ntohs(tcph->dest);
	item->hdr.total_recv = 0;
	item->hdr.total_sent = 0;

	item->client.state = TCP_SYN_SENT;
	item->client.seq = ntohl(tcph->th_seq) + 1;//ntohl(tcph->ack_seq) +1;
	item->client.first_data_seq = item->client.seq;
	item->client.window = ntohs(tcph->th_win);
	item->client.ts_on = (char)get_ts(tcph, &item->client.curr_ts);
	item->client.wscale_on = get_wscale(tcph, &item->client.wscale);
	item->server.state = TCP_CLOSE;

	//tcp_packet_msg(pkt);
	TCP_DEBUG("%d: src:{" FMT_IPADDR ":%u},dst:{" FMT_IPADDR ":%u},ack:%u,seq:%u,ack_seq:%u,window:%u\n",pkt_index,
			TO_IPADDR(item->hdr.src.ip), item->hdr.src.port, TO_IPADDR(item->hdr.dst.ip), item->hdr.dst.port, ntohl(tcph->ack), ntohl(tcph->seq), item->client.seq, item->client.window);
	return item;
}

/**TCP通信的第二次握手处理
 *@parameter item:TCP会话对象
 *@parameter tcph:TCP包头
 */
static inline void tcpsyn_2(tcpsession_t*item, struct tcphdr* tcph)
{
	item->server.state = TCP_SYN_RECV;
	item->server.seq = ntohl(tcph->th_seq) + 1;
	item->server.first_data_seq = item->server.seq;
	item->server.ack_seq = ntohl(tcph->th_ack);
	item->server.window = ntohs(tcph->th_win);
	if(item->client.ts_on) {
		item->server.ts_on = get_ts(tcph, &item->server.curr_ts);
		if(!item->server.ts_on) {
			item->client.ts_on = 0;
		}
	} else {
		item->server.ts_on = 0;
	}
	if(item->client.wscale_on) {
		item->server.wscale_on = get_wscale(tcph, &item->server.wscale);
		if(!item->server.wscale_on) {
			item->client.wscale_on = 0;
			item->client.wscale = 1;
			item->server.wscale = 1;
		}
	} else {
		item->server.wscale_on = 0;
		item->server.wscale = 1;
	}
	TCP_DEBUG("%d  svr_seq:%u,svr_ack:%u,svr_win:%u,svr_ts:%u,svr_wscale:%u\n", pkt_index,item->server.seq, item->server.ack_seq, item->server.window, item->server.curr_ts, item->server.wscale);
}

/**TCP通信的第三次握手处理
 *@parameter item:TCP会话对象
 *@parameter tcph:TCP包头
 */
static inline void tcpsyn_3(tcpsession_t*item, struct tcphdr* tcph)
{
	struct proc_node *i;
	item->client.state = TCP_ESTABLISHED;
	item->client.ack_seq = ntohl(tcph->th_ack);
	item->server.state = TCP_ESTABLISHED;
	TCP_DEBUG("%d  ack_seq:%u,client:%u,server:%u\n", pkt_index, item->client.ack_seq, item->client.state, item->server.state);
}

extern int pkt_index;
/**更新确认序列号
 *@parameter snd:tcpflowhalf_t对象
 *@parameter acknum:确认序号
 */
static void handle_ack(tcpflowhalf_t*snd, uint32_t acknum)
{
	if((acknum - snd->ack_seq) > 0) {
		//printf("handle_ack=> %d  %p:%u\n", pkt_index, snd, acknum);
		snd->ack_seq = acknum;
	}
}

#endif /* LIULQNET_TCPCONVERGE_TCPFLOW_TCPFLOW_FUNCS_H_ */
