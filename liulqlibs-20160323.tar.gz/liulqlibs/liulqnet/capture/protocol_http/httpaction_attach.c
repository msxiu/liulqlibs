/*
 * httpaction_attach.c
 *
 *  Created on: 2016年2月2日
 *      Author: root
 */
#include <pthread.h>

#include "../../../incs/httpaction-.h"
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"
#include "liulqnet.h"

#define ATTACH_BIND(o, att) {\
	vdata_t v1;\
	SET_BUFFER((att)->m_method, o->http->data, o->http->method);\
	if(httpbuffer_headkey(o->http, "host:", &v1)) {\
		SET_BUFFER((att)->m_domain, v1.addr, v1.length);\
	}\
	SET_BUFFER((att)->m_uri, (o->http->data + o->http->method + 1), (o->http->url - o->http->method - 1));\
	http_cookie_each(o, cookie_parameters, att);\
	http_urlquery_each(o, urlquery_parameters, att);\
}while(0)

#define ATTACH_APPEND(o, att) {\
	ATTACH_BIND(o, att);\
	list_add_tail(&((att)->list), &http_attachs);\
}while(0)

static LIST_HEADM(http_attachs);
static pthread_mutex_t attach_lock = PTHREAD_MUTEX_INITIALIZER;

static int formdata_fileparameters(void* par, const char* key, const char* filename, const char* filetype, const char* val, int vlen)//文件上传
{
	httpattach_t* attach = (httpattach_t*)par;
	httpattachrule_t* rule = attach->rules;
	if(0 == strcasecmp(key, rule->data)) {
		strcpy(attach->m_name, filename);
		strcpy(attach->m_type, filetype);
		attach->m_time = time(NULL);
		attach->m_size = vlen;
		attach->data = calloc(1, vlen+10);
		memcpy(attach->data, val, vlen);
		return 1;
	}
	if(0 == strcasecmp(key, rule->sid)) {
		SET_BUFFER(attach->m_sid, val, vlen);//处理附件关联
		return 0;
	}
	return 0;
}
static int urlquery_parameters(void* par, const char* key, const char* val, int vlen)//查询参数
{
	httpattach_t* attach = (httpattach_t*)par;
	httpattachrule_t* rule = attach->rules;
	if(0 == strcasecmp(key, rule->sid)) {
		SET_BUFFER(attach->m_sid, val, vlen);//处理附件关联
		return 0;
	}
	return 0;
}
static int cookie_parameters(void* par, const char* key, const char* val, int vlen)//cookie
{
	httpattach_t* attach = (httpattach_t*)par;
	httpattachrule_t* rule = attach->rules;
	if(0 == strcasecmp(key, rule->cook)) {
		SET_BUFFER(attach->m_sid, val, vlen);//处理附件关联
		return 0;
	}
	return 0;
}

void http_attach_destory(httpattach_t* o) //销毁对象
{
	if(o) {
		if(o->data) {
			free(o->data);
			o->data = NULL;
		}
		if(o->part) {
			free(o->part);
			o->part = NULL;
		}
		free(o);
	}
}

static httpattach_t* http_attach_findpart(httpattach_t* o, httpactionrule_t* rule)//从链表中查找分包数据
{
	httpattach_t *result=NULL, *pos, *n;
	list_for_each_entry_safe(pos, n, &http_attachs, list) {
		if(httprules_contains(rule, pos->m_method, pos->m_domain, pos->m_uri) && 0 == strcasecmp(o->m_sid, pos->m_sid) && NULL != pos->part && 0 == strcasecmp(pos->part->name, o->part->name)) {
			result = pos;
			break;
		}
	}
	return result;
}
httpattach_t* http_attach_partdata(httpdescribe_t* o)//分包附件传送
{
	httpattach_t* attach, item;
	httpattachrule_t* rule =  o->rule->rulenode;
	vdata_t v;
	httattachpart_t* part = calloc(1, sizeof(httattachpart_t));
	httpbuffer_t *http =  o->http;

	attach->rules = rule;
	if(httpbuffer_headkey(http, rule->name, &v)) {
		SET_BUFFER(part->name, v.addr, v.length);//附件名
	}
	if(httpbuffer_headkey(http, rule->offset, &v)) {
		PARSE_INT_OF(part->offset, v.addr, v.length);//偏移
	}
	if(httpbuffer_headkey(http, rule->aid, &v)) {
		PARSE_INT_OF(part->aid, v.addr, v.length);//非首包
	}
	if(httpbuffer_headkey(http, rule->size, &v)) {
		PARSE_INT_OF(part->size, v.addr, v.length);//总大小
	}
	if(httpbuffer_headkey(http, rule->length, &v)) {
		PARSE_INT_OF(part->length, v.addr, v.length);//当前数据大小
	}

	ATTACH_BIND(o, &item);
	attach = http_attach_findpart(&item, o->rule);
	if(NULL == attach) {
		attach = calloc(1, sizeof(httpattach_t));
		attach->data = calloc(1, part->size);
		attach->part = part;
		pthread_mutex_lock(&attach_lock);
		ATTACH_APPEND(o, attach);
		pthread_mutex_unlock(&attach_lock);
	}
	memcpy(attach->data+part->offset, http->data + http->header, part->length);
	attach->part->length += part->length;
	GDB_DEBUGS("http_attach_partdata{sid:'%s',name:'%s',type:'%s'}\n", attach->m_sid, attach->m_name, attach->m_type);
	return ((attach->part->length < attach->part->size) ? NULL : attach);
}

httpattach_t* http_attach_upfile(httpdescribe_t* o) //处理单个文件上传
{
	httpattach_t* attach;
	httpattachrule_t* rule =  o->rule->rulenode;
	vdata_t v;

	if(httpbuffer_headkey(o->http, rule->name, &v)) {
		SET_BUFFER(attach->m_name, v.addr, v.length);
	}
	if(httpbuffer_headkey(o->http, "content-type:", &v)) {
		SET_BUFFER(attach->m_type, v.addr, v.length);
	}
	if(httpbuffer_headkey(o->http, "content-type:", &v)) {
		attach->m_time = time(NULL);
		PARSE_INT_OF(attach->m_size, v.addr, v.length);
		attach->data = calloc(1, attach->m_size+10);
		memcpy(attach->data, o->http->data + o->http->header, attach->m_size);
		ATTACH_BIND(o, attach);
		GDB_DEBUGS("http_attach_upfile{sid:'%s',name:'%s',type:'%s'}\n", attach->m_sid, attach->m_name, attach->m_type);
		return attach;
	}
	return NULL;
}

httpattach_t* http_attach_formdata(httpdescribe_t* o) //提取formdata中文件数据
{
	httpattachrule_t* rule =  o->rule->rulenode;
	httpattach_t* attach = calloc(1, sizeof(httpattach_t));
	attach->rules = rule;
	if(http_formfiledata(o, formdata_fileparameters, attach) > 0) {
		ATTACH_BIND(o, attach);
		GDB_DEBUGS("http_attach_formdata{sid:'%s',name:'%s',type:'%s'}\n", attach->m_sid, attach->m_name, attach->m_type);
	} else {
		free(attach);
		attach = NULL;
	}
	return attach;
}



int http_attach_upload(httpdescribe_t* o)//处理附件上传
{
	httpattach_t* attach;
	httpattachrule_t* rule =  o->rule->rulenode;
	httpbuffer_t *http =  o->http;
	if(0 == strcasecmp(o->ctype->contenttype, "multipart/form-data")) {
		attach = http_attach_formdata(o);
		if(NULL != attach) {
			pthread_mutex_lock(&attach_lock);
			list_add_tail(&((attach)->list), &http_attachs);
			pthread_mutex_unlock(&attach_lock);
		}
	} else if(!chars_is_empty(rule->aid)) {//分包处理
		attach = http_attach_partdata(o);
	} else {
		attach = http_attach_upfile(o);
		pthread_mutex_lock(&attach_lock);
		list_add_tail(&((attach)->list), &http_attachs);
		pthread_mutex_unlock(&attach_lock);
	}
	return (NULL != attach);
}

int http_attach_moveto(httpattachlist_t * rules,  const char* sid, struct list_head* list)//将符合的附件移动到list中
{
	int result = 0;
	httpattach_t *pos, *n;
	while(rules) {
		list_for_each_entry_safe(pos, n, &http_attachs, list) {
			printf("rule:{domain:'%s',url:'%s'},pos:{domain:'%s',url:'%s',sid:'%s'}\n", rules->node->domain, rules->node->url, pos->m_domain, pos->m_uri, pos->m_sid);
			if(httprules_contains(rules->node, pos->m_method, pos->m_domain, pos->m_uri) && 0 == strcasecmp(sid, pos->m_sid)) {
				pthread_mutex_lock(&attach_lock);
				list_del(&(pos->list));//从原链表中删除
				list_add_tail(&(pos->list), list);//挂到list链表
				pthread_mutex_unlock(&attach_lock);
				result++;
			}
		}
		rules = rules->next;
	}
	return result;
}

int http_attach_timeout(int m)//超时移除
{
	int result;
	httpattach_t *pos, *n;
	time_t tm = time(NULL) - m;
	list_for_each_entry_safe(pos, n, &http_attachs, list) {
		if(pos->m_time < tm) {//超时
			pthread_mutex_lock(&attach_lock);
			list_del(&(pos->list));//从原链表中删除
			http_attach_destory(pos);
			pthread_mutex_unlock(&attach_lock);
			result++;
		}
	}
	return result;
}
