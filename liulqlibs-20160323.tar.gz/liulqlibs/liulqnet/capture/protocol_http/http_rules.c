/*
 * requestconf.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include <stdio.h>
#include <stdint.h>

#include "../../../incs/httpaction-.h"
#include "liulqcore.h"
#include "liulqnet.h"



inline char httprules_contains(httpactionrule_t* rule, const char* method, const char*domain, const char*url)//HTTP请求规则包含
{
	int allow_next = 0;
	if(chars_equals_ignore(domain, rule->domain)) {//域名比较
		switch(rule->method) {//比较请求方式
		case HTTP_METHD_ANY: allow_next = (char)1; break;
		case HTTP_METHD_GET: allow_next = (0 == strcasecmp(method, "get")); break;
		case HTTP_METHD_POST: allow_next = (0 == strcasecmp(method, "post")); break;
		}
		if(allow_next) {
			allow_next = 0;
			switch(rule->urltype) {//根据不同的方式对URL比较
			case URLCOMPARE_IGNORE: allow_next = (char)1; break;
			case URLCOMPARE_CONTAIN: allow_next = (-1 != chars_indexof_ignore(url, rule->url, 0)); break;
			case URLCOMPARE_STARTWITH: allow_next =  chars_start_with_ignore(url, rule->url); break;
			case URLCOMPARE_ENDWITH: allow_next =  chars_end_with_ignore(url, rule->url); break;
			}
		}
	}
	return allow_next;
}

//httpactionrule_t* filters_httprules(httpactionrule_t * rule, httpbuffer_t* o)//过滤获得HTTP协议解析规则
//{
//	//httpactionrule_t* rule = filter_request;
//	char allow_next = 0;
//	vdata_t vh = { 0 }, vm = { .addr = (char*)o->data, .length = o->method },  vu =  { .addr = (char*)(o->data + o->method + 1), .length = (o->url - o->method - 1) };
//	int pos = 0;
//	pos = httpbuffer_headkey(o, "host:", &vh);
//	char domain[vh.length + 5], url[vu.length + 5], method[vm.length + 5];
//	if(-1 == pos) return NULL;
//	SET_BUFFER(domain, vh.addr, vh.length);
//	SET_BUFFER(url, vu.addr, vu.length);
//	SET_BUFFER(method, vm.addr, vm.length);
//
//	while(rule && rule->rule) {
//		if(httprules_contains(rule, method, domain, url)) return rule;
//		rule ++;
//	}
//	return NULL;
//}



static inline http_contenttype_fill(httpcontentype_t* v, char* addr, int start, int equals, int end)//对content-type赋值
{
	char name[64];
	int vln;
	memset(&name, 0, 64);
	while(char_is_empty(*(addr + start))) start ++;
	vln = equals - start;
	SET_BUFFER(name, addr+start, vln);
	vln = (end - (equals + 1));
	if(0 == strcasecmp(name, "charset")) {
		SET_BUFFER(v->charset, (addr + equals + 1), vln);
	} else if(0 == strcasecmp(name, "boundary")) {
		SET_BUFFER(v->boundary, (addr + equals + 1), vln);
	}
}


int http_contenttype(httpbuffer_t* o, httpcontentype_t* v)//检测HTTP内容类型;out:v 接收参数,1:success,0:fail
{
	vdata_t vt;
	unsigned int i = httpbuffer_headkey(o, "content-type:", &vt);
	int p, q;
	if(i == -1) return 0;
	memset(v, 0, sizeof(httpcontentype_t));
	i = 0;
	while(i < vt.length) {
		if(';' ==* (vt.addr + i)) break;
		i++;
	}
	SET_BUFFER(v->contenttype, vt.addr, i);
	if(i == vt.length) return 1;
	p = i;
	q = 0;
	while(i < vt.length) {
		switch(*(vt.addr + i)) {
			case '=': q = i;break;
			case ';': {
				if(q) http_contenttype_fill(v, vt.addr, p+1, q, i);
				p = i;
				q = 0;
			}
			break;
		}
		i++;
	}
	if(q && p != i) http_contenttype_fill(v, vt.addr, p+1, q, i);
	return 1;
}

char chars_part_equals(const char* p, const char* key)//key 是否为p的子选项
{
	if(!chars_is_empty(p)) {
		int  pos = 0;
		char tmp[128];
		while(*p) {
			while(p[pos] && '|' !=  p[pos]) pos++;
			if(pos) {
				SET_BUFFER(tmp, p, pos);
				if(0 == strcasecmp(key, tmp)) return 1;
			}
			pos++;
			p+=pos;
			pos = 0;
		}
	}
	return 0;
}
