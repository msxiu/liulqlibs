/*
 * http_urlencode.c
 *
 *  Created on: 2016年1月28日
 *      Author: root
 */
#include <strings.h>
#include <liulqcore.h>
#include <liulqnet.h>
#include <iconv.h>

#include "../../../incs/httpaction-.h"
#define NON_NUM		'0'

/**编码转换:从一种编码转为另一种编码
 * @from_charset 源编码方式
 * @to_charset 目标编码方式
 */
 int encoding_convert(const char *from_charset, const char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen)
 {
     iconv_t cd;
     char **pin = &inbuf;
     char **pout = &outbuf;

     cd = iconv_open(to_charset, from_charset);
     if (cd==0) return -1;
     memset(outbuf,0x00,outlen);
     if (iconv(cd, pin, &inlen, pout, &outlen)==-1)  return -1;
     iconv_close(cd);
     return 0;
 }

int http_urldecode_chars(const char *src, int sln, char *dst, int dln)//url解码字符串
 {
#define URL_DECODEA(c)  (((c)>='a' && (c)<='z')  ? (((c) - 'a') + 10) : (((c) - 'A')+10))
#define URL_DECODE(c) 	(((c)>='0' && (c)<='9') ? (c) - '0' : URL_DECODEA(c))
     int i=0, ret= 0; /* for result index */
     if ((src == NULL) || (dst == NULL) || (sln <= 0) || (dln <= 0))  return 0;
     for (i=0; (i<sln) && (ret<dln); i++)  {
         switch (src[i]) {
             case '%':
                 if (i+2 < sln) {
                	 char c1 = URL_DECODE(src[i+1]);
                	 char c2 = URL_DECODE(src[i+2]);
                	 dst[ret++] = (c1 << 4) | c2;
                	 i += 2;
                 }
                 break;
             case '+':
                 dst[ret++] = ' ';
                 break;
             default:
                 dst[ret++] = src[i];
                 break;
         }
     }
     dst[ret] = '\0';
     return ret;
 }

/**解析每个参数
 *
 */
static inline int http_urldecode_each(form_data_cbk data_cbk, void* par, const char* encoding, const char* addr, int len)
{
#define URLDECODE_ITEM() {\
	char key[128];\
	SET_BUFFER(key, addr+kps, eps - kps);\
	vln = ps - eps -1;\
	char* sval = calloc(1, vln + 10);\
	vln1 = http_urldecode_chars(addr+eps+1, vln, sval, vln);\
	if(0 != strcasecmp(encoding, "utf-8")) {\
		char* tval = calloc(1, (vln1*2) + 10);\
		encoding_convert(encoding, "utf-8", sval, vln1, tval, vln1*2);\
		if(vln1>0 && data_cbk(par, key, tval, vln1*2)) ret ++;\
		free(tval);\
	} else {\
		if(vln1>0 && data_cbk(par, key, sval, vln1)) ret ++;\
	}\
	free(sval);\
} while(0)

	int ps =0, kps = 0, eps = 0, vln, vln1, ret = 0;
	while(ps < len) {
		if('=' ==  *(addr+ps)) eps = ps;
		if('&' ==  *(addr+ps)) {
			if(eps) {
				URLDECODE_ITEM();
			}
			kps = ps + 1;
			eps = 0;
		}
		ps++;
	}
	if(eps && ps > kps) {
		URLDECODE_ITEM();
	}
	return ret;
}

int http_cookie_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par)//处理cookie字符串
{
	vdata_t vt;
	char name[128];
	if(httpbuffer_headkey(o->http, "cookie", &vt) > 0){
		int ps = 0, p1 = 0, p2=0;
		while(ps < vt.length) {
			if('=' == vt.addr[ps]) {
				p2 = ps;
			}
			if(';' == vt.addr[ps]) {
				while(!char_is_empty(vt.addr[p1]))  p1++;
				SET_BUFFER(name, vt.addr + p1, p2-p1);
				data_cbk(par, name, vt.addr + p2+1, ps-p2-1);
				p1=ps;
				p2 = 0;
			}
			ps++;
		}
		if(p2>0 && ps > p1) {
			while(!char_is_empty(vt.addr[p1]))  p1++;
			SET_BUFFER(name, vt.addr + p1, p2-p1);
			data_cbk(par, name, vt.addr + p2+1, ps-p2-1);
		}
	}
	return 0;
}


int http_urlquery_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par)//处理url query查询字符串
{
	httpbuffer_t *http = o->http;
	int ret = 0, urln = http->url - http->method -1, ps =0, kps, eps = 0;
	const char *url = http->data + http->method +1, *encoding = (chars_is_empty(o->ctype->charset) ? o->rule->charset : o->ctype->charset);
	while((' ' != *(url+ps)) && ('?' != *(url+ps))) ps++;
	if('?' == *(url+ps)) {
		ps++;
		ret += http_urldecode_each(data_cbk, par, encoding, url + ps, urln - ps);
	}
	return ret;
}

int http_postdata_each(httpdescribe_t* o, form_data_cbk data_cbk, void* par)//解析HTTP协议的url编码数据
{
	httpbuffer_t *http = o->http;
	int ret = 0, urln = http->url - http->method -1, ps =0, kps, eps = 0;
	const char *url = http->data + http->method +1, *encoding = (chars_is_empty(o->ctype->charset) ? o->rule->charset : o->ctype->charset);
	if(http->body) {
		ret += http_urldecode_each(data_cbk, par, encoding, http->data + http->header, http->body);
	}
	return ret;
}
