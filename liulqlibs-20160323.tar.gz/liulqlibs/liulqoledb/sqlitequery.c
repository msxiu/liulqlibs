﻿#include <stdio.h>
#include <stdlib.h>
#include <liulqsqlite.h>
#include "liulqdebug.h"

char sqlitequery_prepare(sqlitequery_t* o, const char* sql)
{
	char buffer[o->condv + strlen(sql) + 10];
	char * item;
	int pos, ivl;
	memset(buffer,0, sizeof(buffer));
	memcpy(buffer, sql, strlen(sql));
	linked_list_reset(&(o->conds));
	while(linked_list_next(&(o->conds))) {
		item = (char*)linked_list_entry(&(o->conds));
		pos = strlen(buffer);
		strcpy(buffer+pos, (char*)item);
	}
	GDB_DEBUGS("%d:%s\nparameter count %d;\n", strlen(buffer), buffer, o->conds.length);
	int state = sqlite3_prepare(o->db, buffer, -1, &(o->stmt), 0);
	if (state != SQLITE_OK) {
		GDB_ERRORS("sqlite3_prepare state:%d,msg:'%s' error;\n", state, sqlite3_errmsg(o->db));
		return 0;
	}
	if (!o->stmt)  return 0;

	pos=1;
	linked_list_reset(&(o->paras));
	while(linked_list_next(&(o->paras))) {
		item = (char*)linked_list_entry(&(o->paras));
		switch((char)item[0]) {
		case 1:
			//ivl = (int*)item+1;
			memcpy(&ivl, item+1, 4);
			GDB_DEBUGS("add parameter %d:%d;\n", pos, ivl);
			if (sqlite3_bind_int(o->stmt, pos, ivl) != SQLITE_OK) {
				return 0;
			}
			break;
		case 2:
			GDB_DEBUGS("add parameter %d:'%s';\n", pos, (char*)item+1);
			if (sqlite3_bind_text (o->stmt, pos, item+1, strlen(item+1), SQLITE_TRANSIENT) != SQLITE_OK) {
				return 0;
			}
			break;
		}
		pos ++;
	}
	return 1;
}
char sqlitequery_finalize(sqlitequery_t* o)
{
	int rv = 0;
	if(NULL != o->stmt) {
		rv = sqlite3_finalize(o->stmt);
		//sqlite3_reset(o->stmt);
		if( rv != SQLITE_OK){
			GDB_DEBUGS("sqlite3_finalize(%d): %s\n", rv, sqlite3_errmsg(o->db));
			return 0;
		}
		o->stmt = NULL;
		return 1;
	}
	return 0;
}
void sqlitequery_destory(sqlitequery_t* o)
{

	dbuffer_destory(&(o->conds));
	linked_list_destory(&(o->paras));
	free(o);
}
int sqlitequery_condition(sqlitequery_t* o, const char* fmt,...)
{
	char sql[1024];
	int sln = 0;
	memset(sql, 0, sizeof(sql));
	if(o->conds.length > 0) {
		strcpy(sql, " AND ");
		sln = 5;
	} else {
		strcpy(sql, " WHERE ");
		sln = 7;
	}
	VARIABLE_ARGUMENT(sql, fmt, sln);
	o->condv += sln;
	char* buffer = (char*)malloc(sln + 10);
	strcpy(buffer, sql);
	return linked_list_push(&(o->conds), buffer);
}
int sqlitequery_tail(sqlitequery_t* o, const char *fmt, ...)
{
	char sql[1024];
	int sln = 0;
	memset(sql, 0, sizeof(sql));
	VARIABLE_ARGUMENT(sql, fmt, sln);
	o->condv += sln;
	char* buffer = (char*)malloc(sln + 10);
	strcpy(buffer, sql);
	return linked_list_push(&(o->conds), buffer);
}
int sqlitequery_para_integer(sqlitequery_t* o, int v)
{
	char* buffer = (char*)malloc(5);
	buffer[0] = (char)1;
	memcpy(buffer+1, &v, 4);
	return linked_list_push(&(o->paras), buffer);
}
int sqlitequery_para(sqlitequery_t* o, const char* v)
{
	int sln = strlen(v);
	char* buffer = (char*)malloc(sln + 2);
	buffer[0] = 2;
	strcpy(buffer+1, v);
	return linked_list_push(&(o->paras), buffer);
}
char sqlitequery_execute(sqlitequery_t* o, const char* fmt,...)
{
	char sql[1024];
	int sln = 0;
	memset(sql, 0, sizeof(sql));
	VARIABLE_ARGUMENT(sql, fmt, sln);

	sqlitequery_prepare(o, sql);
	int rc = sqlite3_step(o->stmt);
	if (rc == SQLITE_BUSY) return 0;
	if (rc == SQLITE_ERROR) return 0;
	if (rc == SQLITE_MISUSE) return 0;
	if (rc != SQLITE_DONE) return 0;
	sqlite3_reset(o->stmt);
	return 1;
}
int sqlitequery_recordcount(sqlitequery_t* o, const char* fmt,...)
{
	char sql[1024];
	int sln = 0, result = -1;
	memset(sql, 0, sizeof(sql));
	VARIABLE_ARGUMENT(sql, fmt, sln);

	if(!sqlitequery_prepare(o, sql)) return 0;
	int rc = sqlite3_step(stmt);
	if (rc == SQLITE_ROW){
		result = sqlitequery_columnint(o, 0);
	}
	//sqlitequery_finalize(o);
	sqlite3_reset(o->stmt);
	return result;
}
char sqlitequery_next(sqlitequery_t* o)
{
	int rc = sqlite3_step(o->stmt);
	if (rc == SQLITE_ROW) return 1;

	switch(rc) {
	case SQLITE_DONE:
		GDB_INFO("SQLITE_DONE\n");
		sqlite3_reset(o->stmt);
		break;
	case SQLITE_MISUSE:
		GDB_INFO("SQLITE_MISUSE\n");
		break;
	case SQLITE_BUSY:
		GDB_INFO("SQLITE_BUSY\n");
		break;
	case SQLITE_ERROR:
		GDB_INFO("SQLITE_ERROR\n");
		break;
	}
	return 0;
}
char sqlitequery_reset(sqlitequery_t* o)
{
	int rc = sqlite3_step(o->stmt);
	sqlite3_reset(o->stmt);
	if (rc == SQLITE_ROW) return 1;
	return 0;
}

char sqlitequery_restart(sqlitequery_t* o)
{
	sqlite3_reset(o->stmt);
	return 1;
}

int sqlitequery_vtype(sqlitequery_t* o, int i)
{
	return sqlite3_column_type(o->stmt, i);
}
int sqlitequery_vlength(sqlitequery_t* o, int i)//--获得字段长度
{
	return sqlite3_column_bytes(o->stmt, i);
}
int sqlitequery_columnint (sqlitequery_t* o, int i)
{
	return sqlite3_column_int(o->stmt, i);
}
const char *sqlitequery_columnchars (sqlitequery_t* o, int i)
{
	return (const char*)(sqlite3_column_text(o->stmt, i));
}
const void*  sqlitequery_column(sqlitequery_t* o, int i)
{
	return sqlite3_column_blob(o->stmt, i);
}
char  sqlitequery_columnhex(sqlitequery_t* o, int i, void* buffer)
{
	const char* chs = (const char*)(sqlite3_column_text(o->stmt, i));
	int result = (strlen(chs)/2);
	chars_to_hex(buffer, chs);
	return 1;
}


