﻿#include <stdio.h>
#include <stdlib.h>
#include <liulqsqlite.h>
#include "liulqdebug.h"

char sqlitedb_open(sqlitedb_t* o)
{
	int rc, dbexists = access(o->faddr, F_OK);//测试文件是否存在
	GDB_DEBUGS("database file exists %d!\n", dbexists);
	rc = sqlite3_open(o->faddr, &o->db);
	if (rc != SQLITE_OK) {
		sqlite3_close(o->db);
		return 0;
	} else if(dbexists != 0) {
		char hasok = 0;
		if(NULL != o->tables) {
			if(!(hasok = sqlitedb_execute(o, o->tables))) {
				GDB_ERRORS( "create table '%s' fail!\n", o->faddr);
			}
		}
		if(hasok && NULL != o->indexs) {
			hasok = sqlitedb_execute(o, o->indexs);
			if(!hasok) {
				GDB_ERRORS("create index '%s' fail!\n", o->faddr);
			}
		}
	}
	return 1;
}
void sqlitedb_close(sqlitedb_t* o)
{
	if(0 != o->db) {
		sqlite3_close(o->db);
		o->db=0;
	}
}

int sqlitedb_execute(sqlitedb_t* o, const char* fmt,...)
{
	char *errmsg;
	char sql[1024];
	int   ret, sln = 0;
	memset(sql, 0, sizeof(sql));
	VARIABLE_ARGUMENT(sql, fmt, sln);

	ret = sqlite3_exec(o->db, sql, 0, 0, &errmsg);
	if(ret != SQLITE_OK) {
		GDB_DEBUGS("%d:%s\n", ret, errmsg);
		return 0;
	}
	return 1;
}

const char* sqlitedb_errmsg(sqlitedb_t* o)
{
	return sqlite3_errmsg(o->db);
}
char sqlitedb_begin (sqlitedb_t* o)
{
	return sqlitedb_execute(o, "begin");
}
char sqlitedb_commit(sqlitedb_t* o)
{
	return sqlitedb_execute(o, "commit");
}
char sqlitedb_rollback(sqlitedb_t* o)
{
	return sqlitedb_execute(o, "rollback");
}

sqlitequery_t* sqlitedb_statement(sqlitedb_t* o)
{
	sqlitequery_t* stmt = malloc(sizeof(sqlitequery_t));
	stmt->db = o->db;
	dbuffer_initialize(&(stmt->conds), 10240, 512);
	linked_list_initialize(&(stmt->paras));
	return stmt;
}
