/*
 * fwritecache.c
 *
 *  Created on: 2016年2月26日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct fwritecache_struct {//--读取数据回调结构
	unsigned int length, position;
	const char* faddr;
	unsigned char buffer[];
} fwritecache_t;

/**向文件追加数据
 *@parameter addr:文件地址
 *@parameter buffer:写入缓存
 *@parameter len:写入大小
 */
int fwritecache_tofile(char const *const  addr, const void* const buffer, int len)
{
	FILE *fp;
	int rlen;
	fp = fopen(addr, "ab+");
	if(fp) {
		rlen = fwrite(buffer, 1, len, fp);
		fclose(fp);
	}
	return rlen;
}
/**申请一个fwritecache_t结构缓存区,len申请缓存区大小
 *@parameter len:申请缓存大小
 * */
fwritecache_t* fwritecache_alloc(const char* addr, unsigned int len)
{
	fwritecache_t* o = (fwritecache_t*)calloc(1, sizeof(fwritecache_t)+len);
	if(o){o->faddr = addr; o->length = len;}
	return o;
}
/**完成数据缓存,并写入文件
 *@parameter o:memorybuffer_t缓存对象
 */
void fwritecache_finished(fwritecache_t *o)
{
	if(o->position > 0) {
		fwritecache_tofile(o->faddr, o->buffer, (int)o->position);
		memset(o->buffer, 0, o->length);
		o->position = 0;
	}
}
/**向缓存区写数据
 *@parameter o:fwritecache_t缓存对象
 *@parameter  data:数据
 *@parameter  len:数据长度
 */
int fwritecache_write(fwritecache_t *o, const void* data, unsigned int len)
{
	if(len >= o->length) {
		if(o->position >0)  fwritecache_finished(o);
		fwritecache_tofile(o->faddr, data, (int)len);
	} else {
		if((o->position + len) >= o->length)  fwritecache_finished(o);
		memcpy(o->buffer + o->position, data, len);
		o->position += len;
	}
	return len;
}
/**向缓存区写字符串
 *@parameter o:fwritecache_t缓存对象
 *@parameter  data:数据
 */
int  fwritecache_writes(fwritecache_t *o, const char* data)//
{
	return fwritecache_write(o, data, strlen(data));
}
/**回收缓存区
 * @parameter o:fwritecache_t缓存对象
 * */
void fwritecache_free(fwritecache_t *o)
{
	if(NULL != o) {
		free(o);
		o=NULL;
	}
}
void fwritecache_finishedfree(fwritecache_t *o)
{
	fwritecache_finished(o);
	fwritecache_free(o);
}


