#include <liulqcore.h>

 char fcache_check_timeout(fcache_check_t* o)
 {
	if(chars_is_empty(o->addr)) return 0;
	time_t fitm =  file_last_modify(o->addr);
	return (fitm == o->ticks ? 0 : 1);
}
 char fcache_check_onyear(fcache_check_t* o)
 {
	if(chars_is_empty(o->addr)) return 0;
	time_t fitm =  file_last_modify(o->addr), nitm =get_time_t() ;
	if(fitm != o->ticks) return 0;
	int fd = time_to_integer_ymd(fitm,1)  , nd=time_to_integer_ymd(nitm, 1);
	//GDBMSGS(GDB_DEBUG, "year equals:%d=%d, sec:%d=%d;\n", fd,  nd, fitm, nitm);
	return (fd == nd ? 1 : 0);
 }
 char fcache_check_onday(fcache_check_t* o)
{
	if(chars_is_empty(o->addr)) return 0;
	time_t fitm =  file_last_modify(o->addr), nitm =get_time_t() ;
	if(fitm != o->ticks) return 0;
	int fd = time_to_integer_ymd(fitm, 7)  , nd=time_to_integer_ymd(nitm, 7);
	//GDBMSGS(GDB_DEBUG, "year equals:%d=%d, sec:%d=%d;\n", fd,  nd, fitm, nitm);
	return (fd == nd ? 1 : 0);
}
 void fcache_check_update(fcache_check_t* o)
 {
	 o->ticks = file_last_modify(o->addr);
 }


///*************************************************************************
 char fcache_initialize(fcache_t* o)
 {
	 int flen;
	 if(chars_is_empty(o->file.addr)) return 0;
	 if(!file_exists(o->file.addr)) return 0;
	 flen = file_length(o->file.addr);
	 if(o->hasvalue) {
		 free(o->buffer);
		 o->hasvalue = 0;
	 }
	 o->buffer = (char*)malloc(flen);
	 if(NULL == o->buffer) return 0;
	 if(file_read_tobuffer(o->file.addr, o->buffer) < 1) {
		 free(o->buffer);
		 o->hasvalue = 0;
		 return 0;
	 }
	 fcache_check_update(&(o->file));
	 o->hasvalue = 1;
	 return 1;
 }
 void fcache_destory(fcache_t* o)
 {
	 if(o->hasvalue) {
		 free(o->buffer);
	 }
 }
 const char* fcache_buffer(fcache_t* o)
 {
	 if(fcache_check_timeout(&(o->file)))  {
		 if(!fcache_initialize(o)) return NULL;
	 }
	 return o->buffer;
 }
 const char* fcache_buffer_day(fcache_t* o)
 {
	 if(fcache_check_onday(&(o->file)))  {
		 if(!fcache_initialize(o)) return NULL;
	 }
	 return o->buffer;
 }
 const char* fcache_buffer_year(fcache_t* o)
 {
	 if(fcache_check_onyear(&(o->file)))  {
		 if(!fcache_initialize(o)) return NULL;
	 }
	 return o->buffer;
 }
