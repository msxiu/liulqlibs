/*
 * filecache.c
 *
 *  Created on: 2016年1月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <pthread.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "list.h"


static void* filecache_nomap(void* dst, int len)
{
	return dst;
}
 void filecache_initialize(filecache_t* o, const char* fname, filecache_parse func)//初始文件缓存对象
{
	 strcpy(o->addr, fname);
	 o->parse = (NULL == func ? filecache_nomap : func);
}

 int filecache_modify(filecache_t* o)//根据修改时间缓存数据
 {
	 time_t last = file_last_modify(o->addr);
	 return (last != o->tm);
 }
 unsigned char* filecache_bymodify(filecache_t* o)//根据修改时间缓存数据
 {
	 time_t last = file_last_modify(o->addr);
	 if(last != o->tm) {
		int flen = file_length(o->addr);
		 unsigned char *buffer = calloc(1, flen + 2);
		 file_read_tobuffer(o->addr, buffer);
		 o->buffer = o->parse(buffer, flen);
		 o->tm = last;
		 free(buffer);
	 }
	 return o->buffer;
 }

 void filecache_clean(filecache_t* o)//清空缓存数据
 {
	 if(o->buffer) {
		 free(o->buffer);
	 }
 }
