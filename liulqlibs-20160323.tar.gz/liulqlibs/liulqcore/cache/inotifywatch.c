/*
 * inotifywatch.c
 *
 *  Created on: 2016年1月27日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/select.h>
#include "liulqcore.h"
#include "liulqdebug.h"

#define EVENT_NUM		12


static void inotifywatch_invoke(inotifywatch_t* o, struct inotify_event* event)
{
	inotifynode_t* item = o->nodes;
	struct timespec t;
	while(item && item->mask && item->onchange) {
		//if(0 != strcmp(event->name, item->addr)) continue;
		if(event->wd == item->wd) {
			if((event->mask & item->mask) > 0) {
				t = file_lastmodify(item->addr);
				if(item->last.tv_sec != t.tv_sec || item->last.tv_nsec != t.tv_nsec) {
					item->onchange(item, event->mask);
					item->last = t;
				}
			}
		}
		item++;
	}
}

static void* inotifywatch_loop(void* arg)
{
	int i, len, nread;
	char buf[BUFSIZ];
	struct inotify_event *event;
	inotifywatch_t* o =(inotifywatch_t*)arg;
	fd_set rfd;
	struct timeval tv;

	buf[sizeof(buf) - 1] = 0;
	tv.tv_sec = 0;
	tv.tv_usec = 10000;
	while(1) {
		int retval;
		FD_ZERO(&rfd);
		FD_SET(o->fd, &rfd);
		retval = select(o->fd + 1, &rfd, NULL, NULL, &tv);
		if(retval <= 0) continue;

		len = read(o->fd, buf, sizeof(buf) - 1);
		nread = 0;
		while( len > 0 ) {
			event = (struct inotify_event *)&buf[nread];
			for(i=0; i<EVENT_NUM; i++) {
					inotifywatch_invoke(o, event);
			}
			nread = nread + sizeof(struct inotify_event) + event->len;
			len = len - sizeof(struct inotify_event) - event->len;
		}
	}
	return arg;
}

int inotifywatch_startup(inotifywatch_t* o)//启动检测
{
	inotifynode_t* item = o->nodes;
	struct timespec t;
	gettimeofday(&t, NULL);
	o->fd = inotify_init();
	if( o->fd < 0 ) {
		fprintf(stderr, "inotify_init failed\n");
		return -1;
	}
	while(item && item->mask && item->onchange) {
		item->wd = inotify_add_watch(o->fd, item->addr, item->mask);//IN_ALL_EVENTS
		if(item->wd >= 0) {
			item->onchange(item, IN_CREATE);//首次加载调用IN_MODIFY
			item->last = t;
		}
		item++;
	}
	pthread_create(&o->threadid, NULL, inotifywatch_loop, o);
	return 1;
}
