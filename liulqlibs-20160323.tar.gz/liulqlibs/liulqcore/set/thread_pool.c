#include <sys/time.h>
#include <stdio.h>

#include <liulqcore.h>
#include "liulqdebug.h"

void thread_pool_initialize(thread_pool_t* o)//初始化对象
{
	o->execute = NULL;
	o->threadid = NULL;
	o->max_thread_num = 0;
	o->shutdown = 0;
}
void thread_pool_destory(thread_pool_t* o)//销毁对象
{
	int i;
	o->shutdown = 1;//停止任务运行
	linked_queue_destory(&o->queue);
	 if(NULL != o->threadid) {
		for(; i<o->max_thread_num; i++) {
			pthread_cancel(o->threadid[i]);
		}
		 free(o->threadid);
	 }
	o->execute = NULL;
	o->threadid = NULL;
}

void* thread_pool_running(void * arg)//--线程的回调函数
{
	thread_pool_t * o= ((thread_pool_t *)arg);
	while(!o->shutdown) {
		//如果当前的任务数目为0
		linked_list_lock(&(o->queue.items));
		while(o->queue.items.length == 0 && !o->shutdown) { //线程阻塞,等待条件成立
			linked_queue_wait(&(o->queue));
		}
		if(!o->shutdown) {
			o->queue.items.length--;//任务数目减去1
			seqlink_t  *worker = o->queue.items.head;//取出任务链表中的头元素, 也就是第一个任务
			o->queue.items.head = worker->next;
			linked_list_unlock(&(o->queue.items));

			o->execute(worker->arg);
			free(worker);
			worker=NULL;
		}
	}
	pthread_exit(NULL);
	return NULL;
}

int thread_pool_listern(thread_pool_t* o, int num, void* (*handle)(void *arg))//开始线程池监听
{
	int i=0;
	linked_queue_initialize(&(o->queue));
	o->shutdown = 0;
	o->max_thread_num = num;
	if(NULL != handle) o->execute = handle;
	o->threadid=(pthread_t *)malloc(o->max_thread_num * sizeof(pthread_t));
	//创建max_thread_num个线程
	for(; i<o->max_thread_num; i++) {
            pthread_create(&(o->threadid[i]), NULL, thread_pool_running, o);
	}
	return i;
}
int thread_pool_join(thread_pool_t* o)//等待线程执行完成
{
	int i=0;
	for(; i<o->max_thread_num; i++) {
		pthread_join(o->threadid[i], NULL);
	}
	return i;
}

int thread_pool_task_push(thread_pool_t* o, void* arg)//向线程池添加任务
{
	return linked_list_push(&(o->queue.items), arg);
}
