/*
 * hashbuffer.c
 *
 *  Created on: 2016年1月15日
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "liulqcore.h"

static int hashbuffer_string_compare(const void* a, const void* b)//
{
    return (0 == strcasecmp((const char*)(a), (const char*)(b)));
}
static void hashbuffer_string_bind(hashelement_t* o,  const void* key)
{
	strcpy((char*)o->key, (const char*)key);
}
static uint16_t hashbuffer_string_hash(const void* key, uint32_t maxhash)
{
    uint32_t hash = 0;
    const char* ap =  ((const char*)key);
    while(*ap)  hash += *ap++;
	while(hash >= maxhash) {
		hash = (hash / maxhash) + (hash % maxhash);
	}
    return hash;
}

//****************************************************************
int hashbuffer_sizeof(int size, int bsize)
{
	return (sizeof(hashbuffer_t) + (size * sizeof(hashelement_t*)) + bsize);
}
hashbuffer_t* hashbuffer_create(int size, int bsize)
{
	void* buffer = malloc(hashbuffer_sizeof(size, bsize));
	return hashbuffer_initialize(buffer, size, bsize);
}
hashbuffer_t* hashbuffer_initialize(void*buffer, int size, int bsize)
{
	hashbuffer_t* o = (hashbuffer_t*)buffer;
	o->map.size = size;
    o->map.compare = &hashbuffer_string_compare;//hash比较函数
    o->map.hashkey = &hashbuffer_string_hash;//计算哈希值
    o->map.bindkey = &hashbuffer_string_bind;//绑定键名
	o->bufsize = bsize;
    o->buffer = ((char*)buffer) + sizeof(hashbuffer_t) + (size * sizeof(hashelement_t*));
    hashbuffer_clean(o);
	return o;
}
void hashbuffer_destory(hashbuffer_t* o)
{
	free(o);
}
static inline char* hashbuffer_alloc(hashbuffer_t* o, int ln)
{
	char* result = o->buffer + o->bufpos;
	memset(result, 0, ln);
	o->bufpos += ln;
	return result;
}
int hashbuffer_add(hashbuffer_t* o, const void const* key,  const char const* val)//添加key及数据
{
	if(NULL == key || NULL == val) return 0;
	uint16_t hash = o->map.hashkey(key, o->map.size);
	hashelement_t *top, *p = o->map.table[hash];
	int result = 0;
	top = p;
	pthread_mutex_lock(&(o->map.lock));
    while (p && !o->map.compare(p->key, key))  p = p->next;
    if (!p) {
    	int kln = strlen(key), vln = strlen(val);
    	p = (hashelement_t*)hashbuffer_alloc(o, sizeof(hashelement_t));
    	p->key = hashbuffer_alloc(o, kln + 1);
    	memcpy(p->key, key, kln);
    	p->val = hashbuffer_alloc(o, vln + 1);
    	memcpy(p->val, val, vln);
    	if(top) p->next = top;
    	o->map.table[hash] = p;
    	result = 1;
    	o->map.count++;
     }
	pthread_mutex_unlock(&(o->map.lock));
	return result;
}
void hashbuffer_clean(hashbuffer_t* o)//清除所有数据
{
	pthread_mutex_lock(&(o->map.lock));
	o->bufpos = 0;
	memset(o->map.table, 0, (o->map.size * sizeof(hashelement_t*)));
	memset(o->buffer, 0, o->bufsize);
	pthread_mutex_unlock(&(o->map.lock));
 }
//************************************
void* hashbuffer_find(hashbuffer_t* o, const void* key)//哈希值
{
	return hashmap_find(&o->map, key);
}
int hashbuffer_contains(hashbuffer_t* o, const void* key)//哈希包含键名
{
	return hashmap_contains(&o->map, key);
}
int hashbuffer_equals_int32(hashbuffer_t* o, void* k, int v)//哈希值等于
{
	return hashmap_equals_int32(&o->map, k, v);
}
int hashbuffer_equals_string(hashbuffer_t* o, void* k, char* v)//哈希值等于
{
	return hashmap_equals_string(&o->map, k, v);
}
int hashbuffer_each(hashbuffer_t *o, hash_callback_each callback, void* arg)//循环枚举
{
	return hashmap_each(&o->map, callback, arg);
}
int hashbuffer_count(hashbuffer_t* o)//记录条数
{
	return o->map.count;
}



