/*
 * memorybuffer.c
 *
 *  Created on: 2016年2月26日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct memory_buffer_struct {//--读取数据回调结构
	int length, position;
	unsigned char buffer[];
} memorybuffer_t;

/**申请一个memorybuffer_t结构缓存区,len申请缓存区大小
 *@parameter len:申请缓存大小
 * */
memorybuffer_t* memorybuffer_alloc(unsigned int len)
{
	memorybuffer_t* o = (memorybuffer_t*)calloc(1, sizeof(memorybuffer_t)+len);
	o&&(o->length = len);
	return o;
}
/**向缓存区写数据
 *@parameter o:memorybuffer_t缓存对象
 *@parameter  data:数据
 *@parameter  len:数据长度
 */
int memorybuffer_write(memorybuffer_t *o, void const* const data, unsigned int len)
{
	if((o->position + len) < o->length) {
		memcpy(o->buffer + o->position, data, len);
		o->position += len;
		return o->position;
	}
	return -1;
}
/**向缓存区写字符串
 *@parameter o:memorybuffer_t缓存对象
 *@parameter  data:数据
 */
int  memorybuffer_writes(memorybuffer_t *o, char const* const data)//
{
	int ret  = 0;
	size_t len = strlen(data);
	ret = memorybuffer_write(o, data, len);
	if(o->position < o->length) {
		o->buffer[o->position + 1] = 0;
	}
	return ret;
}
/**判断是否允许添加len长度的数据
 *@parameter o:memorybuffer_t缓存对象
 *@parameter len:长度
 */
int memorybuffer_allowadd(memorybuffer_t *o, int len)
{
	return ((o->position + len) < o->length);
}
/**清除数据并复位
 *@parameter o:memorybuffer_t缓存对象
 */
void memorybuffer_clean(memorybuffer_t *o)
{
	memset(o->buffer, 0, o->length);
	o->position = 0;
}
/**回收缓存区
 * @parameter o:memorybuffer_t缓存对象
 * */
void memorybuffer_free(memorybuffer_t *o)
{
	if(NULL != o) {
		free(o);
		o=NULL;
	}
}

