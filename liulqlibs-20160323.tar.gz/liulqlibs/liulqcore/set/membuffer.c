#include <liulqcore.h>
#include "liulqdebug.h"

/**申请一个membuffer_t结构缓存区,len申请缓存区大小*/
membuffer_t* membuffer_alloc(unsigned int len)
{
	membuffer_t* o = (membuffer_t*)malloc(len+8);
	if(NULL != o) {
		o->length = len;
		o->position=0;
		o->buffer = (unsigned char*)(o+8);
	}
	return o;
}
/**向缓存区写数据*/
int membuffer_write(membuffer_t *o, const void* data, unsigned int len)
{
	if((o->position + len) < o->length) {
		memcpy(o->buffer + o->position, data, len);
		o->position += len;
		return o->position;
	}
	return -1;
}
int  membuffer_writes(membuffer_t *o, const char* data)//向缓存区写数据
{
	return membuffer_write(o, data, strlen(data) );
}
/**回收缓存区*/
void membuffer_free(membuffer_t *o)
{
	if(NULL != o) {
		free(o);
		o=NULL;
	}
}
