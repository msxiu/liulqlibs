#include <stdlib.h>
#include <liulqcore.h>
#include "liulqdebug.h"

void linked_queue_initialize(linked_queue_t *o)//链表队列初始化
{
	pthread_cond_init(&o->ready, NULL);//初始化 条件变量
	linked_list_initialize(&o->items);
}

void linked_queue_destory(linked_queue_t *o)//销毁链表队列
{
	pthread_cond_destroy(&o->ready);
	linked_list_destory(&o->items);
}

int linked_queue_push(linked_queue_t *o, void *arg)//--向队例压入一个数据
{
	return linked_list_push(&o->items, arg);
}

void * linked_queue_pop(linked_queue_t *o)//--从队列上弹出一个数据
{
	linked_queue_lock(o);
	while(o->items.length <= 0) {
		linked_queue_wait(o);
	}
	o->items.length--;//任务数目减去1
	seqlink_t  *worker = o->items.head;//取出任务链表中的头元素, 也就是第一个任务
	o->items.head = worker->next;
	linked_queue_unlock(o);
	void* result = worker->arg;
	free(worker);
	return result;
}

void linked_queue_wait(linked_queue_t *o)//等待队列上有数据压入
{
	 pthread_cond_wait(&o->ready, &o->items.lock);
}

void linked_queue_lock(linked_queue_t *o)//给队例加锁
{
	pthread_mutex_lock(&o->items.lock);
}
void linked_queue_unlock(linked_queue_t *o)//给队例解锁
{
	pthread_mutex_unlock(&o->items.lock);
}

