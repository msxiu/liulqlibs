/*
 * hashmap.c
 *
 *  Created on: 2016年1月14日
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "liulqcore.h"


hashptrmap_t* hashptrmap_initialize(int m)//初始化哈希
{
	return (hashptrmap_t*)calloc(1, sizeof(hashptrmap_t) + (m * sizeof(void*)));
}
void hashptrmap_set(hashptrmap_t* o, int i, void* item)//设置数据
{
	if(o->maxsize > i) {
		o->buffer[i] = item;
	}
}
void* hashptrmap_get(hashptrmap_t* o, int i)//获的数据
{
	if(o->maxsize > i) {
		return o->buffer[i];
	}
	return NULL;
}

//*******************************************************
static int hashmap_int32_compare(const void* a, const void* b)//
{
    return (*(int32_t*)(a) == *(int32_t*)(b));
}
static void hashmap_int32_bind(hashelement_t* o,  const void* key)
{
	if(!o->key) o->key = malloc(4);
	memcpy(o->key, key, 4);
}
static uint16_t hashmap_in32_key(const void* key, uint32_t maxhash)
{
    uint32_t hash = 0;
    int ap =  *((int*)key);
    hash = ((ap>>16) & 0xFFFF) + (ap & 0xFFFF);
	while(hash >= maxhash) {
		hash = (hash / maxhash) + (hash % maxhash);
	}
    return hash;
}
static int hashmap_string_compare(const void* a, const void* b)//
{
    return (0 == strcasecmp((const char*)(a), (const char*)(b)));
}
static void hashmap_string_bind(hashelement_t* o,  const void* key)
{
	if(!o->key) o->key = malloc(strlen(key) +1);
	strcpy((char*)o->key, (const char*)key);
}
static uint16_t hashmap_string_key(const void* key, uint32_t maxhash)
{
    uint32_t hash = 0;
    const char* ap =  ((const char*)key);
    while(*ap)  hash += *ap++;
	while(hash >= maxhash) {
		hash = (hash / maxhash) + (hash % maxhash);
	}
    return hash;
}

//*******************************************************


#define HASH_VALUE(p,v,l) {\
	p->val = calloc(1, l);\
	memcpy(p->val, v, l);\
}while(0)
#define HASH_DELETE(p) {\
	    free(p->key);\
	    free(p->val);\
	    free(p);\
}while(0)

void* hashmap_find(hashmap_t* o, const void* key)//哈希值
{
	uint16_t hash = o->hashkey(key, o->size);
	hashelement_t *p =  (hashelement_t*)o->table[hash];
    while (p && !o->compare(p->key, key))  p = p->next;
    if (!p) return NULL;
    return p->val;
}
int hashmap_contains(hashmap_t* o, const void* key)//哈希值包含
{
	uint16_t hash = o->hashkey(key, o->size);
	hashelement_t *p =  (hashelement_t*)o->table[hash];
    while (p && !o->compare(p->key, key))  p = p->next;
    return  (!!p);
}
int hashmap_equals_int32(hashmap_t* o, void* k, int v)//哈希值等于
{
	int* hv = (int*)hashmap_find(o, k);
	if(NULL == hv) return 0;
	return (v == *hv);
}
int hashmap_equals_string(hashmap_t* o, void* k, char* v)//哈希值等于
{
	char* hv = (char*)hashmap_find(o, k);
	if(NULL == hv) return 0;
	return (0 == strcasecmp(hv, v) ? 1 : 0);
}

int hashmap_addint32(hashmap_t* o, const void* key,  int val)
{
	return hashmap_additem(o, key, &val, 4);
}
int hashmap_addint64(hashmap_t* o, const void* key,  int64_t val)
{
	return hashmap_additem(o, key, &val, 8);
}
int hashmap_addstring(hashmap_t* o, const void* key,  const char const* val)
{
	return hashmap_additem(o, key, val, (NULL == val ? 0 : strlen(val)));
}

int hashmap_additem(hashmap_t* o, const void* key,  const void* val, uint32_t vln)//添加key及数据
{
	if(NULL == key || NULL == val || 0 == vln) return 0;
	uint16_t hash = o->hashkey(key, o->size);
	hashelement_t *top, *p = o->table[hash];
	int result = 0;
	top = p;
    while (p && !o->compare(p->key, key))  p = p->next;
	pthread_mutex_lock(&(o->lock));
    if (!p) {
    	p = calloc(1, sizeof(hashelement_t));
    	p->time = time(NULL);
    	o->bindkey(p, key);
    	HASH_VALUE(p, val, vln);
    	if(top) p->next = top;
    	o->table[hash] = p;
    	result = 1;
    	o->count++;
     } else {
		free(p->val);
		HASH_VALUE(p, val, vln);
     }
	pthread_mutex_unlock(&(o->lock));
	return result;
}
int hashmap_addpointer(hashmap_t* o, const void* key,  void* val)//添加key及数据
{
	if(NULL == key || NULL == val) return 0;
	uint16_t hash = o->hashkey(key, o->size);
	hashelement_t *top, *p = o->table[hash];
	int result = 0;
	top = p;
    while (p && !o->compare(p->key, key))  p = p->next;
	pthread_mutex_lock(&(o->lock));
    if (!p) {
    	p = calloc(1, sizeof(hashelement_t));
    	p->time = time(NULL);
    	o->bindkey(p, key);
    	p->val = val;//HASH_VALUE(p, val, vln);
    	if(top) p->next = top;
    	o->table[hash] = p;
    	result = 1;
    	o->count++;
     } else {
		free(p->val);
    	p->val = val;//HASH_VALUE(p, val, vln);
     }
	pthread_mutex_unlock(&(o->lock));
	return result;
}

int hashmap_delitem(hashmap_t* o, const void* key)//删除key及数据
{
	hashelement_t *p0 = NULL, *p = NULL;
	int result = 0;
	uint16_t hash = o->hashkey(key, o->size);
    p = o->table[hash];
	pthread_mutex_lock(&(o->lock));
    while (p && !o->compare(p->key, key)) {
        p0 = p;
        p = p->next;
    }
    if (p) {
		if (p0) {//非第一个元素
			p0->next = p->next;
		} else {//第一个元素
			o->table[hash] = p->next;
		}
		HASH_DELETE(p);
		o->count--;
    }
	pthread_mutex_unlock(&(o->lock));
    return result;
}
int hashmap_count(hashmap_t* o)//记录条数
{
	return o->count;
}
int hashmap_each(hashmap_t *o, hash_callback_each callback, void* arg)//循环枚举
{
	int i=0, ret =0;
	hashelement_t *p0, *p;
	for(;i<o->size;i++) {
		   p = o->table[i];
		    while (p) {
		        p0 = p;
		        callback(arg, p);
		        ret ++;
		        p = p->next;
		    }
	}
	return ret;
}
int hashmap_timeout(hashmap_t* o, int second, hash_callback_each callback, void* arg)//超时移除
{
	int i=0, ret =0;
	hashelement_t *p0, *p;
	time_t outime = time(NULL) - second;
	for(;i<o->size;i++) {
		   p = o->table[i];
		    while (p) {
		        p0 = p;
		        if(p->time < outime) {
					callback(arg, p);
					pthread_mutex_lock(&(o->lock));
					if (p0) {//非第一个元素
						p0->next = p->next;
					} else {//第一个元素
						o->table[i] = p->next;
					}
					HASH_DELETE(p);
					o->count--;
					pthread_mutex_unlock(&(o->lock));
					ret ++;
		        }
		        p = p0->next;
		    }
	}
	return ret;
}
void hashmap_destory(hashmap_t* o)//销毁对象
{
	int i=0;
	hashelement_t *p0, *p;
	for(;i<o->size;i++) {
		   p = o->table[i];
		    while (p) {
		        p0 = p;
		        HASH_DELETE(p0);
		        p = p->next;
		    }
	}
	free(o);
}

//****************************************************************************
hashmap_t* hashmap_create(int size, hash_callback_compare compare, hash_callback_hash hashkey, hash_callback_bind bindkey) //创建存储汇聚流需要的哈希table
{
	int hsize = sizeof(hashmap_t) + (size * sizeof(void*));
    hashmap_t* o;
    o = calloc(1, hsize);
    o->size = size;//hash大小
    o->compare = compare;//hash比较函数
    o->hashkey = hashkey;//计算哈希值
    o->bindkey = bindkey;//绑定键名
    return o;
}
hashmap_t* hashmap_create_int32(int size) //创建存储汇聚流需要的哈希table
{
	return hashmap_create(size, &hashmap_int32_compare, &hashmap_in32_key, &hashmap_int32_bind);
}
hashmap_t* hashmap_create_string(int size) //创建存储汇聚流需要的哈希table
{
	return hashmap_create(size, &hashmap_string_compare, &hashmap_string_key, &hashmap_string_bind);
}
