#include <stdlib.h>
#include <liulqcore.h>
#include "liulqdebug.h"

/**初始化链表结构*/
void linked_list_initialize(linked_list_t *o)
{
	pthread_mutex_init(&o->lock, NULL);//初始化 互斥锁
	o->head = NULL;
	o->current = NULL;
	o->last	= NULL;
	o->length = 0;
}
/**释放链表中记录*/
int linked_list_destory(linked_list_t *o)
{
	GDB_DEBUGS("linked_list_destory by %p;\n", o);
	int cnt = 0;
	if(o->length > 0) {
		linked_list_lock(o);
		seqlink_t  *worker = o->head, *temp;//取出任务链表中的头元素, 也就是第一个任务
		while(NULL != worker) {
			temp = worker->next;
			cnt ++;
			GDB_DEBUGS("'%p' %d node %p: %p;\n", o, cnt,worker, worker->arg);
			free(worker->arg);
			free(worker);
			worker = temp;
		}
		o->head = NULL;
		o->current = NULL;
		o->last	= NULL;
		o->length=0;
		linked_list_unlock(o);
		GDB_DEBUGS("%p finished;\n", o);
	}
	return cnt;
}
//--向链表添加一个任务
int linked_list_push(linked_list_t *o, void *arg)
{
	seqlink_t  *newworker=(seqlink_t *)malloc(sizeof(seqlink_t));
	newworker->arg = arg;
	newworker->next = NULL;

    pthread_mutex_lock(&o->lock);//在操作全局变量pool之前,需要先上锁
     if(o->head !=NULL) {//如果线程池中的任务链表不为空
    	 newworker->prev = o->last;//指向上一个对象
    	 if(o->last) {
    		 o->last->next = newworker;//将对象加入链表
			 o->last = o->last->next;//移动链表尾
    	 } else {
    		 o->last = newworker;//将对象加入链表
    	 }
    } else {//如果线程池中的任务链表为空
    	newworker->prev = NULL;
    	o->head = newworker;
    	o->last = newworker;
    }
     o->length++;
    pthread_mutex_unlock(&o->lock);//在操作完全局变量pool后,需要解锁
    return o->length;
}
//删除当前记录
void linked_list_remove_current(linked_list_t *o)
{
	seqlink_t  *worker = o->current;
	if(NULL != worker) {
		if(worker->prev) {
			worker->prev->next = worker->next;
		} else {
			o->head = worker->next;
		}
		if(worker->next) {
			worker->next->prev = worker->prev;
		} else {
			o->last = worker->next;
		}
		free(worker->arg);
		worker->arg = NULL;
		free(worker);
		worker = NULL;
		o->length--;
	}
}

//获得指定记录
void* linked_list_indexof(linked_list_t *o, int i)
{
	if(i >= o->length) return NULL;
	seqlink_t  *worker = o->head;
	while(i--) worker = worker->next;
	if(NULL == worker) return NULL;
	return worker->arg;
}
//获得记录数据
void *linked_list_entry(linked_list_t *o)
{
	if(NULL == o->current) return NULL;
	return o->current->arg;
}
//是否有下一条记录
char linked_list_next(linked_list_t *o)
{
	seqlink_t  *worker = o->current;
	if(NULL == worker) return 0;
	o->current = o->current->next;
	return (NULL == o->current ? 0 : 1);
}
//是否有上一条记录
char linked_list_prev(linked_list_t *o)
{
	seqlink_t  *worker = o->current;
	if(NULL == worker) return 0;
	o->current = o->current->prev;
	return (NULL == o->current ? 0 : 1);
}
//重置链表记录
void linked_list_reset(linked_list_t *o)
{
	o->current = o->head;
}

//锁定链表
void linked_list_lock(linked_list_t *o)
{
	pthread_mutex_lock(&o->lock);
}
//解锁链表
void linked_list_unlock(linked_list_t *o)
{
	pthread_mutex_unlock(&o->lock);
}
