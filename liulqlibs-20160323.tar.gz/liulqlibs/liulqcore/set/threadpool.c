/*
 * threadpool.c
 *
 *  Created on: 2016年1月22日
 *      Author: root
 */
#include <pthread.h>
#include "liulqcore.h"
#include "list.h"



static void* threadpool_running(void * arg)//--线程的回调函数
{
	threadpool_t * o= ((threadpool_t *)arg);
	while(1) {
		threadpool_entry_t  *item=NULL;
		pthread_mutex_lock(&o->lock);
		while(o->queuelen == 0 && !o->shutdown) { //线程阻塞,等待条件成立
			pthread_cond_wait(&(o->ready), &(o->lock));
		}
		while(o->pause) usleep(10000);
		if(o->queuelen) {
			o->queuelen--;//任务数目减去1
			struct list_head *ptr = o->queue.next;
			item  = list_entry(ptr, threadpool_entry_t, list);
			list_del(ptr);
		}
		pthread_mutex_unlock(&o->lock);
		if(item) {
			if(item->dat) {
				o->execute(item->dat);
				free(item->dat);
			}
			free(item);
			item=NULL;
		}
	}
	pthread_exit(NULL);
	return arg;
}

int threadpool_listern(threadpool_t* o, int num, void (*handle)(void *arg))//开始线程池监听
{
	int i=0;
	INIT_LIST_HEAD(&(o->queue));
	pthread_cond_init(&o->ready, NULL);//初始化 条件变量
	pthread_mutex_init(&o->lock, NULL);//初始化 互斥锁
	o->shutdown = 0;
	o->pause = 0;
	o->max_thread = num;
	if(NULL != handle) o->execute = handle;
	o->threadid=(pthread_t *)malloc(o->max_thread* sizeof(pthread_t));
	//创建max_thread_num个线程
	for(; i<o->max_thread; i++) {
            pthread_create(&(o->threadid[i]), NULL, threadpool_running, o);
	}
	return i;
}
void threadpool_destory(threadpool_t* o)//销毁线程池
{
	threadpool_entry_t  *item=NULL, *n;
	o->shutdown = 1;
	pthread_mutex_lock(&o->lock);
	list_for_each_entry_safe(item, n, &(o->queue), list) {
		if(item) {
			if(item->dat) {
				o->execute(item->dat);
				free(item->dat);
			}
			free(item);
			item=NULL;
		}
	}
	free(o->threadid);
	pthread_mutex_unlock(&o->lock);
}

void threadpool_pause(threadpool_t* o)//暂停运行
{
	o->pause = 1;
}
void threadpool_restore(threadpool_t* o)//恢复运行
{
	o->pause = 1;
}
int threadpool_join(threadpool_t* o)//等待线程执行完成
{
	int i=0;
	for(; i<o->max_thread; i++) {
		pthread_join(o->threadid[i], NULL);
	}
	return i;
}

void* threadpool_task_alloc(threadpool_t* o, int size)//向线程池申请任务空间
{
	void* arg = calloc(1, size);
	if(NULL != arg) {
		threadpool_entry_t* item = (threadpool_entry_t*)calloc(1, sizeof(threadpool_entry_t));
		item->dat = arg;
		item->tm = time(NULL);

		pthread_mutex_lock(&o->lock);
		list_add_tail(&(item->list), &(o->queue));
		pthread_cond_signal(&(o->ready));
		o->queuelen++;//任务数目减去1
		pthread_mutex_unlock(&o->lock);
	}
	return arg;
}


