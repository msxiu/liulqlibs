#include <liulqcore.h>
#include "liulqdebug.h"

#define DEBUG_BUFFER(o, fmt, args...) {\
	char flname[128],buffer[512];\
	sprintf(flname, "/home/logs/dac/dbuffer/%p.log", o);\
	sprintf(buffer, fmt, args);\
	file_addbuffer("/home/logs/dac/dbuffer.log", buffer, strlen(buffer));\
}while(0)

#define LOGS_DBUFFER_WRITE {}while(0)
#define LOGS_DBUFFER_READ {}while(0)
#define LOGS_DBUFFER(o, fmt, args...) {}while(0)


#define DBUFFER_SIMPLE_MEMORY
#ifdef DBUFFER_SIMPLE_MEMORY
static pthread_mutex_t dbuffer_lock = PTHREAD_MUTEX_INITIALIZER;//互斥锁
#define DBUFFER_LOCK		dbuffer_lock
#else
#define DBUFFER_LOCK		o->lock
#endif



static inline void dbuffer_write_data(dbuffer_t *o, void* pa, int ps, const void* data, unsigned int len)//向内存写入数据,利于gdb查看地址
{
	LOGS_DBUFFER_WRITE(o, "write {pa:%p,ps:%d,data:%p,len:%d};\n", pa, ps, data, len);
	if((ps + len) > o->pgsize){
		GDB_DEBUGS("write warn {pa:%p,ps:%d,data:%p,len:%d,overrid:%d};\n", pa, ps, data, len, (ps+len-o->pgsize));
	}
	memcpy(pa + ps, data, len);
}
static inline void dbuffer_read_data(dbuffer_t *o, void* pa, int ps, const void* data, unsigned int len)//向内存写入数据,利于gdb查看地址
{
	LOGS_DBUFFER_READ(o, "read {pa:%p,ps:%d,data:%p,len:%d};\n", pa, ps, data, len);
	memcpy(pa + ps, data, len);
}
static inline void dbuffer_free_memory(dbuffer_t *o, void* addr)//回收内存,利于gdb查看地址
{
	if(addr) {//&& addr >= 0x1000000
		LOGS_DBUFFER(o, "free %p := %p;\n", o, addr);
		free(addr);
		addr = NULL;
	}
}
static inline void* dbuffer_calloc(dbuffer_t *o)
{
	int max_cnt = 5;
	void* result = NULL;
	while(!result && max_cnt--) {
		result = calloc(1, o->pgsize + 10);
		if(!result) usleep(5);
	}
	LOGS_DBUFFER(o, "calloc %p := %p;\n", o, result);
	if(NULL == result) {
		GDB_WARNS("%p:dbuffer_calloc fail!\n", o);
	}
	return result;
}

dbuffer_t* dbuffer_alloc(unsigned int msize, unsigned short psize)
{
	dbuffer_t* o = (dbuffer_t*)calloc(1, sizeof(dbuffer_t));
	dbuffer_initialize(o, msize, psize);
	return o;
}
char dbuffer_initialize(dbuffer_t *o, unsigned int msize, unsigned short psize)
{
	pthread_mutex_init(&(o->lock), NULL);//初始化 互斥锁
	o->bytecnt = 0;
	o->pgsize = psize;
	o->maxpgs = pager_max(msize, o->pgsize);
	size_t sln = sizeof(void*);
	o->pgs = calloc(o->maxpgs , sln);
	LOGS_DBUFFER(o, "-----%p:%d initialize-----------------------------------------------------\n", o->pgs, (o->maxpgs * sln));
	return 1;
}
int dbuffer_pages(dbuffer_t *o)
{
	if(0 == o->bytecnt) return 0;
	return pager_max(o->bytecnt, o->pgsize);
}
char dbuffer_page(dbuffer_t *o, int i, vdata_t *v)
{
	int len, pgcnt = dbuffer_pages(o);
	if(i >= pgcnt) return 0;
	len =( (i == pgcnt - 1) ? (o->bytecnt % o->pgsize) : o->pgsize);
	v->addr = o->pgs[i];
	v->length = len;
	return 1;
}

/**向缓存区写数据*/
int dbuffer_write(dbuffer_t *o, const void* data, unsigned int len)
{
	if((len <=  0) || (o->bytecnt + len >= o->maxpgs * o->pgsize)) return -1;//超出最大值
	int pi = (int) (o->bytecnt / o->pgsize), pnext;
	if(pi >= o->maxpgs) return -1;//当前是否超出最大页数
	int ps = o->bytecnt % o->pgsize;//当前页使用多少
	int pl = o->pgsize - ps;//当前数据位置
    pthread_mutex_lock(&DBUFFER_LOCK);//在操作全局变量pool之前,需要先上锁
	void* pa = o->pgs[pi];
	if(NULL == pa) {
		pa = dbuffer_calloc(o);//calloc(1, o->pgsize + 10);
		if(!pa) {
			GDB_DEBUGS("pi:%d,ps:%d,pl:%d, malloc fail!\n", pi, ps, pl);
			return -1;
		}
		o->pgs[pi] =pa;
	}
	if(pl > len) {//memcpy(pa + ps, data, len);
		dbuffer_write_data(o, pa, ps, data, len);
		o->bytecnt += len;
	} else {
		//写入数据到原页尾 memcpy(pa + ps, data, pl);
		dbuffer_write_data(o, pa, ps, data, pl);
		pnext = len - pl;
		while(pnext > 0) {
			pi++;
			pa = dbuffer_calloc(o);//calloc(1, o->pgsize);
			if(!pa) {
				GDB_DEBUGS("pi:%d,pnext:%d, malloc fail!\n", pi, pnext);
				return -1;
			}
			o->pgs[pi] =pa;
			if(pnext < o->pgsize){//memcpy(pa, data + pl, pnext);
				dbuffer_write_data(o, pa, 0, data + pl, pnext);
				pnext = 0;
			} else {//memcpy(pa, data + pl, o->pgsize);
				dbuffer_write_data(o, pa, 0, data + pl, o->pgsize);
				pnext -= o->pgsize;
				pl += o->pgsize;
			}
		}
		o->bytecnt += len;
	}
    pthread_mutex_unlock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	return len;
}
int  dbuffer_writes(dbuffer_t *o, const char* data)//向缓存区写数据
{
	return dbuffer_write(o, data, strlen(data) );
}

unsigned int dbuffer_read(dbuffer_t *o, void* buffer)
{
	if(o->bytecnt <= 0 || !buffer) return 0;
	int i=0, pgcnt = dbuffer_pages(o), pos = 0;
	vdata_t v;
    pthread_mutex_lock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	for(i=0;i<pgcnt;i++) {
		dbuffer_page(o, i, &v);
		//memcpy(buffer+pos, v.addr, v.length);
		if(v.addr) {
			dbuffer_read_data(o, buffer, pos, v.addr, v.length);
			pos+=v.length;
		} else {
			GDB_WARNS("dbuffer_read:%p fail of %d page %p:%d;\n", o, i, v.addr, v.length);
		}
	}
    pthread_mutex_unlock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	memset(buffer + pos, 0, 1);
	return pos;
}

unsigned int dbuffer_reset_read(dbuffer_t *o, void* buffer)//读取完后清空数据
{
	if(o->bytecnt <= 0 || !buffer) return 0;
	int i=0, pgcnt = dbuffer_pages(o), pos = 0;
	vdata_t v;
    pthread_mutex_lock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	for(i=0;i<pgcnt;i++) {
		dbuffer_page(o, i, &v);
		if(v.addr) {
			dbuffer_read_data(o, buffer, pos, v.addr, v.length);
			pos+=v.length;
		} else {
			GDB_WARNS("dbuffer_read:%p fail of %d page %p:%d;\n", o, i, v.addr, v.length);
		}
		dbuffer_free_memory(o, o->pgs[i]);
	}
	memset(o->pgs, 0, sizeof(o->maxpgs * sizeof(void*)));
	o->bytecnt = 0;
    pthread_mutex_unlock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	memset(buffer + pos, 0, 1);
	return pos;
}

char dbuffer_output(dbuffer_t* o)
{
	char buffer[o->bytecnt + 10];
	if(dbuffer_read(o, buffer)>0) {
		printf("%s\n", buffer);
		return 1;
	}
	return 0;
}

void dbuffer_reset(dbuffer_t *o)//重置缓存区
{
	pthread_mutex_lock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	if(o->bytecnt > 0) {
		int i=0, cnt = pager_max(o->bytecnt, o->pgsize);
		LOGS_DBUFFER(o, "dbuffer_reset:%p,bytecnt:%d,pgcnt:%d;-------\n", o, o->bytecnt, cnt);
		for(; i<cnt; i++) {
			dbuffer_free_memory(o, o->pgs[i]);
			o->pgs[i] = NULL;
		}
		//memset(o->pgs, 0, sizeof(o->maxpgs * sizeof(void*)));
		o->bytecnt = 0;
	}
	pthread_mutex_unlock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
}
void dbuffer_destory(dbuffer_t *o)
{
	if(NULL != o) {
		dbuffer_free(o);
		dbuffer_free_memory(o, o);
	}
}
/**回收缓存区*/
void dbuffer_free(dbuffer_t *o)
{
	pthread_mutex_lock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
	if(o->bytecnt > 0) {
		int i=0, cnt = pager_max(o->bytecnt, o->pgsize);
		LOGS_DBUFFER(o, "dbuffer_free:%p,bytecnt:%d,pgcnt:%d;-------\n", o, o->bytecnt, cnt);
		for(i=0; i<cnt; i++) {
			dbuffer_free_memory(o, o->pgs[i]);
			o->pgs[i] = NULL;
		}
		o->bytecnt=0;
		o->maxpgs = 0;
		dbuffer_free_memory(o, o->pgs);
		o->pgs=NULL;
	}
	pthread_mutex_unlock(&DBUFFER_LOCK);//在操作完全局变量pool后,需要解锁
}
