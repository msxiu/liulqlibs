/*
 * actree_inotify.c
 *
 *  Created on: 2016年2月24日
 *      Author: root
 */
#include <stdio.h>
#include <sys/inotify.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "actree.h"

#define IS_NEWLINE(c)		('\r' == (c) || '\n' == (c))

/**从缓存中加载actree对象
 *@buffer 缓存地址
 *@len 缓存长度
 */
static void* actree_formbuffer(void* buffer, int len)
{
	int argc = 0, ps = 0, i;
	char* argv[1024], *chs = (char*)buffer;
	char* start = chs, c;
	while(ps < len) {
		c = *(chs+ps);
		if(IS_NEWLINE(c)) {
			if(!chars_is_empty(start) && !IS_NEWLINE(*start) && '#' != *start) {
				argv[argc++] = start;
			}
			chs[ps] = 0;
			ps++;
			while(IS_NEWLINE(*(chs+ps))) ps++;
			start = chs+ps;
		}
		ps++;
	}
	if(!chars_is_empty(start) && !IS_NEWLINE(*start) && '#' != *start) {
		argv[argc++] = start;
	}
	return (void*)actree_create(argc, argv, (ACTREE_STYLE_BCSHIFT | ACTREE_STYLE_GSSHIFT));
}

/**acbmtree_t通知改变响应函数
 * @o inotify节点
 * @t 操作位掩码
 */
void actree_notify_change(inotifynode_t* o, uint32_t t)
{
	if((t & IN_MODIFY) || (t & IN_DELETE) || (t & IN_CREATE)) {
		if(o->arg) {
			actree_destory((actree_t*)o->arg);
			o->arg = NULL;
		}
		int flen = file_length(o->addr);
		if(flen > 0) {
			 unsigned char *buffer = calloc(1, flen + 2);
			 file_read_tobuffer(o->addr, buffer);
			 o->arg = actree_formbuffer(buffer, flen);
			 free(buffer);
			 GDB_DEBUGS("acbmtree[%p]:'%s', reload to %p;\n", o, o->addr, o->arg);
		} else {
			GDB_DEBUGS("acbmtree[%p]:'%s' file not exists!\n", o, o->addr);
		}
	}
}

/**actree关键词数组文件动态通知加载
 * @o 检测文件集合
 */
int actree_inotify(inotifywatch_t* o)
{
	inotifynode_t* item=o->nodes;
	while(item && item->mask) {
		item->onchange = actree_notify_change;
		item++;
	}
	return inotifywatch_startup(o);
}



