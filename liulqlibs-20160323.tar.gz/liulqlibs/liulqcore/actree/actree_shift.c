/*
 * actree_shift.c
 *
 *  Created on: 2016年2月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "liulqdebug.h"
#include "actree.h"

/**附加字母首次出现列表
 * @ptree 匹配树对象
 */
int actree_BCshifts_attach (actree_t *ptree)
{
	int i, j = 0 ;
	for (i = 0 ; i < 256 ; i++) {
		ptree->BCshift[i] = ptree->min_pattern_size ;
	}
	for (i = ptree->min_pattern_size - 1 ; i > 0 ; i--) {
		for (j = 0 ; j < ptree->pattern_count ; j++)  {
			unsigned char ch ;
			ch = (ptree->pattern_list+j)->data[i] ;
			ch = tolower(ch) ;
			ptree->BCshift[ch] = i ;
			if ((ch > 'a') && (ch <'z')) {
				ptree->BCshift[ch-32] = i ;
			}
		}
	}
	return 0 ;
}


//计算每个模式串第一个字符的GSshift
static int actree_GSshift_set (actree_t *ptree, unsigned char *pat, int depth, int shift)
{
	int i ;
	actree_node_t *node ;
	if (NULL == ptree || NULL == ptree->root) goto err ;
	node = ptree->root ;
	for (i = 0 ; i < depth ; i++) {
		node = node->childs[pat[i]] ;
		if (NULL == node)goto err ;
	}
	node->GSshift = ((node->GSshift < shift) ? node->GSshift : shift);
	return 0 ;

err:
	return -1 ;
}

/** 计算每个模式串第一个字符的GSshift
 *@ptree 匹配树
 *@pat1 第一个关键词
 *@pat1_len 第一个关键词的长度
 *@pat2 第二个关键词
 *@pat2_len 第二个关键词的长度
 */
static int actree_GSshift_compute (actree_t *ptree, unsigned char *pat1, int pat1_len, unsigned char *pat2, int pat2_len)
{
	unsigned char first_char ;
	int i ;
	int pat1_index, pat2_index, offset ;
	if (NULL == pat1 || NULL == pat2 || pat1_len < 0 || pat2_len < 0) goto err ;
	if (pat1_len == 0 || pat2_len == 0) return 0 ;
	first_char = pat1[0] ;

	first_char = tolower(first_char) ;
	for (i = 1 ; i < pat2_len ; i++) {//跳过与pat1首字母相等字符
		if (tolower(pat2[i]) != first_char) break ;
	}
	actree_GSshift_set (ptree, pat1, 1, i);//计算每个模式串第一个字符的GSshift
	i = 1 ;
	while (1){//i用来的循环，用途？？
		while (i < pat2_len && tolower(pat2[i]) != first_char) i++ ;
		if (i == pat2_len) break ;// pat2剩余字符中未发现有pat1首字符相同字符,结束函数
		if (i > ptree->min_pattern_size) break ;
		offset = pat2_index = i ;
		pat1_index = 0 ;
		while (pat2_index < pat2_len && pat1_index < pat1_len) {//比较pat1是pat2的pat2_index为开始的子串
			if (tolower(pat1[pat1_index]) != tolower(pat2[pat2_index])) break ;
			pat1_index++ ;//是比较位的字符的深度
			pat2_index++ ;
		}
		if (pat2_index == pat2_len) {// 关键字pat1前缀是关键字pat2后缀
			int j ;
			for (j = pat1_index ; j < pat1_len ; j++) {
				actree_GSshift_set (ptree, pat1, j+1, offset) ;
			}
		} else {// pat1的前缀是pat2的子串,被pat2包含
			actree_GSshift_set (ptree, pat1, pat1_index+1, offset) ;//字符所在的深度和序号差一位
		}
		i++ ;
	}
	return 0 ;

err:
	return -1 ;
}

static int actree_GSshifts_attach (actree_t *ptree)//双重循环调用pattern_list每个关键词
{
	int pat_i = 0, pat_j = 0 ;
	for (pat_i = 0 ; pat_i < ptree->pattern_count ; pat_i++) {
		for (pat_j = 0 ; pat_j < ptree->pattern_count ; pat_j++) {
			unsigned char *ppat_i = (ptree->pattern_list+pat_i)->data ;
			int patlen_i = (ptree->pattern_list+pat_i)->len ;
			unsigned char *ppat_j = (ptree->pattern_list+pat_j)->data ;
			int patlen_j = (ptree->pattern_list+pat_j)->len ;
			actree_GSshift_compute (ptree, ppat_i, patlen_i, ppat_j, patlen_j) ;
		}
	}
	return 0 ;
}


//循环赋值child->GSshift=min_pattern_size
static int actree_GSshift_init (actree_node_t *root, int shift)
{
	int i ;
	if (root->label != -2) root->GSshift = shift;
	for (i = 0 ; i < 256 ; i++) {
		if ((i >= 'A') && (i <= 'Z')) continue;
		if (NULL != root->childs[i]) {
			actree_GSshift_init (root->childs[i], shift);
		}
	}
	return 0 ;
}

//循环赋值child->GSshift=min_pattern_size
static int actree_GSshifts_pattern (actree_t *ptree)
{
	actree_GSshift_init (ptree->root, ptree->min_pattern_size);
	return 0;
}


/**获得gs_shift的下一跳转位置
 * @node 节点
 */
static int actree_gshift_position(actree_node_t *node)
{
	return (node->childs[node->one_child] ? node->childs[node->one_child]->GSshift : 0);
}

/**绑定多模匹配节点树的跳转逻辑
 *@ptree 匹配树
 */
int actree_shifts_attach (actree_t *ptree)//
{
	actree_BCshifts_attach (ptree) ;//建立字母首次出现列表
	actree_GSshifts_pattern (ptree) ;//循环赋值child->GSshift=min_pattern_size
	actree_GSshifts_attach (ptree) ;
	ptree->gsposition = actree_gshift_position;
	return 0 ;
}

/** acbm树关键词重置
 * @ptree 匹配树
 * @argc 关键词对象个数
 * @argv 关键词对象列表
*/
 void actree_resetkeys (actree_t *ptree, int argc, char* argv[])
{
	actree_key_t* patterns = (actree_key_t*)malloc(argc * sizeof(actree_key_t));
	int i=0, count = 0;
	for(;i<argc;i++) {
		if(chars_is_empty(argv[i])) continue;
		patterns[i].len = strlen(argv[i]);
		if(patterns[i].len >= ACTREE_PATTERN_LEN) {//处理超长的关键词
			GDB_WARNS("key %d:'%s' override length %d:%d;\n", i, argv[i], patterns[i].len, ACTREE_PATTERN_LEN);
			patterns[i].len = ACTREE_PATTERN_LEN-1;
			SET_BUFFER(patterns[i].data, argv[i], patterns[i].len);
		} else {
			strcpy(patterns[i].data, argv[i]);
		}
		count++;
	}
	actree_patterns (ptree, patterns, argc) ;
	actree_shifts_attach (ptree) ;
}

 /**使用关键词创建actree对象
  *@argc 关键词个数
  *@argv 关键词数组
  *@style actree对象样式
  */
actree_t* actree_create(int argc, char* argv[], enum ACTREE_STYLE style)
{
	actree_t *ptree = NULL ;
	ptree = (actree_t *) malloc (sizeof (actree_t)) ;
	if (NULL == ptree)  return NULL;
	memset (ptree, 0, sizeof(actree_t)) ;
	ptree->style = style;

	actree_resetkeys (ptree, argc, argv);
	return ptree;
}
