/*
 * actree.c
 *
 *  Created on: 2016年2月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "actree.h"



/** actree树初始化关键词
 * @ptree 关键词初始化的树节点,即将关键词初始化到该树上
 * @param patterns 关键词对象列表
 * @param npattern 关键词对象个数
 */
int actree_patterns (actree_t *ptree, actree_key_t *patterns, int npattern)
{
	int i ;
	actree_node_t *root = NULL, *parent = NULL ;
	unsigned char ch ;//当前字符
	int max_pattern_len = 0, min_pattern_len = ACTREE_PATTERN_LEN ;
	if (NULL == ptree || NULL == patterns || npattern < 0) goto err ;
	root = (actree_node_t*) malloc(sizeof (actree_node_t));
	if (NULL == root)goto err ;
	memset (root, 0, sizeof (actree_node_t)) ;

	root->label = -2 ;
	root->depth = 0 ;

	for (i = 0 ; i < npattern ; i++)  {
		int pat_len ;//关键词长度
		int ch_i ;

		pat_len = (patterns+i)->len ;
		if (pat_len == 0) {
			continue ;
		} else {
			if (pat_len > ACTREE_PATTERN_LEN) pat_len = ACTREE_PATTERN_LEN;
			if (pat_len > max_pattern_len) max_pattern_len = pat_len;
			if (pat_len < min_pattern_len) min_pattern_len = pat_len;
			parent = root ;
			for (ch_i = 0 ; ch_i < pat_len ; ch_i++) {
				ch = ((patterns+i)->data)[ch_i] ;
				ch = tolower(ch) ;
				if (NULL == parent->childs[ch]) break ;
				parent = parent->childs[ch] ;
			}
			if (ch_i < pat_len) {//不存在字结点则创建
				for (; ch_i < pat_len ; ch_i++) {//在子节点点下添加新节点
					actree_node_t *node = NULL ;
					ch = ((patterns+i)->data)[ch_i] ;
					ch = tolower(ch) ;
					node = (actree_node_t *) malloc(sizeof (actree_node_t)) ;
					if (node == NULL)goto err ;
					memset (node, 0, sizeof(actree_node_t)) ;
					node->depth = ch_i + 1 ;
					node->ch = ch ;
					node->label = -1 ;
					parent->childs[ch] = node ;
					if ((ch >= 'a') && (ch <= 'z')) {//小写转为大写
						parent->childs[ch-32] = node ;
					}
					parent->nchild++ ;
					parent->one_child = ch ;
					node->parent = parent ;

					parent = node ;
				}
			}
		}
		parent->label = i ;// lable 记录字串来自于第几个输入字串
	}

	ptree->pattern_list = patterns ;
	ptree->pattern_count = npattern ;
	ptree->root = root ;
	ptree->max_depth = max_pattern_len ;
	ptree->min_pattern_size = min_pattern_len ;

	return 0 ;

err:// 出错处理,释放申请的空间
	if (ptree->root != NULL) {
		_clean_tree (ptree->root) ;
		free (ptree->root) ;
		ptree->root = NULL ;
	}
	return -1 ;
}


/** 销毁root对象及字节点
 * @root 关键词树的节点
 */
static inline void actree_destory_childs (actree_node_t *root)
{
	int i ;
	for (i = 0 ; i < 256 ; i++) {
		if ((i >= 'A') && (i <= 'Z'))continue ;
		if (NULL != root->childs[i]) {
			actree_destory_childs (root->childs[i]);
			free (root->childs[i]) ;
			root->childs[i] = NULL ;
		}
	}
	return ;
}

/**销毁对象
 * @ptree 编译好的关键词树
 */
void actree_destory (actree_t *ptree)
{
	if (NULL == ptree) return;
	if (NULL != ptree->root) {
		actree_destory_childs (ptree->root) ;
		free (ptree->root) ;
		ptree->root = NULL ;
	}
	free (ptree) ;
}

/** 查找matcheds结果集中是否包含key
 *@matcheds 结果集
 *@key 查找关键词
 */
static inline int matcheds_haskey(actree_match_t *matcheds, actree_key_t* key)
{
	int i=0;
	for(;i<matcheds->index;i++) {
		if((key->len == matcheds->elements[i].pattern->len) && 0 == memcmp(key->data, matcheds->elements[i].pattern->data, key->len)) {
			return 1;
		}
	}
	return 0;
}

/**申请匹配结果集内存
 * @max 结果集最大个数
 */
actree_match_t* actree_alloc_matchs(uint32_t max)
{
	actree_match_t* item =  (actree_match_t*)calloc(1, sizeof(actree_match_t) + (max * sizeof(actree_match_element_t)));
	item->max = max;
	return item;
}
/**从指定的多模匹配树中搜索关键词
 * @ptree 编译好的关键词树
 * @text 文本字符串
 * @tlen 文本字符串长度
 * @matcheds 匹配到的关键词结果
 * @nmax 允许匹配的最大个数
 * @nmatched 存放结果的位置
 */
int actree_search(actree_t *ptree, unsigned char *text, int tlen, actree_match_t *matcheds, int nreply)
{
	int nmatched = 0;
	register int base_index = 0, cur_index = 0 ;
	register int real_shift = 0, gs_shift = 0, bc_shift = 0 ;
	actree_node_t *node = NULL ;

	if (tlen < ptree->min_pattern_size) goto ret ;
	base_index = tlen - ptree->min_pattern_size ;
	while (base_index >= 0) {
		cur_index = base_index ;
		node = ptree->root ;
		while (NULL != node->childs[text[cur_index]]) {
			node = node->childs[text[cur_index]] ;
			if (node->label >= 0) {
				actree_key_t* key=  (ptree->pattern_list + node->label);
				if(!nreply || !matcheds_haskey(matcheds, key)) {
					if (matcheds->index >= matcheds->max) goto ret ;
					matcheds->elements[matcheds->index].pattern = key;
					matcheds->elements[matcheds->index].offset = base_index ;
					matcheds->index++ ;
					nmatched++;
				}
			}
			cur_index++;
			if (cur_index >= tlen)break;
		}

		if (ptree->style && node->nchild > 0) {
			gs_shift = ptree->gsposition ? ptree->gsposition(node) : 0;
			bc_shift =  (cur_index < tlen) ? (ptree->BCshift[text[cur_index]]+base_index-cur_index) : 1;
			real_shift = gs_shift > bc_shift ? gs_shift : bc_shift;//取大者跳转
			base_index -= real_shift ;
		} else {
			base_index-- ;
		}
	}

ret:
	return nmatched;
}
