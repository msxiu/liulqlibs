/*
 * ac_bm_init.c
 *
 *  Created on: 2015-12-30
 *      Author: Administrator
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "ac_bm.h"
#define IS_NEWLINE(c)		('\r' == (c) || '\n' == (c))


static inline int acbmtree_matched_contains(char *argv[], int argc, char *ks)//argv数组中是否包含ks
{
	int i=0;
	for(;i<argc;i++) {
		if(0 == strcmp(argv[i], ks)) {
			return 1;
		}
	}
	return 0;
}
static  inline void* acbmtree_default_alloc(acbmtree_t *o, size_t size)
{
	return calloc(1, size);
}
static  inline void* acbmtree_buffer_alloc(acbmtree_t *o, size_t size)
{
	if((o->bufpos + size) <  o->buflen) {
		void * item = o->buffer + o->bufpos;
		memset(item, 0, size);
		o->bufpos += size;
		return item;
	}
	return NULL;
}


/** acbm树关键词重置
 * @ptree acbm树
 * @argc 关键词对象个数
 * @argv 关键词对象列表
*/
 void acbmtree_resetkeys (acbmtree_t *ptree, int argc, char* argv[])
{
	 ptree->bufpos = 0;
	pattern_data* patterns = (pattern_data*)ptree->memalloc(ptree, argc * sizeof(pattern_data));
	int i=0, count = 0;
	for(;i<argc;i++) {
		if(chars_is_empty(argv[i])) continue;
		patterns[i].len = strlen(argv[i]);
		if(patterns[i].len >= PATTERN_LEN) {//处理超长的关键词
			GDB_WARNS("key %d:'%s' override length %d:%d;\n", i, argv[i], patterns[i].len, PATTERN_LEN);
			patterns[i].len = PATTERN_LEN-1;
			SET_BUFFER(patterns[i].data, argv[i], patterns[i].len);
		} else {
			strcpy(patterns[i].data, argv[i]);
		}
		count++;
	}
	ACtree_build (ptree, patterns, argc) ;
	ACtree_compute_shifts (ptree) ;
}

acbmtree_t* acbmtree_create(int argc, char* argv[])//初始化AC树
{
	acbmtree_t *ptree = NULL ;
	ptree = (acbmtree_t *) malloc (sizeof (acbmtree_t)) ;
	if (NULL == ptree)  return NULL;
	memset (ptree, 0, sizeof(acbmtree_t)) ;
	ptree->memalloc = acbmtree_default_alloc;
	ptree->buflen =0;

	acbmtree_resetkeys (ptree, argc, argv);
	return ptree;
}

acbmtree_t* acbmtree_initialize(void* buffer, int buflen, int argc, char* argv[])//在指定缓存区初始化AC树
{
	int i=0, count = 0;
	acbmtree_t *ptree = (acbmtree_t *) buffer;
	memset (ptree, 0, sizeof(acbmtree_t)) ;
	ptree->memalloc = acbmtree_buffer_alloc;
	ptree->buflen = (buflen - sizeof(acbmtree_t));

	acbmtree_resetkeys (ptree, argc, argv);
	return ptree;
}


void acbmtree_destory(acbmtree_t *o)//销毁对象
{
	if(!o->buflen)  {
		free(o->pattern_list);
		acbm_clean(o);
	}
}

/**指定节点树进行匹配
 * @o 匹配树对象
 * @text 检测文本
 * @tlen 文本长度
 * @keys 关键词接收缓冲区
 * @nmax 关键词接收缓冲区大小
 * @pos 存放位置
 *@nreply:1去重复,0不去重复
 */
int acbmtree_searchkey(acbmtree_t *o, unsigned char *text, int tlen, char* keys[], int nmax, int pos, int nreply)
{
#define ADDTO_MATCHED(vs, ps, tmp, ln)  if(ln > 0){\
	for(i=0;i<ln;i++) {\
		char * pky = (char *)(pdat + tmp[i].pattern_i)->data;\
		if(ps < (nmax - 1) && !acbmtree_matched_contains(vs, ps, pky)) { vs[ps++] = pky; }\
	}\
}
	matched_info_t matcheds[nmax];
	pattern_data* pdat = o->pattern_list;
	int mi =0, i=0;
	memset(matcheds, 0, (nmax * sizeof(matched_info_t)));
	mi = acbmtree_search(o, text, tlen, matcheds, nmax, pos);
	if(mi > 0) {
		if(nreply) {//去重复关键词
			ADDTO_MATCHED(keys, pos, matcheds, mi);
		} else {
			for(i=0;i<mi;i++) {
				if(pos < (nmax - 1)) {
					keys[pos++] =  (char *)(pdat + matcheds[i].pattern_i)->data;
				}
			}
		}
	}
	return pos;
}


//**************************************************************************
static void* acbmtree_formbuffer(void* buffer, int len)
{
	int argc = 0, ps = 0, i;
	char* argv[1024], *chs = (char*)buffer;
	char* start = chs, c;
	while(ps < len) {
		c = *(chs+ps);
		if(IS_NEWLINE(c)) {
			if(!chars_is_empty(start) && !IS_NEWLINE(*start) && '#' != *start) {
				argv[argc++] = start;
			}
			chs[ps] = 0;
			ps++;
			while(IS_NEWLINE(*(chs+ps))) ps++;
			start = chs+ps;
		}
		ps++;
	}
	if(!chars_is_empty(start) && !IS_NEWLINE(*start) && '#' != *start) {
		argv[argc++] = start;
	}
	return acbmtree_create(argc, argv);
}

void acbmtree_notify_change(struct inotifynode_struct* o, uint32_t t)//acbmtree_t通知改变响应函数
{
	if((t & IN_MODIFY) || (t & IN_DELETE) || (t & IN_CREATE)) {
		if(o->arg) {
			acbmtree_destory((acbmtree_t*)o->arg);
			o->arg = NULL;
		}
		int flen = file_length(o->addr);
		if(flen > 0) {
			 unsigned char *buffer = calloc(1, flen + 2);
			 file_read_tobuffer(o->addr, buffer);
			 o->arg = acbmtree_formbuffer(buffer, flen);
			 free(buffer);
			 GDB_DEBUGS("acbmtree[%p]:'%s', reload to %p;\n", o, o->addr, o->arg);
		} else {
			GDB_DEBUGS("acbmtree[%p]:'%s' file not exists!\n", o, o->addr);
		}
	}
}

int acbmtree_inotify(inotifywatch_t* o)//acbm文件动态通知加载
{
	inotifynode_t* item=o->nodes;
	while(item && item->mask) {
		item->onchange = acbmtree_notify_change;
		item++;
	}
	return inotifywatch_startup(o);
}

int acbmftree_initialize(acbmftree_t* o)//动态加载文件的ACBM缓存
{
	int result = 0;
	filecache_initialize(&(o->cache), o->cache.addr, acbmtree_formbuffer);
	return result;
}
