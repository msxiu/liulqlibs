﻿#ifndef _AC_BM_
#define _AC_BM_
#include "acbm.h"


int ACtree_build (acbmtree_t *ptree, pattern_data *patterns, int npattern) ;
void _clean_tree(pattern_tree_node *root) ;
int ACtree_compute_BCshifts (acbmtree_t *ptree) ;
acbmtree_t *acbm_init (pattern_data *patterns, int npattern) ;
void acbm_clean (acbmtree_t *ptree) ;
int ACtree_compute_shifts(acbmtree_t *ptree) ;
int ACtree_compute_GSshifts(acbmtree_t *ptree) ;
int ACtree_init_GSshifts(acbmtree_t *ptree) ;
int _init_GSshifts(pattern_tree_node *root, int shift) ;
int set_GSshift (acbmtree_t *ptree, unsigned char *pat,  int depth, int shift) ;
int compute_GSshift(acbmtree_t *ptree, unsigned char *pat1, int pat1_len, unsigned char *pat2, int pat2_len) ;

#endif /*_AC_BM_*/
