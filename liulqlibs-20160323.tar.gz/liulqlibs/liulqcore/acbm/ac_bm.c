﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "ac_bm.h"



/** acbm树初始化
 * @ptree 关键词初始化的树节点,即将关键词初始化到该树上
 * @param patterns 关键词对象列表
 * @param npattern 关键词对象个数
 */
int ACtree_build (acbmtree_t *ptree, pattern_data *patterns, int npattern)
{
	int i ;
	pattern_tree_node *root = NULL, *parent = NULL ;
	unsigned char ch ;//当前字符
	int max_pattern_len = 0, min_pattern_len = PATTERN_LEN ;
	if (NULL == ptree || NULL == patterns || npattern < 0) goto err ;
	root = (pattern_tree_node*) ptree->memalloc(ptree, sizeof (pattern_tree_node));
	if (NULL == root)goto err ;
	memset (root, 0, sizeof (pattern_tree_node)) ;

	root->label = -2 ;
	root->depth = 0 ;

	for (i = 0 ; i < npattern ; i++)  {
		int pat_len ;//关键词长度
		int ch_i ;

		pat_len = (patterns+i)->len ;
		if (pat_len == 0) {
			continue ;
		} else {
			if (pat_len > PATTERN_LEN) pat_len = PATTERN_LEN;
			if (pat_len > max_pattern_len) max_pattern_len = pat_len;
			if (pat_len < min_pattern_len) min_pattern_len = pat_len;
			parent = root ;
			for (ch_i = 0 ; ch_i < pat_len ; ch_i++) {
				ch = ((patterns+i)->data)[ch_i] ;
				ch = tolower(ch) ;
				if (NULL == parent->childs[ch]) break ;
				parent = parent->childs[ch] ;
			}
			if (ch_i < pat_len) {//不存在字结点则创建
				for (; ch_i < pat_len ; ch_i++) {//在子节点点下添加新节点
					pattern_tree_node *node = NULL ;
					ch = ((patterns+i)->data)[ch_i] ;
					ch = tolower(ch) ;
					node = (pattern_tree_node *) ptree->memalloc(ptree, sizeof (pattern_tree_node)) ;
					if (node == NULL)goto err ;
					memset (node, 0, sizeof(pattern_tree_node)) ;
					node->depth = ch_i + 1 ;
					node->ch = ch ;
					node->label = -1 ;
					parent->childs[ch] = node ;
					if ((ch >= 'a') && (ch <= 'z')) {//小写转为大写
						parent->childs[ch-32] = node ;
					}
					parent->nchild++ ;
					parent->one_child = ch ;
					node->parent = parent ;

					parent = node ;
				}
			}
		}
		parent->label = i ;// lable 记录字串来自于第几个输入字串
	}

	ptree->pattern_list = patterns ;
	ptree->pattern_count = npattern ;
	ptree->root = root ;
	ptree->max_depth = max_pattern_len ;
	ptree->min_pattern_size = min_pattern_len ;

	return 0 ;

err:// 出错处理,释放申请的空间
	if (ptree->root != NULL) {
		_clean_tree (ptree->root) ;
		free (ptree->root) ;
		ptree->root = NULL ;
	}
	return -1 ;
}



//建立字母首次出现列表
int ACtree_compute_BCshifts (acbmtree_t *ptree)
{
	int i, j = 0 ;
	for (i = 0 ; i < 256 ; i++) {
		ptree->BCshift[i] = ptree->min_pattern_size ;
	}
	for (i = ptree->min_pattern_size - 1 ; i > 0 ; i--) {
		for (j = 0 ; j < ptree->pattern_count ; j++)  {
			unsigned char ch ;
			ch = (ptree->pattern_list+j)->data[i] ;
			ch = tolower(ch) ;
			ptree->BCshift[ch] = i ;
			if ((ch > 'a') && (ch <'z')) {
				ptree->BCshift[ch-32] = i ;
			}
		}
	}
	return 0 ;
}

//计算每个模式串第一个字符的GSshift
int set_GSshift (acbmtree_t *ptree, unsigned char *pat, int depth, int shift)
{
	int i ;
	pattern_tree_node *node ;
	if (NULL == ptree || NULL == ptree->root) goto err ;
	node = ptree->root ;
	for (i = 0 ; i < depth ; i++) {
		node = node->childs[pat[i]] ;
		if (NULL == node)goto err ;
	}
	node->GSshift = ((node->GSshift < shift) ? node->GSshift : shift);
	return 0 ;

err:
	return -1 ;
}

/** 计算每个模式串第一个字符的GSshift
 *@ptree 匹配树
 *@pat1 第一个关键词
 *@pat1_len 第一个关键词的长度
 *@pat2 第二个关键词
 *@pat2_len 第二个关键词的长度
 */
int compute_GSshift (acbmtree_t *ptree, unsigned char *pat1, int pat1_len, unsigned char *pat2, int pat2_len)
{
	unsigned char first_char ;
	int i ;
	int pat1_index, pat2_index, offset ;
	if (NULL == pat1 || NULL == pat2 || pat1_len < 0 || pat2_len < 0) goto err ;
	if (pat1_len == 0 || pat2_len == 0) return 0 ;
	first_char = pat1[0] ;

	first_char = tolower(first_char) ;
	for (i = 1 ; i < pat2_len ; i++) {//跳过与pat1首字母相等字符
		if (tolower(pat2[i]) != first_char) break ;
	}
	set_GSshift (ptree, pat1, 1, i);//计算每个模式串第一个字符的GSshift
	i = 1 ;
	while (1){//i用来的循环，用途？？
		while (i < pat2_len && tolower(pat2[i]) != first_char) i++ ;
		if (i == pat2_len) break ;// pat2剩余字符中未发现有pat1首字符相同字符,结束函数
		if (i > ptree->min_pattern_size) break ;
		offset = pat2_index = i ;
		pat1_index = 0 ;
		while (pat2_index < pat2_len && pat1_index < pat1_len) {//比较pat1是pat2的pat2_index为开始的子串
			if (tolower(pat1[pat1_index]) != tolower(pat2[pat2_index])) break ;
			pat1_index++ ;//是比较位的字符的深度
			pat2_index++ ;
		}
		if (pat2_index == pat2_len) {// 关键字pat1前缀是关键字pat2后缀
			int j ;
			for (j = pat1_index ; j < pat1_len ; j++) {
				set_GSshift (ptree, pat1, j+1, offset) ;
			}
		} else {// pat1的前缀是pat2的子串,被pat2包含
			set_GSshift (ptree, pat1, pat1_index+1, offset) ;//字符所在的深度和序号差一位
		}
		i++ ;
	}
	return 0 ;

err:
	return -1 ;
}

int ACtree_compute_GSshifts (acbmtree_t *ptree)//双重循环调用pattern_list每个关键词
{
	int pat_i = 0, pat_j = 0 ;
	for (pat_i = 0 ; pat_i < ptree->pattern_count ; pat_i++) {
		for (pat_j = 0 ; pat_j < ptree->pattern_count ; pat_j++) {
			unsigned char *ppat_i = (ptree->pattern_list+pat_i)->data ;
			int patlen_i = (ptree->pattern_list+pat_i)->len ;
			unsigned char *ppat_j = (ptree->pattern_list+pat_j)->data ;
			int patlen_j = (ptree->pattern_list+pat_j)->len ;
			compute_GSshift (ptree, ppat_i, patlen_i, ppat_j, patlen_j) ;
		}
	}
	return 0 ;
}


//循环赋值child->GSshift=min_pattern_size
int _init_GSshifts (pattern_tree_node *root, int shift)
{
	int i ;
	if (root->label != -2) root->GSshift = shift;
	for (i = 0 ; i < 256 ; i++) {
		if ((i >= 'A') && (i <= 'Z')) continue;
		if (NULL != root->childs[i]) _init_GSshifts (root->childs[i], shift);
	}
	return 0 ;
}

//循环赋值child->GSshift=min_pattern_size
int ACtree_init_GSshifts (acbmtree_t *ptree)
{
	_init_GSshifts (ptree->root, ptree->min_pattern_size);
	return 0;
}

//编译多模匹配节点树
int ACtree_compute_shifts (acbmtree_t *ptree)
{
	ACtree_compute_BCshifts (ptree) ;//建立字母首次出现列表
	ACtree_init_GSshifts (ptree) ;//循环赋值child->GSshift=min_pattern_size
	ACtree_compute_GSshifts (ptree) ;
	return 0 ;
}

///** acbm树初始化
// * @param patterns 关键词对象列表
// * @param npattern 关键词对象个数
// */
//acbmtree_t *acbm_init (pattern_data *patterns, int npattern)
//{
//	acbmtree_t *ptree = NULL ;
//	ptree = (acbmtree_t *) ptree->memalloc(ptree, sizeof (acbmtree_t)) ;
//	if (NULL == ptree) goto err ;
//	memset (ptree, 0, sizeof(acbmtree_t)) ;
//	ACtree_build (ptree, patterns, npattern) ;
//	ACtree_compute_shifts (ptree) ;
//	return ptree ;
//
//err:
//	return NULL ;
//}

void _clean_tree (pattern_tree_node *root)
{
	int i ;
	for (i = 0 ; i < 256 ; i++) {
		if ((i >= 'A') && (i <= 'Z'))continue ;
		if (NULL != root->childs[i]) {
			_clean_tree (root->childs[i]);
			free (root->childs[i]) ;
			root->childs[i] = NULL ;
		}
	}
	return ;
}


void acbm_clean (acbmtree_t *ptree)
{
	if (NULL == ptree)return;
	if (NULL != ptree->root) {
		_clean_tree (ptree->root) ;
		free (ptree->root) ;
		ptree->root = NULL ;
	}
	free (ptree) ;
}

/**从指定的多模匹配树中搜索关键词
 * @ptree 编译好的关键词树
 * @text 文本字符串
 * @tlen 文本字符串长度
 * @matcheds 匹配到的关键词结果
 * @nmax 允许匹配的最大个数
 * @nmatched 存放结果的位置
 */
int acbmtree_search(acbmtree_t *ptree, unsigned char *text, int tlen, matched_info_t matcheds[], int nmax, int nmatched)
{
	//int nmatched = 0 ;
	register int base_index = 0, cur_index = 0 ;
	register int real_shift = 0, gs_shift = 0, bc_shift = 0 ;
	pattern_tree_node *node = NULL ;

	if (tlen < ptree->min_pattern_size) goto ret ;
	base_index = tlen - ptree->min_pattern_size ;
	while (base_index >= 0) {
		cur_index = base_index ;
		node = ptree->root ;
		while (NULL != node->childs[text[cur_index]]) {
			node = node->childs[text[cur_index]] ;
			if (node->label >= 0) {
				matcheds[nmatched].pattern_i = node->label ;
				matcheds[nmatched].offset = base_index ;
				nmatched++ ;
				if (nmatched == nmax) goto ret ;
			}
			cur_index++;
			if (cur_index >= tlen)break;
		}

		if (node->nchild > 0){
			gs_shift = node->childs[node->one_child]->GSshift ;
			if (cur_index < tlen) {
				bc_shift = ptree->BCshift[text[cur_index]]+base_index-cur_index;
			} else {
				bc_shift = 1 ;
			}
			real_shift = gs_shift > bc_shift ? gs_shift : bc_shift;// 取大者跳转
			base_index -= real_shift ;
		} else {
			base_index-- ;
		}
	}

ret:
	return nmatched ;
}

