#include <liulqsmart.h>
#include "liulqdebug.h"

char stemplate_load(stemplate_t* item, const char *addr, char* master)
{
	const char* pvl,  *temp_s="<master:template id=\"", *temp_e="</master:template>";
	char buffer[128];
	int reslen = 0;
	int temp_sln = strlen(temp_s), temp_eln = strlen(temp_e), tmpln = 0, targetln=0, ipos = 0, vpos=0;
	GDB_DEBUGS("load file '%s';\n", addr);
	int fdlength = file_length(addr);
	if(fdlength <= 0) {
		GDB_ERRORS("get file '%s' size error!\n", addr);
		return 0;
	}
	char fdbuffer[fdlength + 10];
	if(file_read_tobuffer(addr, fdbuffer) <= 0) {
		GDB_ERRORS("load template file '%s' error!\n", addr);
		return 0;
	}
	fdbuffer[fdlength] = 0;
	//membuffer_t *fd = file_read_content(addr);
	pvl = fdbuffer;
	while(char_is_empty(*pvl)) pvl++;
	if(chars_start_with_ignore(pvl, "<%master file=\"")) {
		dbuffer_t dbf;
		dbuffer_initialize(&dbf, 51200, 1024);
		pvl+= 15;
		while(*(pvl + tmpln) != '"') tmpln++;
		if(tmpln == 0) return -1;
		memcpy(master, pvl, tmpln);
		master[tmpln] = 0;
		//GDB_DEBUGS("master:%d=>%s;\n", tmpln, master);
		folder_mappath(addr, master);//map the master
		GDB_DEBUGS("map:%s=>%s;\n", addr, master);
		/*解析调用参数*/
		pvl += tmpln;
		tmpln = 0;
		while(*(pvl+tmpln) != '>') tmpln++;
		if(tmpln > MAX_LEN_PARA) tmpln = MAX_LEN_PARA-1;
		if(tmpln > 0) {
			SET_BUFFER(item->invokepar, pvl, tmpln);
			GDB_MSGL("template invoke parameter %s;\n", pvl, tmpln);
		}

		/*读取母版页内容*/
		GDB_DEBUGS("load master text '%s';\n", master);
		int masterl = file_length(master);
		if(masterl <= 0) {
			GDB_ERRORS("not find master page '%s';\n", master);
			return 0;
		}
		char masters[masterl+10];
		if(file_read_tobuffer(master, masters) <= 0) {
			GDB_WARNS("read master '%s' error!\n", master);
			return 0;
		}
		masters[masterl] = 0;

		pvl = fdbuffer;
		ipos = vpos = 0;
		sfield_t nodes[MAX_TAG_FIELD];
		int nodei=0;
		GDB_DEBUG("parse template nodes;\n");
		/*将调用页内容解析到MAP中*/
		while(vpos < fdlength) {
			if(chars_start_with_ignore(pvl + vpos, temp_s)) {
				sfield_t *node = &nodes[nodei];
				tmpln = 0;
				while(*(pvl + vpos + temp_sln + tmpln) != '"') tmpln ++;
				node->name.start = vpos + temp_sln;
				node->name.length = tmpln;
				//GDB_MSGL("find template node '%s'!\n",  pvl + node->name.start, tmpln);
				vpos +=temp_sln + tmpln + 2;//2:">

				tmpln = 0;
				while(!chars_start_with_ignore(pvl + vpos + tmpln, temp_e)) tmpln++;
				node->value.start = vpos;
				node->value.length = tmpln;
				//string oval(pvl + vpos, tmpln);
				SET_BUFFER(buffer, pvl +  node->name.start, node->name.length);
				//GDB_DEBUGS("[%d:%s]{name:{start:%d,length:%d},value:{start:%d,length:%d}}\n", nodei, buffer, node->name.start, node->name.length, node->value.start, tmpln);
				//GDB_MSGL("\n%s\n", pvl +  node->value.start, node->value.length);
				vpos += tmpln + temp_eln;
				nodei++;
				continue;
			}
			vpos++;
		}

		for(ipos=0;ipos<nodei;ipos++) {
			sfield_t *node = &(nodes[ipos]);
			//GDB_DEBUGS("[%d:%s]{name:{start:%d,length:%d},value:{start:%d,length:%d}}\n", ipos, buffer, node->name.start, node->name.length, node->value.start, tmpln);
		}
		pvl = masters;
		ipos = vpos = 0;
		/*解析母版页,并合入调用页内容*/
		while(vpos < masterl) {
			if(chars_start_with_ignore(pvl + vpos, temp_s)) {
				//GDB_DEBUGS("find template of %d;\n", vpos);
				dbuffer_write(&dbf, pvl + ipos, vpos - ipos);
				tmpln = 0;
				while(*(pvl + vpos + temp_sln + tmpln) != '"') tmpln ++;
				char tempid[tmpln + 10];
				SET_BUFFER(tempid, pvl + vpos + temp_sln, tmpln);
				//GDB_DEBUGS("template of '%s';\n", tempid);

				char findon=1, findi=0;//替换节点数据
				for(;findon && findi<nodei; findi++) {
					sfield_t node = nodes[findi];
					//GDB_MSGL("key:%s;\n", fdbuffer + node.name.start, node.name.length);
					if(buffer_equals(fdbuffer + node.name.start, tempid, node.name.length)) {
						SET_BUFFER(buffer,fdbuffer+node.name.start, node.name.length);
						//GDB_DEBUGS("[%d:%s]{key:{start:%d,length:%d},value:{start:%d,length:%d}};\n", findi, buffer, node.name.start, node.name.length, node.value.start, node.value.length);
						//GDB_MSGL("%s\n", fd->buffer + node.value.start, node.value.length);
						dbuffer_write(&dbf, fdbuffer + node.value.start, node.value.length);
						//GDB_SEPARATOR("template content start");
						//dbuffer_output(&dbf);
						findon=0;
					}
				}

				while(*(pvl + vpos + temp_sln + tmpln) != '>') tmpln ++;
				vpos += (temp_sln + tmpln + 1);
				ipos = vpos;
				continue;
			}
			vpos ++;
			//GDB_DEBUGS("next position:%d;\n", vpos);
		}
		//GDB_SEPARATOR("template file content");
		//printf("%s\n", fdbuffer);
		if(ipos < masterl) {
			GDB_DEBUGS("add template end of {%d:%d}!\n", ipos, masterl - ipos);
			dbuffer_write(&dbf, masters + ipos, masterl - ipos);
		}
		//GDB_SEPARATOR("template content start");
		//dbuffer_output(&dbf);
		//GDB_SEPARATOR("template content finish");
		item->data.addr = (char*)malloc(dbf.bytecnt + 10);
		item->data.length = dbf.bytecnt;//targetln
		dbuffer_read(&dbf, item->data.addr);
		dbuffer_free(&dbf);
	} else {
		item->data.addr =  (char*)malloc(fdlength + 10);
		memcpy(item->data.addr, fdbuffer, fdlength);
		item->data.length = fdlength;//targetln
	}
	//free(fd);
	return item->data.length;
}

//从文件中加载一个模板
stemplate_t* stemplate_invokeofmaster(const char *addr, char *master)
{
	stemplate_t* o = (stemplate_t*)malloc(sizeof(stemplate_t));
	int i = 0, p0 = 0, p1=0, p2=0, tln = 0;;
	char intag =0;
	char* txt;
	if(-1 == stemplate_load(o, addr, master)) {
		GDB_ERRORS("load template '%s' error!\n", addr);
		return NULL;
	}
	GDB_DEBUGS("master:%s;\n", master);
	linked_list_initialize(&(o->tags));
	tln = o->data.length;
	txt = o->data.addr;
	//GDB_SEPARATOR("template content");
	//printf("%s", txt);
	//GDB_SEPARATOR("template parse");
	while(i < tln) {
		if((i+8 < tln) && txt[i] == '<' && buffer_equals(txt + i +1, "server:", 7)) {
				intag =1;
				stag_t *tag = (stag_t*)malloc(sizeof(stag_t));
				memset(tag, 0, sizeof(stag_t));
				tag->outner.start = i;
				//GDB_DEBUGS("find tag of %d;\n", i);
				i+=8;
				tag->tagname.start = p0 = i;
				while(!char_is_empty(txt[i]) && txt[i] != '>') i++;
				tag->tagname.length = (i-p0);
				//GDB_MSGL("tag:%s;\n", txt+tag->tagname.start, tag->tagname.length);
				while(char_is_empty(txt[i])) i++;
				while(txt[i] != '>') {
					p0 = i;
					while(txt[i] != '=') i++;//find field name
					//GDB_MSGL("find field:'%s';\n", txt+p0, i - p0);
					p1 = i;
					char quot = txt[i+1];//“
					//GDB_DEBUGS("quot:'%c';\n", quot);
					i+=2;//跳过引号=“
					p2 = i;
					while(txt[i] != quot && txt[i] != '>') i++;
					if(txt[i] == quot) i++;

					//GDB_DEBUGS("name{%d:%d},value{%d:%d}\n", p0, p1-p0, p2-p0, i-p0);
					stag_field_append(tag, txt + p0, p1-p0, p2-p0, i-p2 - 1);
					while(char_is_empty(txt[i])) i++;
				}
				i++;
				tag->data.addr = txt + i;
				tag->inner.start = i;
				//GDB_DEBUGS("find tag inner of %d/%d;\n", i, tln);
				p0 = i;
				while(intag) {
					if(txt[i] == '<' && txt[i+1] == '/' && buffer_equals(txt + i +2, "server:", 7)) {
						tag->data.length = (i - p0);
						tag->inner.length = (i - p0);
						//GDB_DEBUGS("tag inner length:%d;\n", tag->data.length);
						while(txt[i] != '>') i++;
						tag->outner.finish = ++i;
						//GDB_DEBUGS("outner{%d:%d};\n", tag->outner.start, tag->outner.finish);
						intag = 0;
						continue;
					}
					//printf("%c", txt[i]);
					i++;
				}
				//GDB_DEBUGS("add %d tag by{%d:%d};\n", o->tags.length, tag->outner.start, tag->outner.finish);
				if(stag_field_of(tag, "template") > -1) {
					//GDB_DEBUGS("template %d fields;\n", tag->fldcnt);
					stag_inner_parse(tag);
				}
				linked_list_push(&(o->tags), tag);//tags.push_back(tag);
				//GDB_SEPARATOR("field handle");
			}
			i++;
	}
	o->hastemplate = 1;
	GDB_DEBUGS("'%s' find %d node!\n", addr, o->tags.length);
	return o;
}

stemplate_t* stemplate_initailize(const char *addr)
{
	char master[128];
	return stemplate_invokeofmaster(addr, master);
}
//销毁一个模板对象
void stemplate_destory(stemplate_t* o)
{
	free(o->data.addr);
	linked_list_destory(&(o->tags));
	free(o);
}
//获得调用参数
int  stemplate_param(stemplate_t* o, const char* key, char* val)
{
	if(chars_is_empty(o->invokepar)) return -1;
	int pos = 0, result=-1, kyl=strlen(key), vln=0;
	char k[kyl + 5];
	const char* pori = o->invokepar;
	memset(k, 0, sizeof(k));
	strcpy(k, key);
	k[kyl] = '=';
	k[kyl+1] = 0;
	while(*pori){
		if(chars_start_with(pori, k)){
			pori += (kyl+1);
			while(*pori && *pori != '"') pori++;
			pori++;
			while(*(pori+vln) && *(pori+vln) != '"') vln++;
			memcpy(val, pori, vln);
			val[vln]=0;
			//GDB_DEBUGS("%s:%s;\n", key, val);
			return 0;
		}
		pori++;
	}
	return -1;
}
//获得调用参数
int  stemplate_param_integer(stemplate_t* o, const char* key)
{
	int result = 0;
	char buffer[20];
	memset(buffer, 0, sizeof(buffer));
	if(-1 != stemplate_param(o, key, buffer)) {
		result = atoi(buffer);
	}
	return result;
}

//重置节点列表对象
void stemplate_reset(stemplate_t* o)
{
	//GDB_DEBUGS("stemplate_reset %p:%d;\n", &(o->tags), o->tags.length);
	linked_list_reset(&(o->tags));
}
//是否有下一个节点对象
char stemplate_next(stemplate_t* o)
{
	return linked_list_next(&(o->tags));
}
//模板当前节点与上一个节点之间的数据
char stemplate_fore(stemplate_t* o, vdata_t *v)
{
	int pos = 0;
	seqlink_t *current =o->tags.current;
	stag_t *item = NULL, *prev = NULL;
	if(NULL != current) item = (stag_t*)(current->arg);
	if(NULL != item) {
		if(NULL != current->prev) {
			prev = (stag_t*)(current->prev->arg);
			if(NULL != prev) {
				pos = prev->outner.finish;
			}
		}
		v->addr = (o->data.addr + pos);
		v->length = (item->outner.start - pos);
		return 1;
	}
	return 0;
}
//获得模板的当前实体
stag_t *stemplate_entry(stemplate_t* o)
{
	return (stag_t*)linked_list_entry(&(o->tags));
}
//模板尾数据
char stemplate_last(stemplate_t* o, vdata_t *v)
{
	int pos = 0;//, sl = o.data.length;
	stag_t* item = (stag_t*)((o->tags.last)->arg);
	if(NULL != item) {
		v->addr = (o->data.addr + item->outner.finish);
		v->length = (o->data.length - item->outner.finish);
		return 1;
	}
	return 0;
}
