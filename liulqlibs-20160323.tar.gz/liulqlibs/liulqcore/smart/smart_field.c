#include <liulqsmart.h>

//比较名称是否相等
char sfield_equals(sfield_t *o, const char* name)
{
	int ln = strlen(name);
	if(o->name.length != ln) return 0;
	return buffer_equals(o->addr + o->name.start, name, ln);
}
//获得对象名称,buffer是保存数据的内存地址
char* sfield_name(sfield_t *o, char* buffer)
{
	memcpy(buffer, o->addr + o->name.start, o->name.length);
	return buffer;
}

//获得对象值,buffer是保存数据的内存地址
char* sfield_value(sfield_t *o, char* buffer)
{
	memcpy(buffer, o->addr + o->value.start, o->value.length);
	buffer[o->value.length] = 0;
	return buffer;
}

//获得对象整型值
int sfield_integer(sfield_t *o)
{
	char buffer[20];
	memcpy(buffer, o->addr + o->value.start, o->value.length);
	return atoi(buffer);
}


