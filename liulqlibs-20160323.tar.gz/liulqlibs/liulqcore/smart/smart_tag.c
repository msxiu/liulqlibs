#include <liulqsmart.h>
#include "liulqdebug.h"

//比较与标签名是否相等
char stag_equals(stag_t* o, const char*name)
{
	int ln = strlen(name);
	if(o->tagname.length != ln) return 0;
	return buffer_equals(o->data.addr + o->tagname.start, name, ln);
}
//获得标签名
char *stag_tagname(stag_t* o, char*buffer)
{
	int start = (o->tagname.start - o->inner.start);
	//GDB_MSGL("%s\n", o->data.addr + start, o->tagname.length);
	//GDB_DEBUGS("%d:%d\n", start, o->tagname.length);
	memcpy(buffer, o->data.addr + start, o->tagname.length);
	buffer[o->tagname.length] = 0;
	return buffer;
}
//添加一个字段
char stag_field_add(stag_t* o, sfield_t fld)
{
	if(o->fldcnt < MAX_TAG_FIELD) {
		sfield_t item = o->fields[o->fldcnt++];
		item.addr = fld.addr;
		item.name.start = fld.name.start;
		item.name.length = fld.name.length;
		item.value.start = fld.value.start;
		item.value.length = fld.value.length;
		return 1;
	}
	return 0;
}
//--添加字段
char stag_field_append(stag_t* item, const void* addr, int nlen, int vpos, int vlen)
{
	if(item->fldcnt < MAX_TAG_FIELD -1) {
		sfield_t *o = &item->fields[item->fldcnt];
		o->addr=addr;
		o->name.start=0;
		o->name.length = nlen;
		o->value.start = vpos;
		o->value.length = vlen;
		char buf1[64],buf2[64];
		SET_BUFFER(buf1, o->addr, nlen);
		SET_BUFFER(buf2, o->addr + vpos, vlen);
		//GDB_DEBUGS("%s:{%d:%d},%s{%d:%d};\n", buf1, 0, o->name.length, buf2, o->value.start, o->value.length);
		item->fldcnt++;
	}
	return item->fldcnt;
}

//--包含字段
int  stag_field_of(stag_t* o, const char* name)
{
	//GDB_DEBUGS("field count %d;\n", o->fldcnt);
	if(chars_is_empty(name)) return -1;
	int i=0;
	for(;i<o->fldcnt;i++) {
		//GDB_MSGL("name:%s\n",o->fields[i].addr + o->fields[i].name.start, o->fields[i].name.length);
		if(sfield_equals(&(o->fields[i]), name)) return i;
	}
	return -1;
}
//获得字段值
int  stag_field_value(stag_t* o, const char* name, char* val)
{
	if(chars_is_empty(name)) return -1;
	int i=0;
	for(;i<o->fldcnt;i++) {
		if(sfield_equals(&(o->fields[i]), name)) {
			sfield_value(&(o->fields[i]), val);
			return i;
		}
	}
	return -1;
}
//--获得属性名称
char stag_field_name(stag_t* o, int index, char* name)
{
	if(index < o->fldcnt) {
		sfield_name(&(o->fields[index]), name);
		return 1;
	}
	return 0;
}
//下标字段
char stag_field_value_pos(stag_t* o, int index, char* val)
{
	if(index < o->fldcnt) {
		sfield_value(&(o->fields[index]), val);
		return 1;
	}
	return 0;
}
//获得指定名字的整型值
int  stag_field_integer(stag_t* o, const char* name)
{
	int i=0, result = 0;
	char buffer[20];
	for(;i<o->fldcnt;i++) {
		if(sfield_equals(&(o->fields[i]), name)) {
			sfield_value(&(o->fields[i]), buffer);
			result = atoi(buffer);
			break;
		}
	}
	return result;
}
//--字段个数
int  stag_field_count(stag_t* o)
{
	return o->fldcnt;
}

//内嵌节点解析
int  stag_inner_parse(stag_t* o)
{
	char buffer[20];
	o->indcnt=0;
	int tln= o->inner.length, ts = o->inner.start;
	//GDB_DEBUGS("region{start:%d,length:%d}\n", o->inner.start, o->inner.length);
	const char* original = o->data.addr;//(o->data.addr + ts);

	int i = 0, p0 = 0, p1=0, p2 =0, p3=0;// tln = strlen(original);
	while(i < tln - 5) {
		if(original[i] == '<' && original[i+1] == '%' && original[i+2] == '=') {
			//GDB_DEBUGS("find position:%d;\n", i);

			if(o->indcnt >= MAX_UNIT_FIELD) return -1;
			p0 = i;//<%=
			i+=3;
			while(original[i] == ' ') i++;
			p1 = i;
			while(i <tln) {
				if(original[i] == '%' && original[i+1] == '>'){
					p2=i - 1;
					i+=2;
					p3=i;// %>
					break;
				}
				i++;
			}
			//GDB_DEBUGS("position:%d;\n", i);
			if(p3 < p1) return -1;
			while(original[p2] == ' ') p2--;
			//GDB_DEBUGS("position:%d;\n", p2);
			memset(buffer, 0, sizeof(buffer));
			memcpy(buffer, original + p1, p2-p1 +1);

			stagin_t* item = &(o->inodes[o->indcnt]);
			item->start = ts + p0;//<%=
			item->value = atoi(buffer);
			item->finish = ts + p3;//%>
			//GDB_DEBUGS("%d:{start:%d,finish:%d,value:%d};\n", o->indcnt, item->start, item->finish, item->value);
			//GDB_MSGL("%s\n", o->data.addr + item->start, item->finish - item->start);
			o->indcnt++;
		}
		i++;
	}
	//SET_BUFFER(buffer, o->data.addr + o->tagname.start, o->tagname.length);
	stag_tagname(o, buffer);
	GDB_DEBUGS("inner [%s] find %d nodes!\n", buffer, o->indcnt);
	return o->indcnt;
}

//获得第i个内嵌节点之前内容
char stag_inner_fore(stag_t* o, int i, vdata_t* v)
{
	if(i < o->indcnt) {
		v->addr = (o->data.addr + o->inodes[i].start);
		v->length = (o->inodes[i].finish - o->inodes[i].start);
		return 1;
	}
	return 0;
}
//获得内嵌节点最后内容
char stag_inner_last(stag_t* o, vdata_t* v)
{
	if(o->indcnt > 0) {
		stagin_t c = o->inodes[o->indcnt - 1];
		v->length = (o->data.length - c.finish);
		if(v->length > 0) {
			v->addr = o->data.addr + c.start;
			return 1;
		}
	}
	return 0;
}
//获得第i个内嵌节点值
int  stag_inner_value(stag_t* o, int i)
{
	return (i < o->indcnt ? o->inodes[i].value : 0);
}
//获得内嵌节点个数
int  stag_inner_count(stag_t* o)
{
	return o->indcnt;
}
