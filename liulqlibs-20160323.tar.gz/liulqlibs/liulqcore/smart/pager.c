#include <liulqsmart.h>


char pager_calculation(pager_t* o,  int rcnt, int offset)
{
	o->start=o->end=0;
	o->current = offset;
	o->rcount = rcnt;
	o->total = pager_max(rcnt, o->pgsize);
	if (o->total < 2) return 0;
	if (o->current < 1) o->current = 1;
	if (o->current > o->total) o->current = o->total;//确定当前页
	o->start = o->current - (int)(o->pgrsize / 2);
	if (o->start < 1) o->start = 1;//确定开始页
	o->end = o->start + o->pgrsize - 1;
	if (o->end > o->total) { o->end = o->total; }
	if (o->start + o->pgrsize > o->total) {
		o->start = o->total - o->pgrsize + 1;
		if (o->start < 1) o->start = 1;
	}
	return 1;
}
//--取得最大页码数
int pager_max(int count, int psize)
{
	if (0 == count || psize < 1) return 1;
	int res = (int)(count / psize);
	if ((count % psize) > 0) res += 1;
	return res;
}

