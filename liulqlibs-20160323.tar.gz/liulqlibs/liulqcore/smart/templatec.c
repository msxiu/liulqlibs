#include <liulqsmart.h>
#include "liulqdebug.h"

stemplate_t* stemplate_invokeofmaster(const char *addr, char *master);

//从文件中加载一个模板
char templatec_initialize(templatec_t* o, const char* addr)
{
	memset(o, 0, sizeof(templatec_t));
	strcpy(o->invoke.addr, addr);//复到地址到指定空间
	return 0;
}
stemplate_t* templatec_entry(templatec_t* o)
{
	//GDB_DEBUGS("master:%s;\n", o->master.addr);
	if(fcache_check_timeout(&o->invoke) || (fcache_check_timeout(&o->master))) {
		templatec_free(o);
		o->module = stemplate_invokeofmaster(o->invoke.addr, o->master.addr);
		//GDB_DEBUGS("master:%s;\n", o->master.addr);
		fcache_check_update(&(o->invoke));
		if(!chars_is_empty(o->master.addr)) {
			fcache_check_update(&o->master);
		}
	} else{
		GDB_DEBUGS("'%s':'%s' not modify;\n", o->invoke.addr, o->master.addr);
	}
	return o->module;
}
void templatec_free(templatec_t* o)
{
	if(o->hasmodule) {
		stemplate_destory(o->module);
	}
}

