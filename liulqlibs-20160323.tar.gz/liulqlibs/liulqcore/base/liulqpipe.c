/*
 * api_shared.c
 *
 *  Created on: 2015年11月20日
 *      Author: root
 */
#include <sched.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/select.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <inttypes.h>

#include <liulqcore.h>
#include <liulqdebug.h>


//--命令行字符串执行一个命令
static int pipelistern_execute(pipelistern_t* o, char *line)
{
	int result = 0, pindex=0, argc;
	char *argv[10];//定义命行参数
	if(strlen(line) < 1) return 0;

	while(*(line+pindex)) {
		if(char_is_empty(*(line+pindex))) break;
		pindex ++;
	}
	char *name=line;
	name[pindex] = '\0';
	if(chars_equals_ignore("exit", name)) {
		o->inloop = 0;
		return 0;
	}
	line += pindex + 1;
	argc = parameter_parse(line, sizeof(argv)/sizeof(argv[0]), argv);
	pindex = 0;
	pipexecute_t *cmds = o->commads;//执行命令列表
	while(cmds && cmds->func && cmds->name) {
		pindex++;
		if(chars_equals_ignore(cmds->name, name)) {
			//GDB_DEBUGS("%d:execute %s(%s);\n", ++pindex, name, cmds->name);
			cmds->func(argc, argv);
			result = pindex;
			break;
		}
		cmds++;
	}
	return result;
}

static void*  pipelistern_thread_loop(void* arg)
{
	pipelistern_t* o = (pipelistern_t*)arg;
    char buf[512];
    int fifo_read;
    struct timeval tv;
    fd_set readfs;
    int retval, iread, margc = 128, argc;
	char* argv[margc];
   //pthread_detach(pthread_self(void));

    sprintf(buf, "rm -f %s", o->path);
    retval = system(buf);

    if((mkfifo(o->path, O_CREAT | O_EXCL)  < 0) && (errno != EEXIST)) {
    	GDB_ERROR("connot create fifo server!\n");
    }
    fifo_read = open(o->path, O_RDWR);
    if (fifo_read < 0)  {
    	GDB_ERROR("Can't open pipe!");
        return NULL;
    }
	printf("Named PIPE '%s' server start.\n", o->path);
    while (o->inloop)  {
        tv.tv_sec = 3;
        tv.tv_usec = 0;
        FD_ZERO(&readfs);
        FD_SET(fifo_read, &readfs);
        retval = select(fifo_read + 1, &readfs, NULL, NULL, &tv);
        if (retval <= 0) continue;
        if (FD_ISSET(fifo_read, &readfs)) {
            memset(buf, 0, sizeof(buf));
            iread = read(fifo_read, buf, 512);
            if (iread <= 0) continue;
            //GDB_DEBUGS("'%s' execute -->%s", o->path, buf);
            if(!pipelistern_execute(o, buf)){
            	printf("'%s' bad command or file name!\n", buf);
            }
            fflush(stdout);
        }
    }
    pthread_exit(0);
    return arg;
}

void pipelistern_start(pipelistern_t* o, pipexecute_t *cmds)
{
	o->commads = cmds;
	o->inloop = 1;
	pthread_create(&o->thread, NULL, pipelistern_thread_loop, o);
}

void pipelistern_join(pipelistern_t* o)
{
	pthread_join(o->thread, NULL);
}

