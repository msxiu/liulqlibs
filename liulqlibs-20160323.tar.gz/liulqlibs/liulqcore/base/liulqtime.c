#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <mcheck.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <liulqcore.h>
#include <liulqdebug.h>

//--以不同格式返回系统时间------------------------------------
/**获得当前时间秒*/
time_t get_time_t()
{
	time_t   nowtime;
	time(&nowtime);
	return nowtime;
}
/**获得当前tm结构时间*/
struct tm *get_localtime()
{
	time_t   nowtime;
	time(&nowtime);
	return to_localtime(nowtime);
}
/**将time_t时间转换成tm结构的时间*/
struct tm* to_localtime(time_t t)
{
	struct tm *ntm;
	ntm=localtime(&t);
	return ntm;
}

/**将time_t转换成整型的年月日整数方式,ymd是位或码,1:年,2:月,4:日*/
int time_to_integer_ymd(time_t t, unsigned char ymd)
{
	int result = 0, lx = 1;
    struct tm *ntm = to_localtime(0 == t ? get_time_t() : t);
    if(ymd & 4) {
    	result += ntm->tm_mday;
    	lx*=100;
    }
    if(ymd & 2){
    	result += (ntm->tm_mon + 1) * lx;
    	lx *= 100;
    }
    if(ymd & 1) result += (ntm->tm_year+1900) * lx;
    return result;
}
/**将time_t转换成整型的时分秒整数方式,hms是位或码,1:年,2:月,4:日*/
int time_to_integer_hms(time_t t, unsigned char hms)
{
	int result = 0, lx = 1;
    struct tm *ntm = to_localtime(0 == t ? get_time_t() : t);
    if(hms & 4) {
    	result += ntm->tm_sec;
    	lx*=100;
    }
    if(hms & 2){
    	result += ntm->tm_min * lx;
    	lx *= 100;
    }
    if(hms & 1) result +=ntm->tm_hour * lx;
    return result;
}
/**格式化time_t到字符串缓存中,sl指定字符串长度(仅改文本中部分内容时需指字)*/
char* time_format(time_t t, char* buffer, int sl)
{
	int i=0, tl = 0;
	if(0 == sl) sl = strlen(buffer);
	char c;
	struct tm  itm;
	localtime_r(&t, &itm);
	while(i<sl) {
		c = buffer[i];
		tl = 1;
		switch(c) {
		case 'y':
		case 'Y':
			while(buffer[i+tl] == 'Y' || buffer[i+tl] == 'y') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_year + 1900);
			break;
		case 'M':
			while(buffer[i+tl] == 'M') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_mon + 1);
			break;
		case 'd':
		case'D':
			while(buffer[i+tl] == 'd' || buffer[i+tl] == 'D') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_mday);
			break;
		case 'h':
		case 'H':
			while(buffer[i+tl] == 'h' || buffer[i+tl] == 'H') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_hour);
			break;
		case 'm':
			while(buffer[i+tl] == 'm') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_min);
			break;
		case 's':
		case 'S':
			while(buffer[i+tl] == 's' || buffer[i+tl] == 'S') tl++;
			chars_form_int(buffer + i, 10, tl,  itm.tm_sec);
			break;
		default:
			i++;
			continue;
		}
		i+=tl;
	}
	return buffer;
}

char* local_format(char* buffer, int sl)//格式化当前time_t到字符串缓存中,sl指定字符串长度(仅改文本中部分内容时需指字)
{
	time_t t = get_time_t();
	return time_format(t, buffer, sl);
}
