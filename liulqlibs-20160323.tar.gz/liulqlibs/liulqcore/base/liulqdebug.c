#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <mcheck.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <liulqdebug.h>
#include <liulqcore.h>

gdbentry_t gdbentry;//GDB调试设置对象
static char tmp_buf[MAX_COMMAND_LEN];//缓存命令行参数


//--是否需要输出信息
char gdb_log_allow(int level, const char* fladdr)
{
	char *item;
	if(level <= gdbentry.level) {
		linked_list_t *list = &(gdbentry.filemask);
		linked_list_reset(list);
		while(linked_list_next(list)) {
			item = (char*)linked_list_entry(list);
			if(0 == strcmp(item, fladdr)) return 0;
		}
		return 1;
	}
	return 0;
}
//--打印日志时,显示的文件信息
void gdb_log_printf(const char* fl, int ln)
{
	time_t t = get_time_t();
	int state = 3;
	char stm[30];
	strcpy(stm, "dd HH:mm:ss");
	time_format(t, stm, 0);
	switch(gdbentry.state) {//
	case 1:
		printf("[%s]=>", stm);
		break;
	case 2:
		printf("[%s]%s=>", stm, fl);
		break;
	case 3:
		printf("[%s]%s:%d=>", stm, fl, ln);
		break;
	}
}


//--开启文件调试
void gdb_log_state(char *fladdr, int state)
{
	char hasp=0;
	char* item;
	linked_list_t *list = &(gdbentry.commads);
	linked_list_reset(list);
	while(linked_list_next(list)) {
		item = linked_list_entry(list);
		if(0 == strcmp(item, fladdr)) {
			hasp = 1;
			break;
		}
	}
	if(hasp) {
		if(0 == state) {//开启调试，打印调试信息
			linked_list_remove_current(list);
		}
	} else if(state != 0){//关闭调试,不打印调试信息
		linked_list_push(list, fladdr);
	}
}
/**显示屏蔽调试文件列表*/
void gdb_filemask_show() {
	int pos = 0;
	linked_list_t *list = &(gdbentry.filemask);
	linked_list_reset(list);
	while(linked_list_next(list)) {
		printf("%d:%s;\n", ++pos, (char*)linked_list_entry(list));
	}
}


void gdb_information(int argc, char* argv[])
{
	if(0 == argc){
		printf("debug level:%d, state:%d\n", gdbentry.level, gdbentry.state);
	} else {
		if(0 == strcmp("debug", argv[0]) || 0 == strcmp("4", argv[0])){
			gdbentry.level = D_DEBUG;
		} else if(0 == strcmp("info", argv[0]) || 0 == strcmp("3", argv[0])){
			gdbentry.level = D_INFO;
		} else if(0 == strcmp("warn", argv[0]) || 0 == strcmp("2", argv[0])){
			gdbentry.level = D_WARN;
		}else if(0 == strcmp("error", argv[0]) || 0 == strcmp("1", argv[0])){
			gdbentry.level = D_ERROR;
		}else if(0 == strcmp("exit", argv[0]) || 0 == strcmp("0", argv[0])){
			gdbentry.level = D_EXIT;
		}else if(0 == strcmp("state", argv[0])){
			gdbentry.state = (argc > 1 ? atoi(argv[1]) : 3);
		} else {
			if(argc > 1) {
				int state = 0;
				if(0 == strcmp("disable", argv[1]) || 0 == strcmp("disabled", argv[1])) {
					state = 1;
				} else if (chars_is_numeric(argv[1])) {
					state = atoi(argv[1]);
				}
				gdb_log_state(argv[0], state);
			} else  {
				printf("error parameter '%s'!", argv[0]);
			}
		}
		GDB_WARNS("finish setting level:%d,state:%d\n", gdbentry.level, gdbentry.state);
	}
	if(gdbentry.filemask.length > 0) {
		gdb_filemask_show() ;
	} else {
		printf("not disable gdb file!\n");
	}
}
//输出帮助信息
void gdb_help(int argc, char* argv[])
{
	int nlen = -1, clen;
	gdbcmd_t* item;
	linked_list_t *list = &(gdbentry.commads);
	linked_list_reset(list);
	do {
		item = (gdbcmd_t*)linked_list_entry(list);
		if(NULL != item) {
			clen = 12 - strlen(item->name);//计算补空长度
			nlen = (clen / 4) + (0 == (clen % 4) ? 0 : 1);
			printf("%s", item->name);
			while(nlen--){ printf("\t");}//显示补空
			printf("-- %s\n", item->text);
		}
	} while(linked_list_next(list)) ;
}


//初始化命令行函数
void gdbentry_initialize()
{
	linked_list_initialize(&(gdbentry.commads));
	linked_list_initialize(&(gdbentry.filemask));

	gdbentry_function(gdb_help, "?", "show help information!");
	gdbentry_function(gdb_help, "help", "show help information!");
	gdbentry_function(gdb_information, "gdb", "show or set gdb debug lebel information!");
}
//销毁
void gdbentry_destory()
{
	linked_list_destory(&(gdbentry.commads));
	linked_list_destory(&(gdbentry.filemask));
}
//--添加命令
void gdbentry_function(gdbfunc_t cmd, const char *label, const char* text)
{
	gdbcmd_t* o = (gdbcmd_t*)malloc(sizeof(gdbcmd_t));
	o->func = cmd;
	o->name = label;
	o->text = text;
	linked_list_push(&(gdbentry.commads), o);
}
//--命令行字符串执行一个命令
int gdbentry_execute(char *line)
{
	int result = -1, pindex=0, argc;
	char *argv[10];//定义命行参数
	if(strlen(line) < 1) return 0;

	while(*(line+pindex)){
		if(*(line+pindex) == ' ' || *(line+pindex) == '\t') break;
		pindex ++;
	}
	char name[pindex+1];
	memcpy(name, line, pindex);
	name[pindex] = '\0';
	line += pindex;

	strcpy(tmp_buf, line);
	argc = parameter_parse(tmp_buf, sizeof(argv)/sizeof(argv[0]), argv);

	pindex = 0;

	gdbcmd_t* item;
	linked_list_t *list = &(gdbentry.commads);
	linked_list_reset(list);
	do {
		item = linked_list_entry(list);
		if(NULL != item) {
			if(0 == strcmp(item->name, name)){
				result = pindex;
				item->func(argc, argv);
				LINEFLAG();
				break;
			}
			pindex ++;
		}
	}while(linked_list_next(list));
	return result;
}
/**分解命令参数*/
int parameter_parse(char *s, int argvsz, char *argv[])
{
	int argc = 0;
	while (argc < argvsz - 1) {
		while ((*s == ' ') || (*s == '\t') || (*s == '\r') || (*s == '\n')) ++s;
		if (*s == '\0')	break;
		argv[argc++] = s;
		while (*s && (*s != ' ') && (*s != '\t') &&  (*s != '\r') && (*s != '\n')) ++s;
		if (*s == '\0') break;
		*s++ = '\0';
	}
	argv[argc] = NULL;
	return argc;
}
