#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

#include <liulqcore.h>
#include <liulqdebug.h>

char file_exists(const char* addr)
{
    if(access(addr, F_OK) == -1) return  0;
    if(access(addr, R_OK) == -1) return 0;
	struct stat statbuf;
	if(stat(addr, &statbuf) == -1){
		GDB_ERRORS("get file '%s' state fail!\n", addr);
		return 0;
	}
	if(statbuf.st_mode & S_IFDIR) return 0;
	return 1;
}
long file_length(const char* addr)
{
    if(access(addr, F_OK) == -1) return -1;
    if(access(addr, R_OK) == -1) return -1;
	struct stat statbuf;
	if(stat(addr, &statbuf) == -1){
		GDB_ERRORS("get file '%s' state fail!\n", addr);
		return -1;
	}
	if(statbuf.st_mode & S_IFDIR) return -1;
	return (long)statbuf.st_size;
}
/*获得文件的最后修改时间*/
time_t file_last_modify(const char * addr)
{
	assert(NULL != addr);
	assert(*addr != 0);
	struct stat statbuf;
	if(stat(addr, &statbuf) == -1){
		GDB_ERRORS("get file '%s' state fail!\n", addr);
		return 0;
	}
	return (time_t)statbuf.st_mtim.tv_sec;
}

struct timespec file_lastmodify(const char * addr)//获得文件的最后修改时间
{
	assert(NULL != addr);
	assert(*addr != 0);
	struct timespec res = { .tv_sec=0, .tv_nsec=0 };
	struct stat statbuf;
	if(stat(addr, &statbuf) == -1){
		GDB_ERRORS("get file '%s' state fail!\n", addr);
	} else {
		res = statbuf.st_mtim;
	}
	return res;
}

//检测是否为今天数据
char file_cache_istoday(const char* addr)
{
	time_t fitm = file_last_modify(addr), nitm =get_time_t() ;
	int fd = time_to_integer_ymd(fitm,7)  , nd=time_to_integer_ymd(nitm, 7);
	//int fd = fitm / 86400,nd=nitm / 86400;
	return (fd == nd ? 1 : 0);
}
//检测是否为今年数据
char file_cache_isyear(const char* addr)
{
	time_t fitm = file_last_modify(addr), nitm =get_time_t() ;
	//int fd = fitm / (86400*365),nd=nitm / (86400*365);
	int fd = time_to_integer_ymd(fitm,1)  , nd=time_to_integer_ymd(nitm, 1);
	//GDBMSGS(GDB_DEBUG, "year equals:%d=%d, sec:%d=%d;\n", fd,  nd, fitm, nitm);
	return (fd == nd ? 1 : 0);
}

char file_write_content(const char* addr, const unsigned char* buffer, unsigned int flen)
{
	FILE *fp;
	fp = fopen(addr, "wb");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return 0;
	}
	int wlen = fwrite(buffer, 1, flen, fp);
	fclose(fp);
	return (wlen == flen ? 1 : 0);
}
//--读取文件内容
membuffer_t * file_read_content(const char* addr)
{
	FILE *fp;
	membuffer_t* o;
	int rlen, flen=0;
	fp = fopen(addr, "rb");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return NULL;
	}
	fseek(fp, 0L, SEEK_END);
	flen = ftell(fp);
	o = membuffer_alloc(flen);
	if(NULL == o){
		GDB_ERROR("file_read_content apply memory fail!\n");
		return NULL;
	}
	fseek(fp, 0L, SEEK_SET);

	rlen = fread(o->buffer, 1, flen, fp);
	fclose(fp);
	if(rlen != flen) {
		membuffer_free(o);
		return NULL;
	}
	return o;
}
long file_read_tobuffer(const char*addr, void* buffer)
{
	FILE *fp;
	int rlen, flen=0;
	fp = fopen(addr, "rb");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	fseek(fp, 0L, SEEK_END);
	flen = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	rlen = fread(buffer, 1, flen, fp);
	fclose(fp);

	if(rlen != flen) {
		GDB_ERRORS("'%s' read length(%d:%d) error!!\n", addr, flen, rlen);
		return -1;
	}
	return rlen;
}
int file_read_top_chars(const char* addr, void *buffer, int len)
{
	FILE *fp;
	int rlen;
	fp = fopen(addr, "rb");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	rlen = fread(buffer, 1, len, fp);
	fclose(fp);
	return rlen;
}
int file_write(const char* addr, void* buffer, int len)//覆盖方式打开写文件
{
	FILE *fp;
	int rlen;
	fp = fopen(addr, "wb+");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	rlen = fwrite(buffer, 1, len, fp);
	fclose(fp);
	return rlen;
}
int file_addbuffer(const char* addr, void* buffer, int len)//追加方式打开写文件
{
	FILE *fp;
	int rlen;
	fp = fopen(addr, "ab+");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	rlen = fwrite(buffer, 1, len, fp);
	fclose(fp);
	return rlen;
}
int file_logger(const char* addr, void* buffer, int len)//追加日志方式打开写文件
{
	FILE *fp;
	int rlen;
	char logs[] = "---------[yyyy-MM-dd HH:mm:ss]-----------------------------------\r\n";
	fp = fopen(addr, "ab+");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", addr);
		return -1;
	}
	local_format(logs, 0);
	fwrite(logs, 1, sizeof(logs), fp);
	rlen = fwrite(buffer, 1, len, fp);
	fwrite("\r\n", 1, 2, fp);
	fclose(fp);
	return rlen;
}
//--文件状态
long file_size(const char *addr)
{
    if(access(addr, F_OK) == -1) return -1;
    if(access(addr, R_OK) == -1) return -1;
	struct stat statbuf;
	if(stat(addr, &statbuf) == -1){
		GDB_ERRORS("get file '%s' state fail!\n", addr);
		return -1;
	}
	if(statbuf.st_mode & S_IFDIR) return -1;
	return (int)statbuf.st_size;
}

int file_delete(const char* addr)//删除一个文件
{
	int result = (int)file_size(addr);
	if(-1 != result) {
		result = remove(addr);
	}
	return result;
}
/**文件行回调处理
 *@parameter addr:文件地址
 *@parameter linecallback:行回调处理函数
 */
int file_linecallback(const char* addr, void (* linecallback)(const char*))
{
#define MAX_LINE		4096
	int lns = 0, lne = 0, lpl = 0, lps = 1;
	int ret = 0, sln;
	char *line = malloc(MAX_LINE);
	FILE *fp = fopen(addr, "rb");
	if(NULL == fp) {
		printf("open file '%s' error!\n", addr);
		return ret;
	}
	while(!feof(fp)) {
		fgets(line, MAX_LINE, fp);
		lps = buffer_readline(line, &lns, &lne);
		if(lne > 0 && '#' != line[lns]) {
			line[lne] = 0;
			linecallback(line+lns);
			ret ++;
		}
	}
	free(line);
	fclose(fp);
	return ret;
}
//int file_linecallback(const char* addr, void (* linecallback)(const char*))
//{
//	int lns = 0, lne = 0, lpl = 0, lps = 1;
//	int ret = 0, sln, fln = file_size(addr);
//	char line[1024], *buffer;
//	if(fln <= 0) return ret;
//
//	sln = fln + 10;
//	buffer = (char*) malloc(sln);
//	if(NULL != buffer) {
//		memset(buffer, 0, sln);
//		file_read_tobuffer(addr, buffer);
//		while(lps) {
//			lps = buffer_readline(buffer + lpl, &lns, &lne);
//			if(lne > 0) {
//				SET_BUFFER(line, buffer + lpl + lns, lne);
//				linecallback(line);
//				ret ++;
//			}
//			lpl += lps;
//		}
//		free(buffer);
//	} else {
//		printf("allocate memory error!\n");
//	}
//	return ret;
//}





int folder_delete(const char* destDir)//删除一个目录
{
    DIR *dp;
    struct dirent *entry;
    struct stat statbuf;
    if ((dp = opendir(destDir)) == NULL) {
    	GDB_ERRORS("cannot open directory: %s\n", destDir);
        return -1;
    }
    chdir (destDir);
    while ((entry = readdir(dp)) != NULL) {
        lstat(entry->d_name, &statbuf);
        if (S_ISREG(statbuf.st_mode)) {
            remove(entry->d_name);
        }
    }
    return 0;
}
char* folder_mappath(const char* original, char* addr)
{
	int sln = strlen(addr) + 10, oln = strlen(original) - 1;
	char tmp[sln], *pstr;
	while(oln && original[oln] != '/') oln--;
	if(oln <= 0) return NULL;
	strcpy(tmp, addr);
	pstr = tmp;
	if(pstr[0] == '.' && pstr[1] == '/') pstr += 2;
	while(pstr[0] == '.' && pstr[0] == '.' && pstr[2] == '/')  {
		oln--;
		while(oln && original[oln] != '/') oln--;
		pstr+=3;
	}
	//GDB_DEBUGS("oln:%d,file:'%s';\n", oln, pstr);
	if(oln <= 0) return NULL;
	memcpy(addr, original, oln+1);
	strcpy(addr+oln+1, pstr);
	GDB_DEBUGS("result:'%s';\n", addr);
	return addr;
}

int iniconfig_load(const char* fname, ini_item parse_item, void* par)
{
	int rlen = -1, flen;
	char *curstart, *buffer;
	FILE *fp;

	fp = fopen(fname, "r");
	if(NULL == fp) {//打开文件失败
		GDB_ERRORS("'%s'file not exists!\n", fname);
		goto laberr;
	}
	fseek(fp, 0L, SEEK_END);
	flen = ftell(fp);

	buffer = (char*)calloc(1, flen + 10);
	if(NULL == buffer){
		fclose(fp);
		GDB_ERROR("iniconfigure alloc memory fail!\n");
		goto laberr;
	}
	fseek(fp, 0L, SEEK_SET);
	rlen = fread(buffer, 1, flen, fp);
	fclose(fp);

	curstart = buffer;
	while(curstart < buffer + rlen) {
		int length=0, alength = 0;
		while(*(curstart + alength) != '\n' && *(curstart + alength) != '\0') alength++;
		if(0 == alength) {
			curstart ++;
			continue;
		}
		//GDB_MSGL(curstart, alength);
		for(length = 0;length<alength;length++){
			if(*(curstart+length) == '#') break;
		}
		if(length > 0 && ('#' != *curstart)){
			char *kstart = curstart, *vstart;
			while(char_is_empty(*kstart)) kstart++;
			int klen = 0, vlen = 0;
			while(klen < length){ if((*(kstart+(klen++))) == '=') break; }
			if(klen == length){//没有找到=的情况
				char line[length + 1];
				memcpy(line, curstart, length);
				line[length] = '\0';
				//GDB_INFOS("parse error of '%s'!\n", line);
			} else {
				vstart = kstart+klen;
				klen--;
				while(char_is_empty(*(kstart+klen-1))) klen--;

				while(char_is_empty(*vstart)) vstart++;
				vlen = (curstart + length) - vstart;
				while(char_is_empty(*(vstart+vlen-1))) vlen--;

				//GDB_DEBUGS("%p:%d,%p:%d;\n", kstart, klen, vstart, vlen);
				parse_item(par, kstart, klen, vstart, vlen);
			}
		}
		curstart += alength + 1;
	}
	free(buffer);

laberr:
	return rlen;
}
