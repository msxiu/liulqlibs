#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <signal.h>
#include <mcheck.h>

#include <liulqcore.h>
#include "liulqdebug.h"

/*GDB方式获得异常堆栈信息*/
void gdb_dump_invoke(int signo)
{
	char buf[1024];
	char cmd[1024];
	FILE* fh;
	snprintf(buf, sizeof(buf), "/proc/%d/cmdline", getpid());
	if(!(fh = fopen(buf, "r"))) exit(0);
	if(!fgets(buf, sizeof(buf), fh)) exit(0);
	fclose(fh);

	if(buf[strlen(buf-1)]) buf[strlen(buf) - 1] = 0;
	snprintf(cmd, sizeof(cmd), "gdb %s %d", buf, getpid());
	system(cmd);
	exit(0);
}
/*内存泄漏跟踪开始*/
void gdb_mtrace_start(const char* addr)
{
	setenv("MALLOC_TRACE", addr, 1);
	mtrace();
}
/*内存泄漏跟踪结束,一般不需要使用*/
void gdb_mtrace_finish()
{
	muntrace();
}

/*启动GDB方式异常堆栈跟踪信息*/
void gdb_dump_start()
{
	signal(SIGSEGV, &gdb_dump_invoke);
}

/*非GDB方式获得异常堆栈信息*/
void dump_backtrace_invoke(int signo)
{
	void *array[10];
	size_t size;
	char **strings;
	size_t i;
	size = backtrace (array, 10);
	strings = (char **)backtrace_symbols (array, size);
	printf ("Obtained %zd stack s.\n", size);
	for (i = 0; i < size; i++) printf ("%s\n", strings[i]);
	free (strings);
	exit(0);
}
/*启动非GDB方式异常堆栈跟踪信息*/
void dump_backtrace_start()
{
	signal(SIGSEGV, &dump_backtrace_invoke);
}


