#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <liulqcore.h>
#include <liulqdebug.h>

//--是否为空
char buffer_is_null(const unsigned char*buffer, unsigned int len)
{
	int i=0;
	for(;i<len;i++) if(buffer[i] != 0) return 0;
	return 1;
}

/**从addr缓存中读取一行
 *@parametet addr(in):查找行的数据开始地址
 *@parametet start(out):接收有效数据开始位置
 *@parametet len(out):接收有效数据长度
 *@return 返回下以行位置
 */
int buffer_readline(const char* addr, int* start, int* len) {
	int result = 0;
	const char* s=addr;
	*start=*len=0;
	while(*s) {
		result++;
		if (*s == '\n') break;
		s++;
	}
	if(result > 1) {
		*len = result;
		while(char_is_empty(*s--) && *len)  (*len)--;
		s=addr;
		while(char_is_empty(*s++))  (*start)++;
	}
	return result;
}

//--查找行结尾位置
int buffer_line_length(const char *s)
{
	int pos = 0;
	while(s[pos] != '\n' && s[pos] != '\0') pos++;
	return pos;
}
//--判断缓存是否相等
char buffer_equals(const void*a, const void* b, unsigned int len)//比较内存数据是否相等
{
	unsigned char *a1 = (unsigned char*)a,*b1 = (unsigned char*)b;
	int i=0;
	for(;i<len;i++) if(a1[i] != b1[i]) return 0;
	return 1;
}
char buffer_equals_ignore(const void*a1, const void* b1, unsigned int len)//比较内存数据是否相等
{
	int i=0;
	unsigned char *a = (unsigned char*)a1,*b = (unsigned char*)b1, ac, bc;
	for(i=0; i<len; i++){
		ac = a[i], bc = b[i];
		if(ac >= 65 && ac <= 90) ac += 32;
		if(ac != bc) return 0;
	}
	return 1;
}
char equals_ignore(char a, char b)
{
	if(a >= 65 && a <= 90) a += 32;
	if(b >= 65 && b <= 90) b += 32;
	return (a == b);
}
int buffer_indexof(const char*a, const char* b, int offset, int mx)//查找b在a出现的位置,offset是偏移位置
{
	int i=offset, sln = strlen(b);
	while(i < mx) {
		if(buffer_equals(a+i, b, sln)) return i;
		i++;
	}
	return -1;
}
//******************************************************************************
//--a是否b开头
char chars_start_with(const char* a, const char* b)
{
	int i=0, ln = strlen(b);
	for(i=0; i<ln; i++){
		if(a[i] != b[i]) return 0;
	}
	return 1;
}
//--a是否b开头,忽略大小写比较
char chars_start_with_ignore(const char* a, const char* b)
{
	int i=0, ln = strlen(b);
	char ac, bc;
	for(i=0; i<ln; i++){
		ac = a[i], bc = b[i];
		if(ac >= 65 && ac <= 90) ac += 32;
		if(ac != bc) return 0;
	}
	return 1;
}
char chars_end_with(const char* a, const char* b)//--a是否b结尾
{
	int i=0, lan= strlen(a) - 1, lbn = strlen(b) - 1;
	if(lan < lbn) return 0;
	for(i=0; i<lbn; i++){
		if(a[lan - i] != b[lbn - i]) return 0;
	}
	return 1;
}
char chars_end_with_ignore(const char* a, const char* b)//--a是否b结尾,忽略大小写比较
{
	int i=0, lan= strlen(a) - 1, lbn = strlen(b) - 1;
	if(lan < lbn) return 0;
	char ac, bc;
	for(i=0; i<lbn; i++) {
		ac = a[lan - i], bc = b[lbn - i];
		if(ac >= 65 && ac <= 90) ac += 32;
		if(ac != bc) return 0;
	}
	return 1;
}
int chars_indexof(const char*a, const char* b, int offset)//查找b在a出现的位置,offset是偏移位置
{
	int i=offset, sln = strlen(b);
	while(*(a+i)) {
		if(buffer_equals(a+i, b, sln)) return i;
		i++;
	}
	return -1;
}
int chars_indexof_ignore(const char*a, const char* b, int offset)//查找b在a出现的位置,offset是偏移位置
{
	int i=offset, sln = strlen(b);
	while(*(a+i)) {
		if (buffer_equals_ignore(a+i, b, sln)) return i;
		i++;
	}
	return -1;
}
char chars_equals(const char* a, const char* b)
{
	int i=0, ln = strlen(b), aln = strlen(a);
	if(ln != aln) return 0;
	for(i=0; i<ln; i++){
		if(a[i] != b[i]) return 0;
	}
	return 1;
}
char chars_equals_ignore(const char*a, const char* b)
{
	int i=0, ln = strlen(b), aln = strlen(a);
	if(ln != aln) return 0;
	char ac, bc;
	for(i=0; i<ln; i++){
		ac = a[i], bc = b[i];
		if(ac >= 65 && ac <= 90) ac += 32;
		if(ac != bc) return 0;
	}
	return 1;
}
char buffer_is_numeric(const void* b, int ln)//--判断是否为数字
{
	const char* s = (const char*)b;
	int i=0;
	if (NULL == s || 0 == *s) return 0;
	for(; i<ln; i++) {
		if(s[i] < '0' || s[i] > '9') return 0;
	}
	return 1;
}
//--判断是否为数字
char chars_is_numeric(const char* s)
{
	return buffer_is_numeric(s, strlen(s));
}
//--判断字符串是否为空
char chars_is_empty(const char* s)
{
	return ((NULL == s || 0 == *s) ? 1 : 0);
}
//--判断字符是否为空字符
char char_is_empty(char c)
{
	return ((c == 0 || c == 32 || c == '\v' || c == '\t' || c == '\r' || c == '\n') ? 1 : 0);
}
/** 解析字符串到整型
 * buffer:字符串缓存
 * hex:表示进制(8:10:16)
 * result:结果保存缓存*/
int chars_to_int(const char *buffer, unsigned char hex, int* result)
{
	int ret = 0,px=1, sl = strlen(buffer);
	while(sl) {
		char c = buffer[--sl];
		int i = -1;
		if(c >= 'a' && c <= 'f') {
			i = (c - 'a') + 10;
		} else if(c >= 'A' && c <= 'F') {
			i = (c - 'A') + 10;
		} else if(c >= '0' && c <= '9') {
			i = c - '0';
		} else {
			return -1;
		}
		ret += (i * px);
		px*=hex;
	}
	*result = ret;
	return 0;
}
/** 解析缓存中的字符为一个十进制整数 */
int to_integer(const char* buffer)
{
	int result = 0;
	chars_to_int(buffer, 10, &result);
	return result;
}
/**将一个整数按指的进制转换成字符串;
 * buffer:结果缓存
 * hex:进制
 * width:结果字符串的长度,不够前补0,为0表示整形全长
 * val:要转换的值*/
int chars_form_int(char *buffer, unsigned char hex, unsigned char width, int val)
{
	char tmp[20];
	bzero(tmp, sizeof(tmp));
	int i=0, m;
	tmp[0] = '\0';
	while(val){
		m = val % hex;
		tmp[i] = '0'+m;
		val = val / hex;
		i++;
	}
	if(0 == width) width = (0 == i ? 1 : i);
	i=0;
	while(i<width) {
		char c = tmp[width - i - 1];
		buffer[i] = (0 == c ? '0' : c);
		i++;
	}
	return width;
}
/**将一个整数i转换成字符串保存到buffer中*/
char* to_chars(char* buffer, int i)
{
	chars_form_int(buffer, 10, 0, i);
	return buffer;
}
/**将字符c转换成十六进制的两个字符保存到buffer中*/
void char_form_hex(char* buffer, unsigned char c)
{
	unsigned char a =  (c>>4)&0x0F, b = c&0X0F;
	buffer[0] = (a>9) ? ('A'+(a-10)) : ('0'+a);
	buffer[1] = (b>9) ? ('A'+(b-10)) : ('0'+b);
}
/**将data中的数据以十六制字符方式保存到buffer中，len是data的长度*/
void chars_form_hex(char *buffer, const void* data, int len)
{
	int i=0;
	unsigned char* bys = (unsigned char*)data;
	char tmp[len*2+1];
	memset(tmp, 0, sizeof(tmp));
	for(;i<len;i++) {
		char_form_hex(tmp+(i*2), bys[i]);
	}
	strcpy(buffer, tmp);
}

/**将buffer中两位十六进制字符,还原成数值,并返回*/
short char_to_hex(const char* data)
{
	short a =((data[0] >= 'A') ? 10 + (data[0] - 'A')  : 0 +  (data[0] - '0')),
			b = ((data[1]>='A') ?10 + (data[1] - 'A') : 0 + (data[1] - '0'));
	return (a<<4|b);
}
/**将buffer中的十六进制字符串,还原数据到data中*/
int chars_to_hex(void* buffer, const char* data)
{
	int i=0,sl = strlen(data), vl = (sl / 2);
	if((sl %2) != 0) return -1;
	//unsigned char *bys = (unsigned char*)buffer;
	unsigned char bys[vl];
	for(;i<=vl; i++) {
		bys[i] = (unsigned char)char_to_hex(data + (i*2));
	}
	memcpy(buffer, bys, vl);
	return vl;
}

/**将s中的字符转换成小写并考贝到buffer中*/
char* cpyto_lower(char*buffer, const char*s)
{
	do {
		*buffer++ = (*s>='A' && *s <= 'Z' ? *s +32 : *s );
	}while(*s++) ;
	return buffer;
}
/**将s中的字符转换成小写并考贝到buffer中,sln指定转换长度,超出长度的不转换*/
char* cpyto_lower_part(char*buffer, const char*s, int sln)
{
	do {
		*buffer++ = (*s>='A' && *s <= 'Z' ? *s +32 : *s );
	}while(--sln&&*s++) ;
	*buffer = 0;
	return buffer;
}
/**将s中的字符转换成大写并考贝到buffer中*/
char* cpyto_upper(char*buffer, const char*s)
{
	 do {
		*buffer++ = (*s>='a' && *s <= 'z' ? *s -32 : *s );
	}while(*s++);
	return buffer;
}
/**将s中的字符转换成大写并考贝到buffer中,sln指定转换长度,超出长度的不转换*/
char* cpyto_upper_part(char*buffer, const char*s, int sln)
{
	 do {
		*buffer++ = (*s>='a' && *s <= 'z' ? *s -32 : *s );
	}while(--sln&&*s++);
	 *buffer = 0;
	return buffer;
}



int chars_contact(char *matcheds[], int nmax, char* result, int bufsize, const char const* flag)//连接字符串数组到一个缓存
{
	int i=0, pos = 0, cln, fln = (NULL == flag ? 0 : strlen(flag));
	for(;i<nmax;i++) {
		cln = (NULL == matcheds[i] ? 0 : strlen(matcheds[i]));
		if(cln <= 0) continue;
		if((pos + fln + cln) >= bufsize) break;//超出允许的最大长度
		if(pos) {
			memcpy(result + pos, flag, fln);
			pos += fln;
		}
		memcpy(result + pos, matcheds[i], cln);
		pos += cln;
	}
	return pos;
}
