/*
 * sigalrms.c
 *
 *  Created on: 2016年1月18日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include "liulqcore.h"

static int timer_second = 1;
static sigtimer_t *signalexecs;//定时器的执行函数列表


static void sigalrm_execute(int sig)
{
	static int exe_count = 0;
	alarm(timer_second);
	GDB_INTEGER_ADD(exe_count);
	sigtimer_t *item = signalexecs;
	while(NULL != item) {
		if(NULL != item->func) item->func(exe_count);
		item = item->next;
	}
}


void sigtimer_start(int second)//启动定时器
{
	timer_second = second;
	signal(SIGALRM, sigalrm_execute);
	alarm(timer_second);
}
void sigtimer_add_start(sigtimer_cbk cbk, int second)//添加定时函数并启动定时器
{
	sigtimer_add(cbk);
	sigtimer_start(second);
}
void sigtimer_add(sigtimer_cbk cbk)//添加定时函数
{
	sigtimer_t* item = calloc(1, sizeof(sigtimer_t));
	item->func = cbk;
	if(NULL == signalexecs) {
		signalexecs = item;
	} else {
		item->next = signalexecs;
		signalexecs = item;
	}
}
void sigtimer_remove(sigtimer_cbk cbk)//删除定时函数
{
	sigtimer_t *item = signalexecs, *prev, *p1;
	prev = NULL;
	while(NULL != item) {
		if(cbk == item->func) {
			p1 = item->next;
			free(item);
			if(NULL == prev) {
				signalexecs = p1;
			} else {
				prev->next = p1;
			}
		} else {
			prev = item;
		}
	}
}

void sigtimer_destory(void)
{
	sigtimer_t *item = signalexecs, *p1;
	while(NULL != item) {
		p1 = item->next;
		free(item);
		item = p1;
	}
}
