/*
 * regexmatch.c
 *
 *  Created on: 2016年2月2日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <pcre.h>
#include "liulqcore.h"
#include "liulqdebug.h"

#define OVECCOUNT		30
#define MIN(a,b)		(a<b?a:b)



/** 正则表达式解析
 *@src 原字符串
 *@pattern 正则
 *@ovector 接收数据
 *@maxln 最大接收个数
 */
int regexpattern_parse(const char* src, const char* pattern, vsegment_t* ovector, int maxln)
{
	const char* err;
	int erroffset, rc, i = 0;
	//int ovector[OVECCOUNT];
	pcre* re = pcre_compile (
			pattern,//in:正则表达式字符串
			0,//in:编译选项
			&err,//out:输出错误信息
			&erroffset,//out:出错位置偏移
			NULL//in:指定字符表,一般为NULL
	);
	if(NULL == re) {
		GDB_DEBUGS("PCRE compilation failed at offset %d:%s\n", erroffset, err);
		return -1;
	}
	rc = pcre_exec(
		re,//in:编译好的正则结构体指针
		NULL,//in:额外数据结构指针
		src,//in:匹配字符串
		strlen(src),//in:字符串长度
		0,//in:匹配偏移
		0,//in:匹配过程选项
		(int*)ovector,//out:匹配位置偏移数组
		maxln*2//out:最大个数
	);
	pcre_free(re);

	if(rc < 0) {
		if(rc != PCRE_ERROR_NOMATCH) {
			GDB_DEBUGS("Matching error %d;\n", rc);
			return -1;
		}
		return 0;
	}
	return rc;
}

/** 从正则中匹配指定下标数据
 * @src 原数据
 * @pattern 正则表大式
 *@index 下标
 *@v 接收数据对象
 */
int regexpattern_match(const char* src, const char* pattern, int index, vdata_t *v)//正则匹配数据
{
	vsegment_t ovector[OVECCOUNT];
	int result = regexpattern_parse(src, pattern, ovector, OVECCOUNT);
	if(index < result) {
		vsegment_t ri = ovector[index];
		v->addr = (char*)(src + ri.start);
		v->length = ri.finish - ri.start;
		return 1;
	}
	return 0;
}

