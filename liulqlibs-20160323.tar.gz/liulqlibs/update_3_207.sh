scp -rp root@192.168.3.207:/home/platform-monitor/workspace/liulqlibs/* .
