/*
 * acbmcache.c
 *
 *  Created on: 2016年1月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
//#include <sys/syscall.h>
#include <pthread.h>
#include "liulqcore.h"
#include "acbm.h"

#define MAX_ACBM_SIZE   (5*1024*1024)

acbmftree_t acbm = {
		.cache = {
				.addr = "/home/acbm.txt"
		},
};


#define MAX_RECV 	1024
int main(int argc, char* argv[])
{
	char acbmfkey[128] = "/home/acbm.txt";
	char acbmftxt[128] = "/home/acbm-text.txt";

	int flen = file_size(acbmftxt), rcnt = 0, i=0;
	unsigned char fbuf[flen+10];
	memset(fbuf, 0, flen + 10);
	char* recvkeys[MAX_RECV];
	memset(recvkeys, 0, MAX_RECV * sizeof(void*));
	file_read_tobuffer(acbmftxt, fbuf);

	acbmftree_initialize(&acbm);

	while(10) {
		if(filecache_modify(&(acbm.cache))) {
			printf("==================================================\n");
			acbmtree_t* tree = (acbmtree_t*)filecache_bymodify(&(acbm.cache));
			for(i=0;i<tree->pattern_count;i++) {
				printf("%d:'%s';\n", i, (char*)tree->pattern_list[i].data);
			}
			rcnt = acbmtree_searchkey(tree, fbuf, flen, recvkeys, MAX_RECV, 0, 1);

			printf("find %d key!********************************\n", rcnt);
			for(i=0;i<rcnt;i++) {
				printf("%d key:'%s';\n", i, recvkeys[i]);
			}
		}
		sleep(1);
	}
}

