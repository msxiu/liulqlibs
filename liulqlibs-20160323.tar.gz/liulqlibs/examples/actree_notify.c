/*
 * actree_notify.c
 *
 *  Created on: 2016年2月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/inotify.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "actree.h"

#define MAX_RECV 	512

inotifywatch_t watch = {
		.nodes = {
				{ .mask = (IN_CREATE | IN_MODIFY | IN_DELETE), .addr = "/home/acbm.txt", .onchange = actree_notify_change },//
				{ .mask = 0 },
		}
};



int main(int argc, char* argv[])
{
	gdbentry.level = 6;
	gdbentry.state = 3;
	char acbmftxt[128] = "/home/acbm-text.txt";
	struct timespec t;
	int flen = file_size(acbmftxt), rcnt = 0, i=0;
	unsigned char fbuf[flen+10];
	memset(fbuf, 0, flen + 10);
	if(argc > 1) {
		strcpy(acbmftxt, argv[1]);
	}

	file_read_tobuffer(acbmftxt, fbuf);

	inotifywatch_startup(&watch);
	while(1) {
		if(watch.nodes[0].last.tv_sec != t.tv_sec || watch.nodes[0].last.tv_nsec != t.tv_nsec) {
			actree_match_t * matcheds;
			matcheds = actree_alloc_matchs(MAX_RECV);
			actree_t* tree = (actree_t*)watch.nodes[0].arg;
			GDB_DEBUG("==================================================\n");
			for(i=0;i<tree->pattern_count;i++) {
				printf("%d:'%s';\n", i, (char*)tree->pattern_list[i].data);
			}
			rcnt = actree_search(tree, fbuf, flen, matcheds, 1);

			GDB_DEBUGS("find %d key!********************************\n", rcnt);
			for(i=0;i<rcnt;i++) {
				printf("%d key:'%s';\n", i, matcheds->elements[i].pattern->data);
			}
			free(matcheds);
			t = watch.nodes[0].last;
		}
		sleep(1);
	}
}





