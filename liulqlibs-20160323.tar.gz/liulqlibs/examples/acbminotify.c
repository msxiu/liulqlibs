/*
  *
 *  Created on: 2016年1月24日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
//#include <sys/syscall.h>
#include <pthread.h>
#include <sys/inotify.h>
#include "liulqcore.h"
#include "liulqdebug.h"
#include "acbm.h"

#define MAX_RECV 	1024
#define MAX_ACBM_SIZE   (5*1024*1024)

inotifywatch_t watch = {
		.nodes = {
				{ .mask = (IN_CREATE | IN_MODIFY | IN_DELETE), .addr = "/home/acbm.txt", .onchange = acbmtree_notify_change },//
				{ .mask = 0 },
		}
};



int main(int argc, char* argv[])
{
	gdbentry.level = 6;
	gdbentry.state = 3;
	char acbmftxt[128] = "/home/acbm-text.txt";

	int flen = file_size(acbmftxt), rcnt = 0, i=0;
	unsigned char fbuf[flen+10];
	memset(fbuf, 0, flen + 10);
	char* recvkeys[MAX_RECV];
	memset(recvkeys, 0, MAX_RECV * sizeof(void*));
	if(argc > 1) {
		strcpy(acbmftxt, argv[1]);
	}

	file_read_tobuffer(acbmftxt, fbuf);
	//acbmtree_inotify(&watch);

	inotifywatch_startup(&watch);
	struct timespec t;
	while(1) {
		if(watch.nodes[0].last.tv_sec != t.tv_sec || watch.nodes[0].last.tv_nsec != t.tv_nsec) {
			acbmtree_t* tree = (acbmtree_t*)watch.nodes[0].arg;
			GDB_DEBUG("==================================================\n");
			for(i=0;i<tree->pattern_count;i++) {
				printf("%d:'%s';\n", i, (char*)tree->pattern_list[i].data);
			}
			rcnt = acbmtree_searchkey(tree, fbuf, flen, recvkeys, MAX_RECV, 0, 1);

			printf("find %d key!********************************\n", rcnt);
			for(i=0;i<rcnt;i++) {
				printf("%d key:'%s';\n", i, recvkeys[i]);
			}
			t = watch.nodes[0].last;
		}
		sleep(1);
	}
}

