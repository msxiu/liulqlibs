﻿#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <liulqcore.h>
#include <liulqnet.h>

#define FMT_IPADDR "%d.%d.%d.%d"
#define FMT_MAC		"%x:%x:%x:%x:%x:%x"
#define TO_IPADDR(a)  (int)((a)&0xFF), (int)(((a)>>8)&0xFF), (int)(((a)>>16)&0xFF), (int)(((a)>>24)&0xFF)
#define TO_MAC(a)		(int)a[0],(int)a[1],(int)a[2],(int)a[3],(int)a[4],(int)a[5]
#define STR_IPADDR(a, b)	sprintf(b, FMT_IPADDR, TO_IPADDR(a))
#define GDB_INTEGER_ADD(a)		(++a, a &= 0x0FFFFFFF)
#define GDB_INTEGER_SUM(a, b)		(a = ((a+b)&0x0FFFFFFF))


#define		MSG_SENSITIVE_ALERT_DEVICE_ID_LEN		10 + 1
#define		MSG_SENSITIVE_ALERT_EVENT_TIME_LEN		24 + 1
#define		MSG_SENSITIVE_ALERT_DMAC_LEN			17 + 1
#define		MSG_SENSITIVE_ALERT_SENDER_LEN			64 + 1
#define		MSG_SENSITIVE_ALERT_RECEIVE_LEN			256 + 1
#define		MSG_SENSITIVE_ALERT_TITLE_LEN			128 + 1
#define		MSG_SENSITIVE_ALERT_FILE_NAME_LEN		256 + 1
#define		MSG_SENSITIVE_ALERT_DESCR_LEN			128 + 1
#define		MSG_SENSITIVE_ALERT_SEN_MSG_LEN			128 + 1

//TCP回话的五元组数据
typedef struct {
    time_t startrawtime;/*开始时间*/
    time_t endrawtime;/*结束时间*/
    long total_sent;/*上行流量*/
    long total_recv;/*下行流量*/
    unsigned short int src_port;/*源端口*/
    uint32_t src;/*源IP*/
    unsigned short int dst_port;/*目的端口*/
    uint32_t dst;/*目的ip*/
    unsigned short int protocol;/*协议*/
    uint8_t dmac[6];//目标MAC地址
    uint8_t smac[6];//目标MAC地址
} history_type;


typedef struct attach_file{
		int8_t            m_sid[128];                                          //sid,用于匹配附件
		int8_t            m_name[512];                                        //附件名称
		int8_t            m_type[32];                                         //附件类型
		uint64_t          m_size;                                             //附件大小
		uint64_t          m_time;                                             //收到附件时间
		uint8_t*          m_content;                                          //附件内容
		struct attach_file*    next;
}attach_file_t;


typedef struct {
		int64_t          m_sip;                                              //源ip
		uint32_t         m_sport;                                            //源端口
		int64_t          m_dip;                                              //目的ip
		uint32_t         m_dport;                                            //目的端口
		int8_t           m_dmac[MSG_SENSITIVE_ALERT_DMAC_LEN];               //内部主机地址mac
		int8_t           m_sid[128];                                          //sid,用于匹配附件
		int8_t           m_sender[MSG_SENSITIVE_ALERT_SENDER_LEN];           //发送人
		int8_t           m_receiver[MSG_SENSITIVE_ALERT_RECEIVE_LEN];        /*接收人ID和收受方地址，最长为256个字符*/
		int8_t           m_subject[MSG_SENSITIVE_ALERT_TITLE_LEN];           /*event_type为电子邮件:邮件标题;为即时通信:官方名称;为博客、论坛、网盘:接收方网址*/
		int8_t*          m_content;                                          //正文
		struct attach_file*   m_attach_list;                                      //附件列表
		void* attachs;
} mail_info_t;

int form_data_sina (void* par, const char* key, const char* flname, const char* fltype, const char* val, int vlen)
{
	mail_info_t *mail = (mail_info_t*)par;
	if(chars_equals_ignore(key, "from")) {
		SET_BUFFER(mail->m_sender, val, vlen);
	} else if(chars_equals_ignore(key, "to")) {
		SET_BUFFER(mail->m_receiver, val, vlen);
	} else if(chars_equals_ignore(key, "cc")) {
		//抄送
	} else if(chars_equals_ignore(key, "bcc")) {
		//密送
	} else if(chars_equals_ignore(key, "subj")) {
		SET_BUFFER(mail->m_subject, val, vlen);
	} else if(chars_equals_ignore(key, "msgtxt")) {
		if(NULL == mail->m_content) {
			mail->m_content = (char*)malloc(vlen+1);
			SET_BUFFER(mail->m_content, val, vlen);
		}
	} else if(chars_equals_ignore(key, "att_swf")) {
		if(NULL == mail->attachs) {
			mail->attachs = malloc(vlen+1);
			char* temp = (char*)mail->attachs;
			SET_BUFFER(temp, val, vlen);
		}
	}
	return 1;
}

//
int http_mail_sina(history_type* e, void* buffer, int len)
{
	httpbuffer_t html = { .data = buffer,  .length = len };
	mail_info_t mail = {.m_dip = e->dst, .m_dport=e->dst_port, .m_sip=e->src, .m_sport = e->src_port };
	sprintf(mail.m_dmac, FMT_MAC, TO_MAC(e->smac));
	if(!httpbuffer_context(&html)) return -1;//解析HTML
	if(http_form_data_file(&html, form_data_sina, &mail) <= 0) return -1;

	printf("sender:%s;\n", mail.m_sender);
	printf("receiver:%s;\n", mail.m_receiver);
	printf("subject:%s;\n", mail.m_subject);
	printf("attachs:%s;\n", (char*)mail.attachs);
	printf("content:%s;\n", mail.m_content);
	if(mail.m_content) free(mail.m_content);
	return 0;
}



int form_data_sina_attach (void* par, const char* key, const char* flname, const char* fltype, const char* val, int vlen)
{
	attach_file_t *attach = (attach_file_t*)par;
	if(chars_equals_ignore(key, "filedata")) {
		if(NULL == attach->m_content) {
			strcpy(attach->m_name, flname);
			strcpy(attach->m_type, fltype);
			attach->m_content = malloc(vlen+1);
			char* temp = (char*)attach->m_content;
			attach->m_size = vlen;
			SET_BUFFER(temp, val, vlen);
		}
	}
	return 1;
}
//
int http_mail_sina_attach(history_type* e, void* buffer, int len)
{
	attach_file_t attach = {0};
	httpbuffer_t html = { .data = buffer,  .length = len };
	char mails[128];
	if(!httpbuffer_context(&html)) return -1;//解析HTML
	if(http_form_data_file(&html, form_data_sina_attach, &attach) <= 0) return -1;

	if(NULL != attach.m_content) {
		memset(mails, 0, sizeof(mails));
		sscanf((char*)buffer+28, "email=%[^&]", mails);
		printf("sender:%s,attach:{name:'%s',type:'%s',size:%u}\n", mails, attach.m_name, attach.m_type, (unsigned int)attach.m_size);
		free(attach.m_content);
	}
	return 0;
}



int main(int argc, char *argv[])
{
	history_type e;
	const char* fname = "sina_mail.txt", *flname2 = "sina_attach.txt";
	int length = file_length(fname);
	char* buffer;
	buffer= (char*)malloc(length+10);
	file_read_tobuffer(fname, buffer);
	buffer[length] = 0;

	http_mail_sina(&e, buffer, length);
	free(buffer);

	length = file_length(flname2);
	buffer = (char*)malloc(length+10);
	file_read_tobuffer(flname2, buffer);
	buffer[length] = 0;
	http_mail_sina_attach(&e, buffer, length);
	free(buffer);
}
