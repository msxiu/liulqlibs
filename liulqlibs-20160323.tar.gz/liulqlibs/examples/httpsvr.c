﻿#include "liulqdebug.h"
#include "liulqcore.h"
#include "liulqsmart.h"
#include "liulqnet.h"
//*************************************************************************
void httpsvr_execute(socksvrc_t* c)
{
	int state = 0, i=0;
	httpd_t* req = malloc(sizeof(httpd_t));
	char key[64], val[512], item[512];
	memset(req, 0, sizeof(httpd_t));
	memcpy(&(req->client), &(c->sock), sizeof(socketc_t));
	state = httpd_initialize(req);
	if(state <= 0) {
		GDB_ERRORS("httpsvr_execute %d error!\n", state);
		return;
	}
	GDB_DEBUGS("%d headers\n", req->request.headcnt);

	GDB_SEPARATOR("http request headers");
	while(i < req->request.headcnt) {
		vfield_t fld = req->request.headers[i];
		state = fld.key.finish - fld.key.start;
		SET_BUFFER(key, req->request.header + fld.key.start, state);
		state = fld.val.finish - fld.val.start;
		SET_BUFFER(val, req->request.header + fld.val.start, state);

		sprintf(item, "%d:{key:%s,value:%s}<br />\n", i, key, val);
		GDB_DEBUGS("%d:{%d:%d,%d:%d}=%s", i, fld.key.start, fld.key.finish, fld.val.start, fld.val.finish, item);
		httpres_addtext(req, item);
		i++;
	}
	GDB_SEPARATOR("http request parameters");
	i = 0;
	while(i < req->request.paracnt) {
		vfield_t fld = req->request.paras[i];
		state = fld.key.finish - fld.key.start;
		SET_BUFFER(key, req->request.header + fld.key.start, state);
		state = fld.val.finish - fld.val.start;
		SET_BUFFER(val, req->request.header + fld.val.start, state);

		sprintf(item, "%d:{key:%s,value:%s}<br />\n", i, key, val);
		GDB_DEBUGS("%d:{%d:%d,%d:%d}=%s", i, fld.key.start, fld.key.finish, fld.val.start, fld.val.finish, item);
		httpres_addtext(req, item);
		i++;
	}
	GDB_SEPARATOR("http request cookies");
	i = 0;
	while(i < req->request.cookcnt) {
		vfield_t fld = req->request.cookies[i];
		state = fld.key.finish - fld.key.start;
		SET_BUFFER(key, req->request.header + fld.key.start, state);
		state = fld.val.finish - fld.val.start;
		SET_BUFFER(val, req->request.header + fld.val.start, state);

		sprintf(item, "%d:{key:%s,value:%s}<br />\n", i, key, val);
		GDB_DEBUGS("%d:{%d:%d,%d:%d}=%s", i, fld.key.start, fld.key.finish, fld.val.start, fld.val.finish, item);
		httpres_addtext(req, item);
		i++;
	}
	GDB_DEBUGS("finished buffer %d pages;\n", state);

	httpres_write(req);
	GDB_DEBUGS("client address:'%p',connid:%d;\n", &(c->sock), c->sock.connfd);
	httpd_destory(req);
}
socksvr_t svr = {port:80, backlog:128};
int httpsvr_start()
{
	svr.execute = &httpsvr_execute;
	if(-1 == socksvr_start(&svr)) {
		GDB_ERRORS("http server listen %d error!\n", svr.port);
		return 0;
	}
	return 1;
}
int httpsvr_join()
{
	return socksvr_join(&svr);
}
int httpsvr_cancel()
{
	return socksvr_cancel(&svr);
}
void httpsvr_destory()
{
	socksvr_destory(&svr);
}


//*******************************************************
#define MAX_FILEPATH 256
char cmdaddr[MAX_COMMAND_LEN];
//templatec_t m_template;

int main(int argc, char* argv[])
{
	gdb_mtrace_start("output");

	gdbentry.level = 6;
	gdbentry.state = 3;
	//iniconfig_load("config.ini", configuare_parse);
	if(!httpsvr_start()) goto httpexit;
	httpsvr_join();
	httpsvr_cancel();
	httpsvr_destory();

httpexit:
	httpsvr_cancel();
	httpsvr_destory();
	gdbentry_destory();
	GDB_WARN("main finish!\n");
	return 1;
}
