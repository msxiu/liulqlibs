/*
 * hashmap.c
 *
 *  Created on: 2016年1月14日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include "liulqdebug.h"
#include "liulqcore.h"

int  print_hash_int(void*o, hashelement_t* b)//循环枚举
{
	printf("%p{%d:%d};\n", b, *(int*)b->key, *(int*)b->val);
	return 1;
}
int print_hash_string(void*o, hashelement_t* b)//循环枚举
{
	printf("%p{%s:%s};\n", b, (char*)b->key, (char*)b->val);
	return 1;
}

int main(int argc, char* argv[])
{
	gdbentry.level = 6;
	gdbentry.state = 3;

	hashmap_t *map = hashmap_create_int32(65535);
	hashbuffer_t *hash;
	int i=0;
	//
	for(;i<5;i++) {
		hashmap_addint32(map, &i, i);
	}
	hashmap_each(map, print_hash_int, NULL);
	hashmap_destory(map);


	map = hashmap_create_string(65535);
	hashmap_addstring(map, "a4", "abcd");
	hashmap_addstring(map, "1b", "010");
	hashmap_addstring(map, "c6", "123");
	hashmap_addstring(map, "d", "456");
	hashmap_addstring(map, "4e", "789");
	hashmap_addstring(map, "ff", "102");
	hashmap_addstring(map, "pg", "987");

	printf("-----map------------------------------------------------------------------\n");
	printf("map has size:%d;\n", hashmap_count(map));
	printf("map has 4e:%s;\n", (char*)hashmap_find(map, "4e"));
	printf("map has c6:%d;\n", hashmap_contains(map, "c6"));
	printf("map has c7:%d;\n", hashmap_contains(map, "c7"));
	printf("map equals c6(123):%d;\n", hashmap_equals_string(map, "c6", "123"));
	printf("map equals c6(456):%d;\n", hashmap_equals_string(map, "c6", "456"));

	hashmap_each(map, print_hash_string, NULL);
	hashmap_destory(map);


	hash = hashbuffer_create(256, 50 * 1024);
	hashbuffer_add(hash, "a4", "abcd");
	hashbuffer_add(hash, "1b", "010");
	hashbuffer_add(hash, "c6", "123");
	hashbuffer_add(hash, "d", "456");
	hashbuffer_add(hash, "4e", "789");
	hashbuffer_add(hash, "ff", "102");
	hashbuffer_add(hash, "pg", "987");

	printf("-----hash------------------------------------------------------------------\n");
	printf("hash has size:%d;\n", hashbuffer_count(hash));
	printf("hash has 4e:%s;\n", (char*)hashbuffer_find(hash, "4e"));
	printf("hash has c6:%d;\n", hashbuffer_contains(hash, "c6"));
	printf("hash has c7:%d;\n", hashbuffer_contains(hash, "c7"));
	printf("hash equals c6(123):%d;\n", hashbuffer_equals_string(hash, "c6", "123"));
	printf("hash equals c6(456):%d;\n", hashbuffer_equals_string(hash, "c6", "456"));

	hashbuffer_each(hash, print_hash_string, NULL);
	hashbuffer_destory(hash);

}



