/*
 * threadpool.c
 *
 *  Created on: 2016年1月22日
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
//#include <sys/syscall.h>
#include <pthread.h>
#include "liulqcore.h"
#include "acbm.h"

//acbmtree_t acbm;
threadpool_t tpool;


void thread_run(void* arg)
{
	printf("msg:thread %d %s; task:%d;\n", (int)pthread_self(), (char*)arg, tpool.queuelen);
	sleep(1);
}

int main(int argc, char* argv[])
{
	gdbentry.level = 6;
	gdbentry.state = 3;

	int i=0, count = 30;
	char* addr;
	threadpool_listern(&tpool, 2, thread_run);
	printf("threadpool_listern\n");
	for(i=0;i<count;i++) {
		addr = threadpool_task_alloc(&tpool, 64);
		sprintf(addr, "start %d task!", i);
	}
	sleep(20);

	for(i=0;i<count;i++) {
		addr = threadpool_task_alloc(&tpool, 64);
		sprintf(addr, "start %d task!", i);
		sleep(1);
		//sprintf(addr, "thread %ld start %d task!", syscall(SYS_gettid), i);
	}
	threadpool_join(&tpool);
}



