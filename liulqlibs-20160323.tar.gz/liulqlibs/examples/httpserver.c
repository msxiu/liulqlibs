﻿#include "liulqdebug.h"
#include "liulqcore.h"
#include "liulqsmart.h"
#include "liulqnet.h"

void* httpserver_connect(epollsvr_t *e, socketc_t *c)
{
	GDB_DEBUG("httpserver_connect;\n");
	httpd_t* req = malloc(sizeof(httpd_t));
	memset(req, 0, sizeof(httpd_t));
	memcpy(&(req->client), c, sizeof(socketc_t));
	req->server = e;
	return req;
}
int httpserver_send(epollsvr_t *e, int i)//处理数据发送
{
	GDB_DEBUG("httpserver_send;\n");
	httpd_t *c = (httpd_t *)e->events[i].data.ptr;

	httpres_addtext(c, "OK");
	httpres_write(c);
	GDB_DEBUGS("client address:'%p',connid:%d;\n", &(c->client), c->client.connfd);

	epollsvr_torecv(e, &(c->client), i);
	epollcnt_destory(e, &(c->client), i);
	GDB_DEBUG("httpserver_send finish!\n");
	httpd_destory(c);
	GDB_DEBUGS("free httpd_t by %p!\n", c);
	free(c);
	GDB_DEBUGS("httpserver_send finish!\n%s", GDB_LINE_NEXT);
	return -1;
}

int httpserver_recv(epollsvr_t *e, int i)//处理数据接收
{
	GDB_DEBUG("httpserver_recv;\n");
	httpd_t *c = (httpd_t *)(e->events[i].data.ptr);
	if(httpd_initialize(c) <= 0) {
		goto laberror;
	}
	GDB_DEBUG("read the header finish, transfer servers;\n");
	epollsvr_tosend(e, &(c->client), i);
	return 0;

laberror:
	epollcnt_destory(e, &(c->client), i);
	return -1;
}

epollsvr_t e;
int httpserver_start()
{
	//strcpy(e.ipaddr, "192.168.0.1");
	memset(&e, 0, sizeof(epollsvr_t));
	e.port = 80;
	e.backlog = 128;
	e.onsend = &httpserver_send;
	e.onrecv = &httpserver_recv;
	e.connect = &httpserver_connect;
	if(-1 == epollsvr_start(&e)) {
		GDB_ERRORS("http server listen %d error!\n", e.port);
		return 0;
	}
	return 1;
}
void httpserver_join()
{
	epollsvr_join(&e);
	epollsvr_destory(&e);
}


#define MAX_FILEPATH 256

char cmdaddr[MAX_COMMAND_LEN];
//templatec_t m_template;

int main(int argc, char* argv[])
{
	gdb_mtrace_start("output");
	//gdb_dump_start();

	gdbentry.level = 6;
	gdbentry.state = 3;
	//iniconfig_load("config.ini", configuare_parse);

	httpserver_start();
	httpserver_join();
}
