﻿#include "liulqdebug.h"
#include "liulqcore.h"
#include "liulqsmart.h"
#include "liulqnet.h"



#define SCREEN_PRINT(v, l) do {\
	char sb[l+1];\
	memcpy(sb, v, l);\
	sb[l]=0;\
	printf("%s", sb);\
}while(0);

templatec_t tmplate;

void test_template_init()
{
	templatec_initialize(&tmplate, "template.html");
}

void test_template()
{
	GDB_SEPARATOR("first template loading");
	stemplate_t* temp = templatec_entry(&tmplate);
	GDB_SEPARATOR("second template loading");
	temp = templatec_entry(&tmplate);
	GDB_SEPARATOR("finish template loading");
	vdata_t v;
	char buffer[128];
	int i=0, pgcnt = 0;
	GDB_DEBUGS("template address:%p;\n", temp);
	if(-1 != stemplate_param(temp, "cache", buffer)) {
		GDB_DEBUGS("{cache:%s}\n", buffer);
	}
	GDB_DEBUG("stemplate_reset\n");
	stemplate_reset(temp);
	while(1) {
		GDB_DEBUG("stemplate_entry\n");
		stag_t  *tag = stemplate_entry(temp);
		if(NULL != tag) {
			if(stemplate_fore(temp, &v)) {
				SCREEN_PRINT(v.addr, v.length);
			}
			SET_BUFFER(buffer, temp->data.addr+tag->tagname.start, tag->tagname.length);
			printf("{start:%d,finish:%d,tagname:%s}", tag->outner.start, tag->outner.finish, buffer);
			if(-1 != stag_field_value(tag, "template", buffer)) {
				printf("{template:%s}", buffer);
			}
		}
		if(!stemplate_next(temp)) break;
	}
	if(stemplate_last(temp, &v)){
		SCREEN_PRINT(v.addr, v.length);
	}
}

void test_template_free()
{
	templatec_free(&tmplate);
}




#define MAX_FILEPATH 256

char cmdaddr[MAX_COMMAND_LEN];
//templatec_t m_template;

int main(int argc, char* argv[])
{
	gdb_mtrace_start("output");
	//gdb_dump_start();

	gdbentry.level = 6;
	gdbentry.state = 3;
	//iniconfig_load("config.ini", configuare_parse);

	test_template_init();
	test_template();
	test_template_free();
}
